﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace Historia.AI_Behaviour.s1
{
    public class LookAround : Unsettled_Behaviour
    {
        public override void Scheme()
        {
            //bool WillWalkATile;
            if (map.D.Next(0, 100) > 50)
            {
                // WillWalkATile = true;
                bool Successful = PlanWalkToLocation(ThreatLocation(),1);
                //Pick a nearby tile 
                if (Successful)
                {
                    
                }
                else
                {
                    AddToPlan(Me.TilePosition, 0, false);
                    
                }

            }
            else
            {
                //WillWalkATile = false;
                
                AddToPlan(Me.TilePosition+ Being.GetDirection(map.D.Next(0, 3)), 0, false);
               
            }
        }
    }
}
