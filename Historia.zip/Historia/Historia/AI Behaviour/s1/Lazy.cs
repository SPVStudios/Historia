﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace Historia.AI_Behaviour.s1
{
    class Lazy:Unsettled_Behaviour
    {
        public override void Scheme()
        {
            AddToPlan(Me.TilePosition, 0, false);
            
        }
    }
}
