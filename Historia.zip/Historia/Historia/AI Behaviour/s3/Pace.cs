﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace Historia.AI_Behaviour.s3
{
    class Pace:Alerted_Behaviour
    {
        public override void Scheme()
        {
            if (CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, map.BC.BC, Me.TilePosition+Me.Direction))
            {
                
                AddToPlan(Me.TilePosition+Me.Direction, 1, true);
                return;
            }
            else if (CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, map.BC.BC, Me.TilePosition - Me.Direction))//behind
            {
                AddToPlan(Me.TilePosition - Me.Direction,1,true);
                
                return;
            }
            else
            {
                
                AddToPlan(Me.TilePosition, 0, false);
            }
        }
    }
}
