﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Xml.Serialization;
using System.Xml;

namespace Historia.AI_Behaviour.s3
{
    public abstract class Alerted_Behaviour:AIBehaviour//Detection Level 3+ - Has quite concrete belief in a particular Co-ordinate.
        //would normally pathfind to your location and attack you.

    //Alerted_Behaviours consist of a response behaviour to the threat level, usually just trying to get to you to attack you - 
    // and also a specific attack strategy behaviour be mentioned if it overrides the combat system specified by basic AI, be it zealous and use-up-stamina-quick, or sneak-and-dodge-y, or Parry intensive etc.
    {
        protected virtual Rectangle SuggestThreatLocation()
        {
            Vector2 BiggestKey = Vector2.Zero;
            int BiggestValue = 0;
            //step 1: Create 3x3 clusters using the values for all tiles in that cluster added together
            foreach (KeyValuePair<Vector2, int> I in Me.CurrentSuspicions)
            {
                if(I.Value > BiggestValue)
                {
                    BiggestValue = I.Value;
                    BiggestKey = I.Key;
                }
            }
            return new Rectangle((int)BiggestKey.X, (int)BiggestKey.Y,1,1);//the most suspicious tile.
        }

        protected void AttackAdjacentEnemy(out Vector2 Target, out int Action, out bool MovementBased)
        {
            Target = StealthManager.Instance.PlayerLoc;
            MovementBased = false;

            if(map.D.Next(0,100) > 65)//35% chance of them using a heavy attack
            {
                Action = 4;
            }
            else
            { //65% chance of a regular attack
                Action = 3;
            }
        }

        public override void DecideWhatToDo(out Vector2 NextTarget, out int NextAction, out bool MovementBased)
        {
            Vector2 PlayerLoc = StealthManager.Instance.PlayerLoc;

            if (RectMethod.DistanceBetweenLocations(Me.TilePosition, StealthManager.Instance.PlayerLoc) == 1
                && StealthMethod.CheckLOS(map, Me.TilePosition, PlayerLoc)
                && StealthMethod.CheckFOV(Me.TilePosition, PlayerLoc, Me.Direction))
            {
                AttackAdjacentEnemy(out NextTarget, out NextAction, out MovementBased);
            }
            else
            {
                base.DecideWhatToDo(out NextTarget, out NextAction, out MovementBased);//act using the usual protocol.
            }

        }



    }
}
