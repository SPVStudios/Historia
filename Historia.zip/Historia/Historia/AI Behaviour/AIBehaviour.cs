﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;


namespace Historia.AI_Behaviour
{
    public abstract class AIBehaviour
    {
        protected Enemy Me;
        protected Map map;


        const int TimesTillRethink = 5;
        const int MaxRethinkScope = 5;


        protected bool HasAPlan
        {
            get
            {
                if (PlannedTargets.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }



        public List<Vector2> PlannedTargets { get { return plannedTargets; } }
        protected List<Vector2> plannedTargets;
        public List<int> PlannedActions { get { return plannedActions; } }
        protected List<int> plannedActions;
        public List<bool> PlannedActionsMB { get { return plannedActionsMB; } }
        protected List<bool> plannedActionsMB;
        //when the end of this list is reached, the AI should carry out the process the Plan's Aim was.


        public List<Vector2> BackupTargets { get { return backupTargets; } }
        protected List<Vector2> backupTargets;
        public List<int> BackupActions { get { return backupActions; } }
        protected List<int> backupActions;
        public List<bool> BackupActionsMB { get { return backupActionsMB; } }
        protected List<bool> backupActionsMB;



        public bool WaitingforGoAhead { get; private set; }
        bool GoAhead;


        public Vector2 ConfirmedTile;


        protected int PlanAimID;
        /// <summary>
        /// Key for what the plans mean
        /// 0 = Walk to Location - no end action
        /// 1 = Check Suspicious Location - Confirm Enemy Location or Dissipate Suspicion of tile. Look at 2 facings as well.
        /// 2 = Attack Final Location
        /// 3 = Pull into Layby - have moved here to get out of way of another. switch WaitingOnGoAhead to true GoAhead to false, and transfer the backupPlan to this one, on this plan being completed.
        /// 
        /// 
        /// 
        /// 
        /// </summary>
        /// <param name="NextTarget"></param>
        /// <param name="NextAction"></param>
        /// <param name="HasAPlan"></param>
        /// <param name="PlanAimID"></param>

        //the Lists above work in cooperation with each other. If the AI deems itself to "HaveAPlan",
        //then it just returns the next values and deletes those from the plan, until ther isn't any left.

        //Certain conditions may be monitored to check that the Plan still makes sense.
        //One interrupt mechanic already exists - suspicion rising or falling to the extent that this Behaviour isn't active any more!

        public virtual void DecideWhatToDo(out Vector2 NextTarget, out int NextAction, out bool MovementBased)
        {
            if (!WaitingforGoAhead)
            {
                if (!HasAPlan)
                {
                    Scheme();
                }

                ExecutePlan(out NextTarget, out NextAction, out MovementBased);
            }
            else
            {
                
                if (GoAhead || AIMoveManager.Instance.NumPassCalls == 0)
                {
                    WaitingforGoAhead = false;
                    GoAhead = false;
                    if (!HasAPlan)
                    {
                        Scheme();
                    }

                    ExecutePlan(out NextTarget, out NextAction, out MovementBased);
                }
                else
                {
                    NextAction = 0;
                    NextTarget = Me.TilePosition;
                    MovementBased = false;
                }
            }

        }

        public void ExecutePlan(out Vector2 NextTarget, out int NextAction, out bool MovementBased)
        {
            if (PlannedTargets.Count > 0)
            {
                if (RectMethod.TwoTilesAreAdjacentOrSame(PlannedTargets[0], Me.TilePosition) 
                    && (PlannedTargets[0] == Me.TilePosition || CollisionCheck.Instance.CheckTarget(map.Collision.CMap,map.BC.BC,PlannedTargets[0],true)!=4))//if next location is on or adjacent to this tile and it's not occupied by a fellow enemy....
                {//enact plan
                    RethinkCount = TimesTillRethink;//reset refthink count on valid plan
                    NextAction = PlannedActions[0];
                    NextTarget = PlannedTargets[0];
                    MovementBased = PlannedActionsMB[0];
                    PlannedActions.RemoveAt(0);
                    PlannedTargets.RemoveAt(0);
                    PlannedActionsMB.RemoveAt(0);
                    if (PlannedActions.Count == 0)//if a plan has finished...
                    {
                        switch (PlanAimID)
                        {
                            case 1:
                                //check this suspicious Location
                                Vector2 PlayerLoc = StealthManager.Instance.PlayerLoc;
                                int DistanceFromMe = RectMethod.DistanceBetweenLocations(PlayerLoc, Me.TilePosition);
                                if (StealthMethod.CheckLOS(map, Me.TilePosition, PlayerLoc)
                                    && StealthMethod.CheckFOV(Me.TilePosition, PlayerLoc, Me.Direction)
                                    && DistanceFromMe <= 3)
                                {
                                    Me.MakeSuspiciousOfTile(PlayerLoc, Enemy.AlertPointsPerLevel);
                                    ConfirmEnemyLocation(PlayerLoc);
                                }
                                else
                                {
                                    DissipateSuspicion(Me.TilePosition);
                                }

                                break;
                            case 2:
                                //Attack this confirmed Player location, if that makes sense
                                break;
                            case 3:
                                //Begin Waiting for Go Ahead
                                CollisionCheck.Instance.AddOverrule(Me.TilePosition, 4);
                                WaitingforGoAhead = true;
                                PlanAimID = 0;
                                GoAhead = false;
                                plannedTargets.AddRange(BackupTargets);
                                plannedActions.AddRange(backupActions);
                                plannedActionsMB.AddRange(backupActionsMB);
                                break;
                        }
                        PlanAimID = 0;
                    }
                }
                else
                {//plan invalid, back to the drawing board
                    CancelPlan();
                    RethinkCount--;
                    if (RethinkCount > 0)
                    {
                        Scheme();
                        //ExecutePlan(out NextTarget, out NextAction, out MovementBased);
                        GiveHesitationPlan(out NextTarget, out NextAction, out MovementBased);
                    }
                    else
                    {
                        Rethink();
                        //ExecutePlan(out NextTarget, out NextAction, out MovementBased);
                        GiveHesitationPlan(out NextTarget, out NextAction, out MovementBased);
                    }
                    
                }
            }
            else
            {
                //plan invalid, back to the drawing board
                CancelPlan();
                Scheme();
                //ExecutePlan(out NextTarget, out NextAction, out MovementBased);
                GiveHesitationPlan(out NextTarget, out NextAction, out MovementBased);
            }

        }

        public abstract void Scheme();
        //Scheming takes place when a plan does not already exist.

        public void Rethink()
        {
            int Scope = 1;
            int TriesTillBiggerScope = 5;

            while (true)
            {
                int WanderToX = map.D.Next((int)Me.TilePosition.X - Scope, (int)Me.TilePosition.X + Scope);
                int WanderToY = map.D.Next((int)Me.TilePosition.Y - Scope, (int)Me.TilePosition.Y + Scope);
                if (CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, new Vector2(WanderToX, WanderToY)) && Me.TilePosition != new Vector2(WanderToX, WanderToY))
                {
                    if (PlanWalkToLocation(new Vector2(WanderToX, WanderToY), 0))
                    {
                        break;
                    }
                    else
                    {
                        TriesTillBiggerScope--;//if keeps failing, cast the net wider
                    }
                }

                if (TriesTillBiggerScope <= 0 && Scope < MaxRethinkScope)
                {
                    Scope++;
                    TriesTillBiggerScope = 5 + Scope;
                }
            }
        }
        //A rethink takes place when a plan is invalid and has been declared invalid a few times.
        private int RethinkCount;//the amount of times it will repeat again before triggering a rethink.

        public virtual void LoadContent(ref Enemy Me, Map map)
        {
            this.Me = Me;
            this.map = map;
            plannedActions = new List<int>();
            plannedTargets = new List<Vector2>();
            plannedActionsMB = new List<bool>();

        }

        protected Rectangle CalculateCurrentRoomIn(Vector2 Location)
        {
            for (int R = 0; R < map.Rooms.Count; R++)
            {
                if (RectMethod.LocationIsInRectangle(Location, map.Rooms[R].Location[0]))
                {

                    return map.Rooms[R].Location[0];
                }
            }
            //now checks passageways
            for (int P = 0; P < map.Passages.Count; P++)
            {
                if (RectMethod.LocationIsInRectangle(Location, map.Passages[P].Location))
                {


                    return map.Passages[P].Location;
                }
            }
            throw new Exception("Not in a Room or a Passageway..");
        }

        protected Rectangle CalculateCurrentRoomIn(Vector2 Location, out int RoomOrPassageNum, out bool IsInRoom)
        {
            for (int R = 0; R < map.Rooms.Count; R++)
            {
                if (RectMethod.LocationIsInRectangle(Location, map.Rooms[R].Location[0]))
                {
                    RoomOrPassageNum = R;
                    IsInRoom = true;
                    return map.Rooms[R].Location[0];
                }
            }
            //now checks passageways
            for (int P = 0; P < map.Passages.Count; P++)
            {
                if (RectMethod.LocationIsInRectangle(Location, map.Passages[P].Location))
                {

                    IsInRoom = false;
                    RoomOrPassageNum = P;
                    return map.Passages[P].Location;
                }
            }
            throw new Exception("Not in a Room or a Passageway..");
        }

        protected void AddToPlan(Vector2 Target, int Action, bool IsMovementBased)
        {
            plannedTargets.Add(Target);
            plannedActions.Add(Action);
            plannedActionsMB.Add(IsMovementBased);
        }


        //end of Pathfinding algorithm(s)


        protected void ConfirmEnemyLocation(Vector2 OpponentsTile)
        //when a location is confirmed to contain the opponent, redistribute suspicion to halve all others,
        //set it to the Confirmed location, and put all of the suspicion from everything else onto that tile.
        {
            int ExtraSuspicion = 0;

            Dictionary<Vector2, int> NewSuspicions = new Dictionary<Vector2, int>();
            foreach (KeyValuePair<Vector2, int> I in Me.CurrentSuspicions)
            {
                NewSuspicions.Add(I.Key, I.Value / 2);
                ExtraSuspicion += I.Value / 2;
            }

            NewSuspicions[OpponentsTile] += ExtraSuspicion;
            ConfirmedTile = OpponentsTile;
        }

        protected void MoveConfirmedPosition(Vector2 NewLocation)
        //When you see the opponent move, just move the confirmed tile and its suspicion onto the new tile.
        {
            if (Me.CurrentSuspicions.ContainsKey(NewLocation))
            {
                Me.CurrentSuspicions[NewLocation] += Me.CurrentSuspicions[ConfirmedTile];
            }
            else
            {
                Me.CurrentSuspicions.Add(NewLocation, Me.CurrentSuspicions[ConfirmedTile]);
            }
            Me.CurrentSuspicions.Remove(ConfirmedTile);
            ConfirmedTile = NewLocation;
        }

        protected virtual void CancelConfirmedPosition()
        //when the player disappears from their once confirmed location to somewhere unknown,
        //spread the suspicion out amongst different tiles in the room.
        {
            Rectangle RoomOfTarget = CalculateCurrentRoomIn(ConfirmedTile);

            Rectangle Close_By = RectMethod.TileIntersectArea(RoomOfTarget, new Rectangle((int)ConfirmedTile.X - 2, (int)ConfirmedTile.Y - 2, 4, 4));

            Dictionary<Vector2, int> DissipatedSuspicion = new Dictionary<Vector2, int>();
            int SuspicionToDissipate = Me.CurrentSuspicions[ConfirmedTile];
            int Total = SuspicionToDissipate;
            while (SuspicionToDissipate > 0)
            {
                int NextAmount = Math.Min(map.D.Next(0, Total / 10), SuspicionToDissipate);
                int LocX, LocY;

                if (map.D.Next(0, 100) > 49)
                {
                    LocX = map.D.Next(Close_By.X, Close_By.Right - 1);
                    LocY = map.D.Next(Close_By.Y, Close_By.Bottom - 1);
                }
                else
                {
                    LocX = map.D.Next(RoomOfTarget.X, RoomOfTarget.Right - 1);
                    LocY = map.D.Next(RoomOfTarget.Y, RoomOfTarget.Bottom - 1);
                }

                if (DissipatedSuspicion.ContainsKey(new Vector2(LocX, LocY)))
                {
                    DissipatedSuspicion[new Vector2(LocX, LocY)] += NextAmount;
                }

            }
            Me.CurrentSuspicions = StealthMethod.CombineSuspicionLists(Me.CurrentSuspicions, DissipatedSuspicion);
            ConfirmedTile = Vector2.Zero;
        }

        protected void DissipateSuspicion(Vector2 Target)
        //similar to the above, but doesn't need to be the confirmed position. However, spreads less closely.
        {
            Rectangle RoomOfTarget = CalculateCurrentRoomIn(Target, out int RoomOrPassageIn, out bool IsInRoom);

            Dictionary<Vector2, int> DissipatedSuspicion = new Dictionary<Vector2, int>();

            int SuspicionToDissipate = 0;
            for (int X = Me.ImmediatelyAhead.X; X < Me.ImmediatelyAhead.Right; X++)
            {
                for(int Y = Me.ImmediatelyAhead.Y; Y < Me.ImmediatelyAhead.Bottom; Y++)
                {
                    if(Me.CurrentSuspicions.ContainsKey(new Vector2(X, Y)))
                    {
                        SuspicionToDissipate += Me.CurrentSuspicions[new Vector2(X, Y)];
                        Me.CurrentSuspicions[new Vector2(X, Y)] = 0;
                    }
                }
                
            }

            int Total = SuspicionToDissipate;
            if (IsInRoom)
            {
                List<Rectangle> Checks = RectMethod.RemoveOverlaps(new List<Rectangle> { Me.ImmediatelyAhead, RoomOfTarget });
                if (Checks.Count < 2)
                {// if the second shape (the room) is entirely contained within the first(the immediatelyAhead square),
                    //this room is so small that the enemy isn't possibly in it.

                }
                else
                {
                    while (SuspicionToDissipate > 0)
                    {
                        int NextAmount = Math.Min(map.D.Next(Total / 8, Total / 3), SuspicionToDissipate);
                        int LocX = map.D.Next(RoomOfTarget.X, RoomOfTarget.Right - 1);
                        int LocY = map.D.Next(RoomOfTarget.Y, RoomOfTarget.Bottom - 1);
                        Vector2 Loc = new Vector2(LocX, LocY);

                        if (!RectMethod.LocationIsInRectangle(Loc, Me.ImmediatelyAhead))
                        {
                            if (DissipatedSuspicion.ContainsKey(new Vector2(LocX, LocY)))
                            {
                                DissipatedSuspicion[new Vector2(LocX, LocY)] += NextAmount;
                            }
                            else
                            {
                                DissipatedSuspicion.Add(new Vector2(LocX, LocY), NextAmount);
                            }
                            SuspicionToDissipate -= NextAmount;
                        }
                    }
                }

                
            }
            else
            {//Is in a passageway
                Rectangle RoomEndA = map.Rooms[map.Passages[RoomOrPassageIn].End1.EndPointID].Location[0];

                Rectangle RoomEndB = map.Rooms[map.Passages[RoomOrPassageIn].End2.EndPointID].Location[0];

                Rectangle Passage = RoomOfTarget;

                while (SuspicionToDissipate > 0)
                {
                    int Roll = map.D.Next(0, 100);
                    int LocX, LocY;
                    if (Roll < 40)
                    {//40% chance of room connected to one way
                        LocX = map.D.Next(RoomEndA.X, RoomEndA.Right - 1);
                        LocY = map.D.Next(RoomEndA.Y, RoomEndA.Bottom - 1);
                    }
                    else if (Roll < 80)
                    {//40% chance of the other one
                        LocX = map.D.Next(RoomEndB.X, RoomEndB.Right - 1);
                        LocY = map.D.Next(RoomEndB.Y, RoomEndB.Bottom - 1);
                    }
                    else
                    {//20% chance of the passageway itself
                        LocX = map.D.Next(Passage.X, Passage.Right - 1);
                        LocY = map.D.Next(Passage.Y, Passage.Bottom - 1);
                    }

                    int NextAmount = Math.Min(map.D.Next(Total / 8, Total / 3), SuspicionToDissipate);
                    
                    Vector2 Loc = new Vector2(LocX, LocY);

                    if (!RectMethod.LocationIsInRectangle(Loc, Me.ImmediatelyAhead))
                    {
                        if (DissipatedSuspicion.ContainsKey(new Vector2(LocX, LocY)))
                        {
                            DissipatedSuspicion[new Vector2(LocX, LocY)] += NextAmount;
                        }
                        else
                        {
                            DissipatedSuspicion.Add(new Vector2(LocX, LocY), NextAmount);
                        }
                        SuspicionToDissipate -= NextAmount;
                    }
                }
            }
            Me.CurrentSuspicions = StealthMethod.CombineSuspicionLists(Me.CurrentSuspicions, DissipatedSuspicion);
        }


        //Routines to be called by Scheme sections to put plans together

        protected bool PlanWalkToLocation(Vector2 Target, int PlanAimID)
        //bool is whether Plan was successfully added.

        {
            List<Vector2> NearbyObstacles = map.BC.OccupiedLocations(RectMethod.RadiusRectangle(Me.TilePosition, 2),Me.MyIndex);

            if (Pathfinding.GetToLocation(Target, Me.TilePosition, out List<Vector2> WayToGetThere, map,NearbyObstacles))
            {
                this.PlanAimID = PlanAimID;
                for (int I = 0; I < WayToGetThere.Count; I++)
                {
                    AddToPlan(WayToGetThere[I], 1, true);
                    WayToGetThere = ListMethod.RemoveConsecDuplicates(WayToGetThere);
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        protected bool PlanWalkToLocation(Rectangle AreaOfTarget, int PlanAimID)//picks random valid tile in the rectangle.
                                                                                //bool is whether Plan was successfully added.
        {
            for (int Try = 0; Try < 5; Try++)
            {
                int X = map.D.Next(AreaOfTarget.X, AreaOfTarget.Right - 1);
                int Y = map.D.Next(AreaOfTarget.Y, AreaOfTarget.Bottom - 1);
                if (Pathfinding.GetToLocation(new Vector2(X,Y), Me.TilePosition, out List<Vector2> WayToGetThere, map))
                {
                    WayToGetThere = ListMethod.RemoveConsecDuplicates(WayToGetThere);
                    this.PlanAimID = PlanAimID;
                    for (int I = 0; I < WayToGetThere.Count; I++)
                    {
                        AddToPlan(WayToGetThere[I], 1, true);

                    }
                    return true;
                }
                else
                {

                }

            }
            return false;
        }

        protected bool CreatePlanToAvoid_B(Vector2 CollLoc, List<Vector2> B_Moves, int AHitsBhere, int B_index)
        {
            int WhenPlanShouldBeInserted;
            int WhenPlanShouldEndBefore;
            List<Vector2> Diversion;

            //find out whether there is an oppurtunity to just go "the other side of a square"
            Vector2 MovementToColl = CollLoc - Me.MovingToTilePosition;

            int ChangePhase = -1;

            if (MovementToColl.X != 0 && MovementToColl.Y != 0)
            {
                List<Vector4> Phases = new List<Vector4>();//Each "Phase" details the X-stint OR Y-stint next, e.g. zigzaggy diagonals will have as many stints as moves.
                                                           //the first two values refer to its movement(X and Y). The second 2 coordinates refer to the X and Y of the first Tile in it.



                if (0 == AHitsBhere)//in case the collision is near-immediate
                {
                    ChangePhase = 0;
                }

                for (int I = 1; I < PlannedTargets.Count; I++)
                {
                    if ((PlannedTargets[I] - PlannedTargets[I - 1]).X == 1 || (PlannedTargets[I] - PlannedTargets[I - 1]).X == -1)
                    {
                        if (Phases.Count > 0)
                        {
                            if (Phases[Phases.Count - 1].X != 0)
                            {
                                Phases[Phases.Count - 1] = Phases[Phases.Count - 1] + new Vector4((PlannedTargets[I] - PlannedTargets[I - 1]), 0, 0);
                            }
                            else
                            {
                                Phases.Add(new Vector4((PlannedTargets[I] - PlannedTargets[I - 1]), PlannedTargets[I - 1].X, PlannedTargets[I - 1].Y));
                            }
                        }
                        else
                        {
                            Phases.Add(new Vector4((PlannedTargets[I] - PlannedTargets[I - 1]), PlannedTargets[I - 1].X, PlannedTargets[I - 1].Y));
                        }
                    }
                    else if ((PlannedTargets[I] - PlannedTargets[I - 1]).Y == 1 || (PlannedTargets[I] - PlannedTargets[I - 1]).Y == -1)
                    {
                        if (Phases.Count > 0)
                        {
                            if (Phases[Phases.Count - 1].Y != 0)
                            {
                                Phases[Phases.Count - 1] = Phases[Phases.Count - 1] + new Vector4((PlannedTargets[I] - PlannedTargets[I - 1]), 0, 0);
                            }
                            else
                            {
                                Phases.Add(new Vector4((PlannedTargets[I] - PlannedTargets[I - 1]), PlannedTargets[I - 1].X, PlannedTargets[I - 1].Y));
                            }
                        }

                        else
                        {
                            Phases.Add(new Vector4((PlannedTargets[I] - PlannedTargets[I - 1]), PlannedTargets[I - 1].X, PlannedTargets[I - 1].Y));
                        }
                    }
                    else//No Movement
                    {
                        //nothing
                    }


                    if (I == AHitsBhere)//find the phase where the collision takes place
                    {
                        ChangePhase = Phases.Count - 1;
                    }
                }
                bool ChangePhaseIsVertical = false;
                if (Phases[ChangePhase].Y != 0)
                {
                    ChangePhaseIsVertical = true;
                }

                if (ChangePhase < Phases.Count - 1)
                {//try to shift the ChangePhase's section one into the next section by extending out the previous stint in that direction
                    List<Vector4> TryPhases = new List<Vector4>();
                    int TryChangePhase = ChangePhase;
                    TryPhases.AddRange(Phases);
                    if (ChangePhaseIsVertical)
                    {
                        TryPhases[TryChangePhase + 1] -= new Vector4(Math.Sign(MovementToColl.X), 0, -Math.Sign(MovementToColl.X), 0);
                        if (TryChangePhase > 0)
                        {
                            TryPhases[TryChangePhase - 1] += new Vector4(Math.Sign(MovementToColl.X), 0, 0, 0);
                        }
                        else
                        {
                            TryPhases.Add(new Vector4(Math.Sign(MovementToColl.X), 0, PlannedTargets[PlannedTargets.Count - 1].X, PlannedTargets[PlannedTargets.Count - 1].Y - Math.Sign(MovementToColl.Y)));
                        }
                        TryPhases[TryChangePhase] += new Vector4(0, 0, Math.Sign(MovementToColl.X), 0);
                    }
                    else
                    {
                        TryPhases[TryChangePhase + 1] -= new Vector4(0, Math.Sign(MovementToColl.Y), 0, -Math.Sign(MovementToColl.Y));
                        if (ChangePhase > 0)
                        {
                            TryPhases[TryChangePhase - 1] += new Vector4(0, Math.Sign(MovementToColl.Y), 0, 0);
                        }
                        else
                        {
                            List<Vector4> Middleman = new List<Vector4>();
                            Middleman.AddRange(TryPhases);
                            TryPhases.Clear();
                            TryPhases.Add(new Vector4(0, Math.Sign(MovementToColl.Y), PlannedTargets[0].X, PlannedTargets[0].Y));
                            TryPhases.AddRange(Middleman);
                            TryChangePhase++;
                        }
                        TryPhases[TryChangePhase] += new Vector4(0, 0, 0, Math.Sign(MovementToColl.Y));
                    }
                    if (Pathfinding.Pathfinding_Check_Path(
                        new Vector2(TryPhases[TryChangePhase].Z, TryPhases[TryChangePhase].W)
                        , new Vector2(TryPhases[TryChangePhase].X, TryPhases[TryChangePhase].Y),
                        true, map, out Vector2 q, out bool Q)) 
                    {//if this patch works

                        List<Vector2> alternatePath = CalculateAvoidSolution(TryPhases, ChangePhase, ChangePhaseIsVertical, out WhenPlanShouldBeInserted, out WhenPlanShouldEndBefore);
                        //ENACT THIS PLAN SOMEWHERE!!
                        //Insert......
                        InsertPlan(alternatePath, 1, true, WhenPlanShouldBeInserted, WhenPlanShouldEndBefore);
                        return true;
                    }
                }

                if (ChangePhase > 0)
                {// (now) try to shift the ChangePhase's section one into the previous section by shortening it by 1, and extending the next stint in that direction
                    List<Vector4> TryPhases = new List<Vector4>();
                    TryPhases.AddRange(Phases);
                    if (ChangePhaseIsVertical)
                    {
                        TryPhases[ChangePhase - 1] -= new Vector4(Math.Sign(MovementToColl.X), 0, 0, 0);
                        if (TryPhases.Count - 1 > ChangePhase)
                        {
                            TryPhases[ChangePhase + 1] += new Vector4(Math.Sign(MovementToColl.X), 0, -Math.Sign(MovementToColl.X), 0);
                        }
                        else
                        {
                            TryPhases.Add(new Vector4(Math.Sign(MovementToColl.X), 0, PlannedTargets[PlannedTargets.Count - 1].X - Math.Sign(MovementToColl.X), PlannedTargets[PlannedTargets.Count - 1].Y));
                        }
                        TryPhases[ChangePhase] -= new Vector4(0, 0, Math.Sign(MovementToColl.X), 0);
                    }
                    else
                    {
                        TryPhases[ChangePhase - 1] -= new Vector4(0, Math.Sign(MovementToColl.Y), 0, 0);
                        if (TryPhases.Count - 1 > ChangePhase)
                        {
                            TryPhases[ChangePhase + 1] += new Vector4(0, Math.Sign(MovementToColl.Y), 0, -Math.Sign(MovementToColl.Y));
                        }
                        else
                        {
                            TryPhases.Add(new Vector4(0, Math.Sign(MovementToColl.Y), PlannedTargets[PlannedTargets.Count - 1].X, PlannedTargets[PlannedTargets.Count - 1].Y - Math.Sign(MovementToColl.Y)));
                        }
                        TryPhases[ChangePhase] -= new Vector4(0, 0, 0, Math.Sign(MovementToColl.Y));
                    }

                    if (Pathfinding.Pathfinding_Check_Path(
                        new Vector2(TryPhases[ChangePhase].Z, TryPhases[ChangePhase].W)
                        , new Vector2(TryPhases[ChangePhase].X, TryPhases[ChangePhase].Y),
                        true, map, out Vector2 q, out bool Q))
                    {//if this patch works
                        Diversion = CalculateAvoidSolution(TryPhases, ChangePhase, ChangePhaseIsVertical, out WhenPlanShouldBeInserted, out WhenPlanShouldEndBefore);
                        //Insert......
                        InsertPlan(Diversion, 1, true, WhenPlanShouldBeInserted, WhenPlanShouldEndBefore);
                        return true;
                    }
                }
            }

            //if not, check to see whether it is 2 wide or more at the site of the collision and a bit before and after it, so you can move unhindered
            bool CollIsVertical = false;
            if (AHitsBhere > 0)
            {
                if ((PlannedTargets[AHitsBhere] - PlannedTargets[AHitsBhere - 1]).Y != 0)
                {
                    CollIsVertical = true;
                }
            }
            else
            {
                if ((Me.MovingToTilePosition - PlannedTargets[0]).Y != 0)
                {
                    CollIsVertical = true;
                }
            }

            List<Vector2> Poss1 = new List<Vector2>();
            List<Vector2> Poss2 = new List<Vector2>();

            if (IsInStraightLine(PlannedTargets, Math.Max(AHitsBhere - 2, 0), Math.Min(AHitsBhere + 2, PlannedTargets.Count - 1)))
            {
                try
                {
                    if (CollIsVertical)
                    {

                        for (int I = -2; I <= 2; I++)
                        {
                            Poss1.Add((PlannedTargets[AHitsBhere + I]) + new Vector2(1, 0));
                            Poss2.Add((PlannedTargets[AHitsBhere + I]) + new Vector2(-1, 0));
                        }

                    }
                    else
                    {

                        for (int I = -2; I <= 2; I++)
                        {
                            Poss1.Add((PlannedTargets[AHitsBhere + I]) + new Vector2(0, 1));
                            Poss2.Add((PlannedTargets[AHitsBhere + I]) + new Vector2(0, -1));
                        }
                    }
                    if (CollisionCheck.Instance.CheckListBool(map.Collision.CMap, Poss1))//if the first option is valid...
                    {
                        Diversion = CalculateAvoidSolution(Poss1, AHitsBhere, 2, out WhenPlanShouldBeInserted, out WhenPlanShouldEndBefore);

                        InsertPlan(Diversion, 1, true, WhenPlanShouldBeInserted, WhenPlanShouldEndBefore);
                        return true;



                    }
                    else if (CollisionCheck.Instance.CheckListBool(map.Collision.CMap, Poss2))//if the second option is valid
                    {
                        Diversion = CalculateAvoidSolution(Poss2, AHitsBhere, 2, out WhenPlanShouldBeInserted, out WhenPlanShouldEndBefore);
                        InsertPlan(Diversion, 1, true, WhenPlanShouldBeInserted, WhenPlanShouldEndBefore);
                        return true;
                    }
                }
                catch (ArgumentOutOfRangeException)
                {

                }
            }
            
        
            //Doesn't seem to be a solution without "pulling in somewhere". Fail.
            WhenPlanShouldBeInserted = WhenPlanShouldEndBefore = 0;
            Diversion = new List<Vector2>();
            return false;
        }

        protected bool GetOutOfTheWayOf_B(Vector2 CollLoc, List<Vector2> B_Moves, Vector2 B_Loc, int AhitsBHere, int BhitsAhere, int B_index, int A_index)
        {
            Vector2 LatestDiversion = CalculateLatestDiversion(PlannedTargets, B_Moves,B_Loc, AhitsBHere, BhitsAhere, out List<Vector2> B_LocationsNearCrash, out int LTime);
            List<Vector2> Possible_LayBys = new List<Vector2>();
            List<Vector2> Nextpossible = new List<Vector2>
            {
                LatestDiversion + new Vector2(1, 0),
                LatestDiversion + new Vector2(-1, 0),
                LatestDiversion + new Vector2(0, 1),
                LatestDiversion + new Vector2(0, -1)
            };

            List<Vector2> OldPossible = new List<Vector2>
            {
                LatestDiversion
            };

            while (Possible_LayBys.Count < 1)
            {
                Possible_LayBys = new List<Vector2>();
                Possible_LayBys.AddRange(Nextpossible);
                Possible_LayBys = CollisionCheck.Instance.FilterList(map.Collision.CMap, Possible_LayBys);
                Possible_LayBys = ListMethod.FilterBOutOfA(Possible_LayBys, B_Moves);

                if (Possible_LayBys.Count > 0)
                {
                    if (Possible_LayBys.Count == 1)
                    {

                        if (Pathfinding.GetToLocation(Possible_LayBys[0], LatestDiversion, out List<Vector2> PlanBeforeStop, map, B_LocationsNearCrash))
                        {
                            return CalcuateLaybyLogistics(PlanBeforeStop,Me.MovingToTilePosition,  LatestDiversion, LTime, B_Moves, B_index, A_index);
                        }
                        else
                        {
                            Possible_LayBys = new List<Vector2>();//increments and tries again
                        }
                    }
                    else
                    {//multiple possibilities
                        List<Vector2> BestPlan = new List<Vector2>();
                        int LengthofBest = int.MaxValue;

                        for (int I = 0; I < Possible_LayBys.Count; I++)
                        {
                            if (Pathfinding.GetToLocation(Possible_LayBys[I], LatestDiversion, out List<Vector2> CurrentPlan, map, B_LocationsNearCrash))
                            {
                                if (CurrentPlan.Count < LengthofBest)
                                {
                                    LengthofBest = CurrentPlan.Count;
                                    BestPlan = CurrentPlan;
                                }
                            }
                        }
                        if(LengthofBest < int.MaxValue)//if a valid route was found...
                        {
                            return CalcuateLaybyLogistics(BestPlan, Me.MovingToTilePosition,LatestDiversion,LTime, B_Moves, B_index, A_index);
                        }
                        else
                        {//none of the supposedly valid layby routes were actually reachable
                            Possible_LayBys = new List<Vector2>();
                        }
                    }

                }

                if(Nextpossible.Count == 0)
                {
                    return false;
                }

                OldPossible.AddRange(Nextpossible);
                List<Vector2> LastPossible = new List<Vector2>();
                LastPossible.AddRange(Nextpossible);
                Nextpossible = new List<Vector2>();
                foreach (Vector2 Loc in LastPossible)
                {
                    if (!Nextpossible.Contains(Loc + new Vector2(1, 0)) && !OldPossible.Contains(Loc + new Vector2(1, 0)) && Loc.X >= 0 && Loc.Y >= 0 && Loc.X < map.Size.X && Loc.Y < map.Size.Y)
                    {
                        Nextpossible.Add(Loc + new Vector2(1, 0));
                    }
                    if (!Nextpossible.Contains(Loc + new Vector2(-1, 0)) && !OldPossible.Contains(Loc + new Vector2(-1, 0)) && Loc.X >= 0 && Loc.Y >= 0 && Loc.X < map.Size.X && Loc.Y < map.Size.Y)
                    {
                        Nextpossible.Add(Loc + new Vector2(-1, 0));
                    }
                    if (!Nextpossible.Contains(Loc + new Vector2(0, 1)) && !OldPossible.Contains(Loc + new Vector2(0, 1)) && Loc.X >= 0 && Loc.Y >= 0 && Loc.X < map.Size.X && Loc.Y < map.Size.Y)
                    {
                        Nextpossible.Add(Loc + new Vector2(0, 1));
                    }
                    if (!Nextpossible.Contains(Loc + new Vector2(0, -1)) && !OldPossible.Contains(Loc + new Vector2(0, -1)) && Loc.X >= 0 && Loc.Y >= 0 && Loc.X < map.Size.X && Loc.Y < map.Size.Y)
                    {
                        Nextpossible.Add(Loc + new Vector2(0, -1));
                    }
                }
            }
            return false;//unreachable, but restricts error

        }

        private static Vector2 CalculateLatestDiversion(List<Vector2> MyMoves, List<Vector2> TheirMoves, Vector2 TheirLoc, int I_Hit_Them, int They_Hit_Me, out List<Vector2> LocationsNearCrash, out int LatestDiversionTime)
        {
            LocationsNearCrash = new List<Vector2>();
            //Add the locations before the crash

            //if very close to occuring, add their actual location as well as their planned targets
            if (They_Hit_Me < 2)
            {
                LocationsNearCrash.Add(TheirLoc);
            }
            for (int I = Math.Min(2, They_Hit_Me); I > 0; I--)//TheyHitMe also refers to the number of moves the enemy will make before reaching us, as its zero index
            {
                LocationsNearCrash.Add(TheirMoves[They_Hit_Me - I]);
            }

            if (I_Hit_Them - 1 < 0)
            {
                LatestDiversionTime = 0;
                return MyMoves[0];
            }
            else if(I_Hit_Them - 1 ==0)//if its in 2 tiles
                
            {
                LocationsNearCrash.Add(MyMoves[I_Hit_Them]);//add the collision as it won't needed to be the latest diversion
                LatestDiversionTime = 0;
                return MyMoves[0];
            }
            else
            {//it's further away
                LocationsNearCrash.Add(MyMoves[I_Hit_Them]);//add the collision as it won't needed to be the latest diversion
                LocationsNearCrash.Add(MyMoves[I_Hit_Them - 1]);//add the one before for safety and fluidity as you van spare the tile
                LatestDiversionTime = Math.Max(I_Hit_Them - 2, 0);
                return MyMoves[LatestDiversionTime];
            }

        }

        private bool CalcuateLaybyLogistics(List<Vector2> PlanBeforeStop, Vector2 CurrentLoc, Vector2 SplitOffPoint, int SplitOff_time, List<Vector2> B_Moves, int B_index, int A_index)
        {
            //add the location of the split-off to the diversion so it's a complete route when flipped
            List<Vector2> PlanBeforeStopPlusStartLocation = new List<Vector2>() { SplitOffPoint };
            PlanBeforeStopPlusStartLocation.AddRange(PlanBeforeStop);
            List<Vector2> FullPlanBeforeStop = new List<Vector2>();
            FullPlanBeforeStop.AddRange(PlannedTargets);
            FullPlanBeforeStop.RemoveRange(SplitOff_time, (PlannedTargets.Count - (SplitOff_time)));
            FullPlanBeforeStop.AddRange(PlanBeforeStopPlusStartLocation);
           
            //flip to give the route back to the original route from the layby
            List<Vector2> PlanAfterStop = new List<Vector2>();
            PlanAfterStop.AddRange(PlanBeforeStopPlusStartLocation);
            PlanAfterStop.Reverse();

            //find where the latest point of the original planned route that can be rejoined as part of the journey back from the layby
            if (ListMethod.ReturnIfListsShareTerm(PlanAfterStop, PlannedTargets, out int FirstInstanceA, out int LastInstancePLanned))
            {//if this is possible...
                PlanAfterStop.RemoveRange(FirstInstanceA, PlanAfterStop.Count - FirstInstanceA);//cut off the rejoin plan after it connects to the original route.
                if (LastInstancePLanned > 0)//if it's cutting out part of the route doing this...
                {
                    plannedTargets.RemoveRange(0, LastInstancePLanned);
                    plannedActions.RemoveRange(0, LastInstancePLanned);
                    plannedActionsMB.RemoveRange(0, LastInstancePLanned);
                }
                backupTargets = new List<Vector2>();
                backupActions = new List<int>();
                backupActionsMB = new List<bool>();

                backupTargets.AddRange(PlanAfterStop);
                for (int I = 0; I < PlanAfterStop.Count; I++)
                {
                    backupActions.Add(1);
                    backupActionsMB.Add(true);
                }
                BackupTargets.AddRange(plannedTargets);
                BackupActions.AddRange(plannedActions);
                backupActionsMB.AddRange(plannedActionsMB);

                plannedTargets = FullPlanBeforeStop;
                plannedActions = new List<int>();
                plannedActionsMB = new List<bool>();
                for (int I = 0; I < plannedTargets.Count; I++)
                {
                    plannedActions.Add(1);
                    plannedActionsMB.Add(true);
                }
                PlanAimID = 3;
                if (ListMethod.ReturnIfListsShareTerm(backupTargets, B_Moves, out int FA, out int LB))
                {
                    AIMoveManager.Instance.AddNewPassCall(B_index, A_index, backupTargets[FA],PlannedTargets[PlannedTargets.Count-1]);
                    return true;
                }
                else
                {
                    throw new Exception("How has this happened?");
                }
            }
            else
            {
                return false;
            }

        }

        private static bool IsInStraightLine(List<Vector2> Path, int Start, int Stop)//includes both the start and stop values given
        {
            Vector2 PrimaryMove = Path[Start + 1] - Path[Start];

            for(int I = 1; I <= Stop - Start; I++)
            {
                Vector2 ThisMove = Path[Start + I] - Path[Start + I - 1];

                if(ThisMove != PrimaryMove && ThisMove != Vector2.Zero)
                {
                    return false;
                }
            }
            return true;
        }

        private List<Vector2> CalculateAvoidSolution(List<Vector4> Phases, int ChangePhase, bool ChangePhaseIsVertical, out int WhenPlanShouldBeInserted, out int WhenPlanShouldEndBefore)
        {
            List<Vector2> Alterations = new List<Vector2>();
            if (ChangePhaseIsVertical)
            {
                for (int I = 0; MathMethod.Modulus(I) <= MathMethod.Modulus(Phases[ChangePhase].Y); I += Math.Sign(Phases[ChangePhase].Y))
                {
                    Alterations.Add(new Vector2(Phases[ChangePhase].Z, Phases[ChangePhase].W) + new Vector2(0, I));
                }
                Vector2 LocBeforeAlteration, LocAfterAlteration;
                if (ChangePhase > 0)
                {
                    LocBeforeAlteration = new Vector2(Phases[ChangePhase - 1].Z + Phases[ChangePhase-1].X - Math.Sign(Phases[ChangePhase-1].X), Phases[ChangePhase - 1].W);
                }
                else
                {
                    //if the change phase is the first, the first location is where they are right now
                    LocBeforeAlteration = Me.MovingToTilePosition;
                }

                if(ChangePhase < Phases.Count - 1)
                {
                     LocAfterAlteration = new Vector2(Phases[ChangePhase + 1].Z + Math.Sign(Phases[ChangePhase+1].X), Phases[ChangePhase + 1].W );
                }
                else
                {//if the last phase, make the loc after alteration the last tile, derived by adding the movement of the last phase to its start location
                    LocAfterAlteration = new Vector2(Phases[ChangePhase].Z + Phases[ChangePhase].X, Phases[ChangePhase].W + Phases[ChangePhase].Y);
                }
               
                
                WhenPlanShouldBeInserted = PlannedTargets.IndexOf(LocBeforeAlteration);
                WhenPlanShouldEndBefore = PlannedTargets.IndexOf(LocAfterAlteration);
                
                return Alterations;
            }
            else
            {//changephase is horizontal
                for (int I = 0; MathMethod.Modulus(I) <= MathMethod.Modulus(Phases[ChangePhase].X); I += Math.Sign(Phases[ChangePhase].X))
                {
                    Alterations.Add(new Vector2(Phases[ChangePhase].Z, Phases[ChangePhase].W) + new Vector2(I,0 ));
                }
                Vector2 LocBeforeAlteration, LocAfterAlteration;
                if (ChangePhase > 0)
                {
                    LocBeforeAlteration = new Vector2(Phases[ChangePhase - 1].Z, Phases[ChangePhase - 1].W +  Phases[ChangePhase-1].Y - Math.Sign(Phases[ChangePhase-1].Y));
                    WhenPlanShouldBeInserted = PlannedTargets.IndexOf(LocBeforeAlteration);
                }
                else
                {//if the change phase is the first, the first location is where they are right now
                    LocBeforeAlteration = Me.MovingToTilePosition;
                    WhenPlanShouldBeInserted = 0;
                }

                if(ChangePhase < Phases.Count - 1)
                {
                    LocAfterAlteration = new Vector2(Phases[ChangePhase + 1].X, Phases[ChangePhase + 1].Y + Math.Sign(Phases[ChangePhase+1].W));
                    WhenPlanShouldEndBefore = PlannedTargets.IndexOf(LocAfterAlteration);
                }
                else
                {//if the last phase, make the loc after alteration the last tile, derived by adding the movement of the last phase to its start location
                    LocAfterAlteration = new Vector2(Phases[ChangePhase].Z + Phases[ChangePhase].X, Phases[ChangePhase].W + Phases[ChangePhase].Y);
                    WhenPlanShouldEndBefore = PlannedTargets.Count;
                }
                return Alterations;
            }



        }

        private List<Vector2> CalculateAvoidSolution(List<Vector2> Insert, int AHitsBHere, int BeforeAfterCollOffset, out int WhenPlanShouldBeInserted, out int WhenPlanShouldEndBefore)
        {
            WhenPlanShouldBeInserted = AHitsBHere - BeforeAfterCollOffset;
            WhenPlanShouldEndBefore = AHitsBHere + BeforeAfterCollOffset;

            return Insert;
        }

        public bool WarnOfFriendlyCollision(int SuperiorInd, int YourInd, Vector2 Location, List<Vector2> OthersMovement, Vector2 OthersLocation, int YourMovesTillOccurence, int TheirMovesTillOccurence)
        {

            if (!CreatePlanToAvoid_B(Location, OthersMovement, YourMovesTillOccurence, SuperiorInd))//first, try insering a plan to divert you
            {
                //if even this is impossible, find somewhere to "pull into" to let the other past, and inform the AIMoveManager that you are waiting for a signal that the other has passed you to continue
                if (!GetOutOfTheWayOf_B(Location, OthersMovement, OthersLocation, YourMovesTillOccurence, TheirMovesTillOccurence, SuperiorInd, YourInd))
                {
                    //nonw of the solutions worked, avoidance failed
                    return false;
                }
                else
                {
                    return true;
                }
            } 
            else
            {
                return true;
            }


            //you may even have to double back to find somewhere.
        }

        public void InsertPlan(List<Vector2> InsertTarget, List<int> InsertAction, List<bool> InsertActionMB, int PlaceStartAfter, int PlaceEndBefore)
        {
           
            plannedTargets.RemoveRange(PlaceStartAfter + 1, PlaceEndBefore-(PlaceStartAfter+1));
            plannedActions.RemoveRange(PlaceStartAfter + 1, PlaceEndBefore - (PlaceStartAfter + 1));
            plannedActionsMB.RemoveRange(PlaceStartAfter + 1, PlaceEndBefore - (PlaceStartAfter + 1));

            PlannedTargets.InsertRange(PlaceStartAfter + 1, InsertTarget);
            PlannedActions.InsertRange(PlaceStartAfter + 1, InsertAction);
            PlannedActionsMB.InsertRange(PlaceStartAfter + 1, InsertActionMB);
        }

        public void InsertPlan(List<Vector2> InsertTarget, int constantInsertAction, bool constantInsertActionMB, int PlaceStartAfter, int PlaceEndBefore)
        {
            List<int> CreatedList = new List<int>();
            List<bool> CreastedListMB = new List<bool>();
            for(int I =0; I < InsertTarget.Count; I++)
            {
                CreatedList.Add(constantInsertAction);
                CreastedListMB.Add(constantInsertActionMB);
            }

            InsertPlan(InsertTarget, CreatedList, CreastedListMB, PlaceStartAfter, PlaceEndBefore);
        }

        private void RemovePartOfPlan(int FromAndIncluding, int ToAndIncluding)
        {
            plannedTargets.RemoveRange(FromAndIncluding, ToAndIncluding);
            plannedActions.RemoveRange(FromAndIncluding, ToAndIncluding);
            plannedActionsMB.RemoveRange(FromAndIncluding, ToAndIncluding);
        }

        private void RemovePartOfPlan(int FromAndIncluding, bool IsToEnd)
        {
            plannedTargets.RemoveRange(FromAndIncluding, PlannedTargets.Count - 1);
            plannedActions.RemoveRange(FromAndIncluding, PlannedTargets.Count - 1);
            plannedActionsMB.RemoveRange(FromAndIncluding, PlannedTargets.Count - 1);
        }

        private void RemovePartOfPlan(int FromStart__UpToAndIncluding)
        {
            plannedTargets.RemoveRange(0, FromStart__UpToAndIncluding);
            plannedActions.RemoveRange(0, FromStart__UpToAndIncluding);
            plannedActionsMB.RemoveRange(0, FromStart__UpToAndIncluding);
        }

        public bool GiveGoAhead()//indicates whether it was successful
        {
            if (WaitingforGoAhead)
            {
                GoAhead = true;
                WaitingforGoAhead = false;
                return true;
            }
            else
            {
                return false;
            }
            

        }

        public void CancelPlan()
        {
            plannedActions.Clear();
            plannedTargets.Clear();
            plannedActionsMB.Clear();
        }

        public void GiveHesitationPlan(out Vector2 Target, out int Action, out bool IsMB)
        {
            Target = Me.TilePosition;
            Action = 0;
            IsMB = false;
        }
    }
}
