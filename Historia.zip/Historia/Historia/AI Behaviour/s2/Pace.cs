﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace Historia.AI_Behaviour.s2
{
    class Pace:Suspicious_Behaviour
    {
        public override void Scheme()
        {
            if (CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, map.BC.BC, Me.TilePosition+Me.Direction))
            {
                AddToPlan(Me.TilePosition+Me.Direction, 1, true);
               //walk forwards
                return;
            }
            else if (CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, map.BC.BC, Me.TilePosition - Me.Direction))//behind
            {
                AddToPlan(Me.TilePosition-Me.Direction, 1, true);
                //turn and walk backwards
                return;
            }
            else
            {
                AddToPlan(Me.TilePosition, 0, false);
               
            }
        }
    }
}
