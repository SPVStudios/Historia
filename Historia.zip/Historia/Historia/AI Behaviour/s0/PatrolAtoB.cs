﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace Historia.AI_Behaviour.s0
{
    public class PatrolAtoB:Oblivious_Behaviour
    {
        public override void LoadContent(ref Enemy Me, Map map)
        {
            base.LoadContent(ref Me, map);
            Create_Standard_Patrol(true);
        }

        public override void Scheme()
        {
            Plan_Journey_ToNextWaypoint(); 
        }
    }
}
