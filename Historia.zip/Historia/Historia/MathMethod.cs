﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Historia
{
    public static class MathMethod
    {
        public static double Average(List<int> Numbers)
        {
            int Total = 0;
            foreach(int Num in Numbers)
            {
                Total += Num;
            }
            return Total / Numbers.Count;
        }

        public static int ReturnIndexBiggest(List<int> Numbers)
        {
            int BiggestNum = Numbers[0];
            int BiggestIndex = 0;
            for(int N = 1; N < Numbers.Count;N++)
            {
                if (Numbers[N] > BiggestNum)
                {
                    BiggestNum = Numbers[N];
                    BiggestIndex = N;
                }
            }
            return BiggestIndex;
        }

        public static int ReturnIndexBiggest(List<double> Numbers)
        {
            double BiggestNum = Numbers[0];
            int BiggestIndex = 0;
            for (int N = 1; N < Numbers.Count; N++)
            {
                if (Numbers[N] > BiggestNum)
                {
                    BiggestNum = Numbers[N];
                    BiggestIndex = N;
                }
            }
            return BiggestIndex;
        }

        public static int ReturnIndexSmallest(List<int> Numbers)
        {
            int SmallestNum = Numbers[0];
            int SmallestIndex = 0;
            for (int N = 1; N < Numbers.Count; N++)
            {
                if (Numbers[N] < SmallestNum)
                {
                    SmallestNum = Numbers[N];
                    SmallestIndex = N;
                }
            }
            return SmallestIndex;
        }

        public static int ReturnIndexSmallest(List<double> Numbers)
        {
            double SmallestNum = Numbers[0];
            int SmallestIndex = 0;
            for (int N = 1; N < Numbers.Count; N++)
            {
                if (Numbers[N] < SmallestNum)
                {
                    SmallestNum = Numbers[N];
                    SmallestIndex = N;
                }
            }
            return SmallestIndex;
        }

        public static int Modulus(int PosOrNegNum)
        {
            return Math.Max(PosOrNegNum, -PosOrNegNum);
        }

        public static double Modulus(double PosOrNegNum)
        {
            return Math.Max(PosOrNegNum, -PosOrNegNum);
        }

        public static decimal Modulus(decimal PosOrNegNum)
        {
            return Math.Max(PosOrNegNum, -PosOrNegNum);
        }

    }
}
