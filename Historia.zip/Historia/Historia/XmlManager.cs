﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace Historia
{
    /* <Summary>
     * this code takes any data from an xml file, and loads the data found in that xml file into the variables of the class
     * that called it.*/

    public class XmlManager<T>//This "T" is the placeholder for a specific type that is defined when this is called.
        //It is called a "Generic Type"
    {
        public Type Type;

        public XmlManager()
        {
            Type = typeof(T);
        }

        public T Load(string path)
        {
            T instance;
            using (TextReader reader = new StreamReader(path))
            {
                XmlSerializer xml = new XmlSerializer(Type);
                instance = (T)xml.Deserialize(reader);//The object must be converted to whatver type "T" is first
            }
            return instance;
        }

        public void Save(string Path, object obj)
        {
            using (TextWriter Writer = new StreamWriter(Path))
            {
                XmlSerializer xml = new XmlSerializer(Type);
                xml.Serialize(Writer, obj);
            }
        }





    }
}
