﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace Historia
{
    class InputManager
    {
        KeyboardState currentKeyState, PreviousKeyState;

        private static InputManager instance;//this creates a private instance of the class to allow InputManager to be used
        //as a "singleton" class - a class that can only have one version of itself in existence.
        public static InputManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new InputManager();

                }
                return instance;//SINGLETON - creates a new instance of the class to be called by other classes ONLY IF one does not yet exist.
            }
        }

        public void Update(GameTime gameTime)
        {
            PreviousKeyState = currentKeyState;//old keys pressed become saved as the previous KeyState
            if (ScreenManager.Instance.IsTransitioning == false)
            {
                currentKeyState = Keyboard.GetState();//this prevents input being taken when transitioning screens
            }
        }

        public bool KeyPressed(params Keys[] keys)
        {
            foreach (Keys key in keys)
            {
                if (currentKeyState.IsKeyDown(key) && PreviousKeyState.IsKeyUp(key))//if it was only just PRESSED down
                {
                    return true;
                }
            }
            return false;
        }

        public bool KeyReleased(params Keys[] keys)
        {
            foreach (Keys key in keys)
            {
                if (currentKeyState.IsKeyUp(key) && PreviousKeyState.IsKeyDown(key))//if it was only just let go of
                {
                    return true;
                }
            }
            return false;
        }

        public bool KeyDown(params Keys[] keys)
        {
            foreach (Keys key in keys)
            {
                if (currentKeyState.IsKeyDown(key))//if it is pressed down.
                {
                    return true;
                }
            }
            return false;
        }

        public Keys DirectionKey
        {
            get
            {
              
                if (Instance.KeyDown(Keys.W))
                {
                    return Keys.W;
                }
                else if (Instance.KeyDown(Keys.S))
                {
                    return Keys.S;
                }
                else if (Instance.KeyDown(Keys.A))
                {
                    return Keys.A;
                }
                else if (Instance.KeyDown(Keys.D))
                {
                    return Keys.D;
                }
                else
                {
                    return Keys.Sleep;//acting as a  null value
                }
            }
        }

        public Keys ActionKey
        {
            get
            {
                if (Instance.KeyDown(Keys.R))//Facing Only
                {
                    return Keys.R;
                }
                else if (Instance.KeyDown(Keys.Space))//Attacking
                {
                    return Keys.Space;
                }
                else if (Instance.KeyDown(Keys.C))//Dodge
                {
                    return Keys.C;
                }
                else if (Instance.KeyDown(Keys.B))//Block
                {
                    return Keys.B;
                }
                else if (Instance.KeyDown(Keys.V))//Parry
                {
                    return Keys.V;
                }
                else if (Instance.KeyDown(Keys.N))//SP3
                {
                    return Keys.N;
                }
                else if (Instance.KeyDown(Keys.G))//SP1
                {
                    return Keys.G;
                }
                else if (Instance.KeyDown(Keys.H))//SP2
                {
                    return Keys.H;
                }
                else if (Instance.KeyDown(Keys.F))//Interact
                {
                    return Keys.F;
                }

                else
                {
                    return Keys.Sleep;//acting as a  null value
                }
            }
        }

        public Keys ModifierKey
        {
            get
            {
                if (Instance.KeyDown(Keys.LeftControl))//'mellows' actions
                {
                    return Keys.LeftControl;
                }
                else if (Instance.KeyDown(Keys.LeftShift))//intensifies actions (ie walk-run, attack-heavyattk)
                {
                    return Keys.LeftShift;
                }
                else
                {
                    return Keys.Sleep;//acting as a  null value
                }
            }
        }
    }
}
