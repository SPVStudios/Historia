﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace Historia.ObjectFillMethods
{
    class SingleTopLeftObject:ObjectFillMethod//creates a single object in the top-left corner of a room.
    {
        public override void FillRoom(Room Room, ref List<MapObject> Created, List<ObjectTileSet> Available, Random D, ref List<Rectangle> FilledAreas)
        {
            int ChosenTileSet = FindTileSetIndex(Available, D);

            int ChosenInt = D.Next(0, Available[ChosenTileSet].RowSchemas.Count - 1);
            
            MapObject Solo = new MapObject(Available[ChosenTileSet], ChosenTileSet, ChosenInt, new Vector2(Room.Location[0].X, Room.Location[0].Y),D);

            if (!RectMethod.TileIntersects(Solo.FullTileLocation, FilledAreas))
            {
                Created.Add(Solo);
                FilledAreas.Add(Solo.FullTileLocation);
            }
        }
    }
    public class SingleRandomObject : ObjectFillMethod
    {
        public override void FillRoom(Room Room, ref List<MapObject> Created, List<ObjectTileSet> Available, Random D, ref List<Rectangle> FilledAreas)
        {
            int ChosenTileSet = FindTileSetIndex(Available,true, D);

            int ChosenInt = D.Next(0, Available[ChosenTileSet].RowSchemas.Count - 1);
            Vector2 ObjectSize = Available[ChosenTileSet].RowSchemas[ChosenInt].Dimensions;
            if (ObjectFits(Room.Location[0], ObjectSize))
            {
                int ObjectStartX = D.Next(Room.Location[0].X, Room.Location[0].Right - (int)ObjectSize.X);
                int ObjectStartY = D.Next(Room.Location[0].Y, Room.Location[0].Bottom - (int)ObjectSize.Y);

                MapObject Solo = new MapObject(Available[ChosenTileSet], ChosenTileSet, ChosenInt, new Vector2(ObjectStartX, ObjectStartY), D);

                if (!RectMethod.TileIntersects(Solo.FullTileLocation, FilledAreas))
                {
                    Created.Add(Solo);
                    FilledAreas.Add(Solo.FullTileLocation);
                }
            }
        }

    }
}
