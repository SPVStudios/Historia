﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.IO;
using System.Drawing;

namespace Historia.ObjectFillMethods
{
    public class Installation:ObjectFillMethod
    {
        



        public override void FillRoom(Room Room, ref List<MapObject> Created, List<ObjectTileSet> Available, Random D, ref List<Rectangle> FilledAreas)
        { 
            //no need to adjust for Overlaps - handled by rectanglefill
           
            Rectangle RoomLoc = Room.Location[0];
            if(RoomLoc.Width > 4 && RoomLoc.Y > 4)
            {
               
                Rectangle InstallationBounds = RectMethod.CreateRandomRectangle(RoomLoc,D);
                List<Rectangle> Installation = RectMethod.ReturnBoxyShape(InstallationBounds, D);

                
                int ChosenInt = FindTileSetIndex(Available, true, D);
                ObjectTileSet ChosenTileSet = Available[ChosenInt];
               

                foreach (Rectangle Part in Installation)
                {
                    Created.AddRange(FillWholeRectangle(Part, ChosenTileSet, ChosenInt, D, ref FilledAreas,true));
                }
                
            }
            
        }
    }
}
