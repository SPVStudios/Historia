﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Historia.ObjectFillMethods
{
    class Full : ObjectFillMethod
    {
        public override void FillRoom(Room Room, ref List<MapObject> Created, List<ObjectTileSet> Available, Random D, ref List<Rectangle> FilledAreas)
        {
            List<Rectangle> bitstofill = ReboundMultiforConstraints(Room.Location[0], FilledAreas);
            
            int ChosenInt = FindTileSetIndex(Available, D);
            ObjectTileSet ChosenTileSet = Available[ChosenInt];

            foreach(Rectangle bit in bitstofill)
            {
                Created.AddRange(FillWholeRectangle(bit, ChosenTileSet, ChosenInt, D, ref FilledAreas));
            }

            FilledAreas.Add(Room.Location[0]);

        }

    }
}
