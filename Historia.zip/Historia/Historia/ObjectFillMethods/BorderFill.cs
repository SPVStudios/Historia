﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Historia.ObjectFillMethods
{
    public class BorderFill:ObjectFillMethod
    {
        public override void FillRoom(Room Room, ref List<MapObject> Created, List<ObjectTileSet> Available, Random D, ref List<Rectangle> FilledAreas)
        {
            List<MapObject> ObjectsToAdd = new List<MapObject>();
            Rectangle RoomLoc = Room.Location[0];
            int BorderHeight = ((RoomLoc.Height - 1) / 10) + 1;
            int BorderWidth = ((RoomLoc.Width - 1) / 10) + 1;
            int ChosenInt = FindTileSetIndex(Available,false, D);
            ObjectTileSet ChosenTileSet = Available[ChosenInt];
            
            //no need to adjust impact area; Overlaps handled in FillRect method.


            if(RoomLoc.Height >= 6 && RoomLoc.Width >= 6)//should be >= 5, but is 5 >= The actual height of room - 1
            {//big enough for border round the outside before items
                ObjectsToAdd.AddRange(FillWholeRectangle(
                    new Rectangle(RoomLoc.X + BorderWidth, RoomLoc.Y + BorderHeight, RoomLoc.Width - (2*BorderWidth), BorderHeight), ChosenTileSet, ChosenInt, D, ref FilledAreas));

                ObjectsToAdd.AddRange(FillWholeRectangle(
                    new Rectangle(RoomLoc.X + BorderWidth, RoomLoc.Y + (2* BorderHeight),// +1: to be placed below the first rectangle, not overlapping it
                    BorderWidth, RoomLoc.Height - (4 * BorderHeight)),//-1-1; cuts off overlap with top rect and bottom rect
                    ChosenTileSet, ChosenInt, D, ref FilledAreas));

                ObjectsToAdd.AddRange(FillWholeRectangle(
                    new Rectangle(RoomLoc.X + BorderWidth, RoomLoc.Bottom - (2 * BorderHeight), RoomLoc.Width-(2*BorderWidth), BorderHeight),
                    ChosenTileSet, ChosenInt, D, ref FilledAreas));

                ObjectsToAdd.AddRange(FillWholeRectangle(
                    new Rectangle(RoomLoc.Right - (2* BorderWidth), RoomLoc.Y + (2*BorderHeight),
                    BorderWidth, RoomLoc.Height - (4*BorderHeight)),
                    ChosenTileSet, ChosenInt, D, ref FilledAreas));
            }
            else
            {//just the outside tiles. The Border's Widths and Heights here are also always equal to 1, as the room isnt't big enough.
                ObjectsToAdd.AddRange(FillWholeRectangle(
                    new Rectangle(RoomLoc.X, RoomLoc.Y, RoomLoc.Width, 1), ChosenTileSet, ChosenInt, D, ref FilledAreas));

                ObjectsToAdd.AddRange(FillWholeRectangle(
                    new Rectangle(RoomLoc.X, RoomLoc.Y + 1,//to be placed below the first rectangle not overlapping it
                    1, RoomLoc.Height - 2),//-1-1; cuts off overlap with top rect and bottom rect
                    ChosenTileSet,ChosenInt, D, ref FilledAreas));

                ObjectsToAdd.AddRange(FillWholeRectangle(
                    new Rectangle(RoomLoc.X, RoomLoc.Bottom - 1, RoomLoc.Width,1),
                    ChosenTileSet, ChosenInt, D, ref FilledAreas));

                ObjectsToAdd.AddRange(FillWholeRectangle(
                    new Rectangle(RoomLoc.Right - 1, RoomLoc.Y + 1,//to be placed below the first rectangle not overlapping it
                    1, RoomLoc.Height - 2),//-1-1; cuts off overlap with top rect and bottom rect
                    ChosenTileSet, ChosenInt, D, ref FilledAreas));
            }
            Created.AddRange(ObjectsToAdd);

        }
    }
}
