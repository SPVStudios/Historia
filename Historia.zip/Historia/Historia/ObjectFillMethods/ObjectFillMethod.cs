﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Historia
{
    public abstract class ObjectFillMethod
    {
        public bool GeneralPurpose;
        public string SpecificPurpose;

        public abstract void FillRoom(Room Room, ref List<MapObject> Created, List<ObjectTileSet> Available, Random D, ref List<Rectangle> FilledAreas);

        protected static Rectangle ReboundLargeSoloforConstraints(Rectangle originalBound, List<Rectangle> Constraints)
        {
            List<Rectangle> bits = new List<Rectangle>() { originalBound };
            foreach(Rectangle constraint in Constraints)
            {
                List<Rectangle> Passed = new List<Rectangle>();
                foreach (Rectangle bit in bits)
                {
                    Passed.AddRange(RectMethod.Splice(constraint, bit));
                }
                bits = Passed;
            }
            //with a list of areas that satisfy all constraints, you'll now choose the biggest to use for this object fill method.
            int biggestsize = 0;
            int biggestindex = -1;
            for(int I = 0; I < bits.Count; I++)
            {
                int size = bits[I].Width * bits[I].Height;
                if (size > biggestsize)
                {
                    biggestsize = size;
                    biggestindex = I;
                }
            }
            return bits[biggestindex];

        }

        protected static Rectangle ReboundRandSoloforConstraints(Rectangle originalBound, List<Rectangle> Constraints, Random D)
        {
            List<Rectangle> bits = new List<Rectangle>() { originalBound };
            foreach (Rectangle constraint in Constraints)
            {
                List<Rectangle> Passed = new List<Rectangle>();
                foreach (Rectangle bit in bits)
                {
                    Passed.AddRange(RectMethod.Splice(constraint, bit));
                }
                bits = Passed;
            }
            //with a list of areas that satisfy all constraints, you'll now choose the bigger-than-average to 
            //select at random.
            int smallestsize = 10000;
            int biggestsize=0;
            for (int I = 0; I < bits.Count; I++)
            {
                int size = bits[I].Width * bits[I].Height;
                if (size > biggestsize)
                {
                    biggestsize = size;
                    
                }
                else if(size < smallestsize)
                {
                    smallestsize = size;
                }
            }
            int cutoff = (smallestsize + biggestsize) / 2;

            //cycle throught these sizes to select only the larger shapes to continue
            List<Rectangle> goodbits = new List<Rectangle>();
            for(int I = 0; I < bits.Count; I++)
            {
                int size = bits[I].Width * bits[I].Height;
                if(size >= cutoff)
                {
                    goodbits.Add(bits[I]);
                }
            }
            int Chosen = D.Next(0, goodbits.Count - 1);
            return goodbits[Chosen];

        }
        
        protected static List<Rectangle>ReboundMultiforConstraints(Rectangle originalBound, List<Rectangle> Constraints)
        {
            List<Rectangle> bits = new List<Rectangle>() { originalBound };
            foreach (Rectangle constraint in Constraints)
            {
                List<Rectangle> Passed = new List<Rectangle>();
                foreach (Rectangle bit in bits)
                {
                    Passed.AddRange(RectMethod.Splice(constraint, bit));
                }
                bits = Passed;
            }
            //return the list of bits to fill up.
            return bits;
        }

        protected static List<MapObject> FillWholeRectangle(Rectangle Rect, ObjectTileSet Pieces, int whichTileSet, Random D, ref List<Rectangle> FilledAreas, bool IsUsingOverlapCheck)
        {
            List<Rectangle> Areas = new List<Rectangle>() { Rect };
            bool AnyNewArea = CheckAreaOverlap(ref Areas, FilledAreas);
            if (AnyNewArea)
            {
                List<MapObject> Placed = new List<MapObject>();
                foreach (Rectangle Area in Areas)
                {
                    Placed.AddRange(FillWholeRectangle(Area, Pieces, whichTileSet, D, ref FilledAreas));
                }
                return Placed;
            }
            return new List<MapObject>();
        }

        protected static List<MapObject> FillWholeRectangle(Rectangle Rect, ObjectTileSet Pieces, int whichTileSet, Random D, ref List<Rectangle> FilledAreas)
        {





            int numOfPieces = Pieces.RowSchemas.Count;


            Vector2 Origin = new Vector2(Rect.X, Rect.Y);

            List<MapObject> Placed = new List<MapObject>();

            bool[] stillValid = new bool[numOfPieces];

            for (int I = 0; I < numOfPieces; I++)
            {
                if (Pieces.RowSchemas[I].Dimensions.X > Rect.Width || Pieces.RowSchemas[I].Dimensions.Y > Rect.Height)
                {
                    stillValid[I] = false;
                }
                else
                {
                    stillValid[I] = true;
                }
            }

            int[,] TilesToGo = new int[Rect.Width, Rect.Height];

            Vector2 firstValidSpot = Vector2.Zero;

            //Create a list of integers referring to the index of the row schema it is from. THis will be used to weight all items equally
            //within a tileset.
            List<int> SchemaIndexes = new List<int>();
            for (int I = 0; I < Pieces.RowSchemas.Count; I++)
            {
                for (int P = 0; P < Pieces.RowSchemas[I].Instances; P++)
                {
                    SchemaIndexes.Add(I);
                }
            }

            // then continue with the rest of the rectangle.
            while (AnyValid(stillValid))
            {
                //select the next schema to use randomly. If the random selection is still valid, place it.
                int NextPiece = D.Next(0, SchemaIndexes.Count - 1);
                int I = SchemaIndexes[NextPiece];
                if (stillValid[I])
                {
                    bool OK = TryPlace
                        (
                        whichTileSet,
                        Pieces, I, ref Placed, ref TilesToGo,
                        ref firstValidSpot, Rect, Origin, D);


                    if (!OK)
                    {
                        stillValid[I] = false;
                        //remove all copies of this schema's number form the SchemaIndexes list.
                        for(int Z = 0; Z < SchemaIndexes.Count; Z++)
                        {
                            if(SchemaIndexes[Z] == I)
                            {
                                SchemaIndexes.RemoveAt(Z);
                                Z--;
                            }
                        }

                    }
                }
                else
                {
                    //remove all copies of this schema's number from the SchemaIndexes list.
                    for(int Z = 0; Z < SchemaIndexes.Count; Z++)
                        {
                        if (SchemaIndexes[Z] == I)
                        {
                            SchemaIndexes.RemoveAt(Z);
                            Z--;
                        }
                    }
                }

            }
            if (RectMethod.TileIntersects(Rect, FilledAreas))
            {
                Placed = FilterOverlaps(Placed, FilledAreas);
            }
            FilledAreas.Add(Rect);
            return Placed;
        }
            
        protected static bool AnyValid(bool[] Valid)
        {
            for(int I = 0; I < Valid.Length; I++)
            {
                if (Valid[I])
                {
                    return true;
                }
            }
            return false;
        }

        protected static bool TryPlace(int WhichTileSet, ObjectTileSet Pieces, int PieceIndex, ref List<MapObject> Placed,
            ref int[,] TilesToGo, ref Vector2 firstValidSpot, Rectangle Site, Vector2 Origin, Random D)
        {
            ///<Important>
            ///This Method does NOT work for complex shapes
            /// </Important>
            ObjectTileSet.ObjectRowSchema Piece = Pieces.RowSchemas[PieceIndex];

            for(int Y = (int)firstValidSpot.Y; Y < Site.Height - (Piece.Dimensions.Y - 1); Y++)//replacement for 'Y', seems bugged
            {
                for (int X = (int)firstValidSpot.X; X < Site.Width - (Piece.Dimensions.X - 1); X++)
                {
                    Vector2 status = PlaceHere(Piece, new Vector2(X, Y), TilesToGo);
                    if ( status == new Vector2(-1,-1))
                    {
                        //place the object, then return "true".

                        //Add to ObjectList
                        Placed.Add(new MapObject(Pieces, WhichTileSet, PieceIndex, new Vector2(X + Origin.X, Y + Origin.Y),D));
                        //TilesToGo + ObjectLocations
                        for (int P = 0; P < Piece.Dimensions.Y; P++)
                        {
                            int NextTTGValue;
                            if (X + (Piece.Dimensions.X) >= Site.Width)
                            {
                                if (Y + P + 1 >= Site.Height)
                                {
                                    NextTTGValue = 0;//end of the area, no further tiles to direct to.
                                }
                                else
                                {
                                    NextTTGValue = TilesToGo[0, Y + P + 1];//moves onto start of the the next row.
                                }
                            }
                            else
                            {
                                NextTTGValue = TilesToGo[X + (int)Piece.Dimensions.X, Y + P];//moves to the space on the right of this one.
                            }

                            for (int Q = 0; Q < Piece.Dimensions.X; Q++)
                            {

                                TilesToGo[X + Q, Y + P] = ((int)Piece.Dimensions.X - Q) + NextTTGValue;
                            }
                        }

                        //if FirstValidSpot falls in this region, move it along to the actual next FirstValidSpot
                        if (TilesToGo[(int)firstValidSpot.X, (int)firstValidSpot.Y]!= 0)
                        {
                            while (true)
                            {
                                firstValidSpot.X += TilesToGo[(int)firstValidSpot.X, (int)firstValidSpot.Y];
                                if (firstValidSpot.X >= Site.Width)
                                {
                                    firstValidSpot.X = 0;
                                    firstValidSpot.Y++;
                                }
                                try
                                {
                                    if (TilesToGo[(int)firstValidSpot.X, (int)firstValidSpot.Y] == 0)
                                    {
                                        break;
                                    }
                                }
                                catch(IndexOutOfRangeException)
                                {
                                    return true;
                                }
                            }
                        }

            
                        //return true
                        return true;
                    }
                    else
                    {
                        int TTGRef = TilesToGo[X + (int)status.X, Y + (int)status.Y];
                        X += (int)status.X + TTGRef;
                        //progress to the next possible spot.
                    }
                }
            }
            return false;
            
        }

        protected static Vector2 PlaceHere(ObjectTileSet.ObjectRowSchema Piece, Vector2 Spot, int[,] TilesToGo)
        {
            
            for (int X = 0; X < Piece.Dimensions.X; X=X+1)
            {
                for (int Y = 0; Y < Piece.Dimensions.Y; Y++)
                {
                    if (TilesToGo[(int)Spot.X + X, (int)Spot.Y + Y] != 0)
                    {
                        return new Vector2(X, Y);
                        //shows the vector of the tile that first caused the problem.
                    }
                    else
                    {
                        
                    }
                }
                
            }
            return new Vector2(-1, -1);//used to signify that it CAN go here
        }

        protected static int FindTileSetIndex (List<ObjectTileSet> All, Random D)//to find a random general-purpose TileSet
        {
            List<int> GeneralPurposeTileSets = new List<int>();

            for (int T = 0; T < All.Count; T++)
            {
                if (All[T].Purpose == null || All[T].Purpose == string.Empty)
                {
                    GeneralPurposeTileSets.Add(T);
                }
            }
            
            return GeneralPurposeTileSets[D.Next(0, GeneralPurposeTileSets.Count - 1)];
        }

        protected static int FindTileSetIndex ( List<ObjectTileSet> All, string SpecificPurpose, Random D)//to find a specific-purpose tileset
        {
            List<int> SpecificPurposeTileSets = new List<int>();
            
            for (int T = 0; T < All.Count; T++)
            {
                if (All[T].Purpose == SpecificPurpose)
                {
                    SpecificPurposeTileSets.Add(T);
                }
            }
            
            return SpecificPurposeTileSets[D.Next(0, SpecificPurposeTileSets.Count - 1)];
        }

        protected static int FindTileSetIndex( List<ObjectTileSet> All, Vector2 DesiredAverageSize, Random D)//to find a tileset with ideal-sized objects
        {
            throw new NotImplementedException();
        }

        protected static int FindTileSetIndex(List<ObjectTileSet> All, bool WantLarge, Random D)//EITHER finds a tileset with smaller-than-avg objects OR larger-than-avg objecs
        {
            if (All.Count > 1)
            {
                List<double> TileSetAvgSize = new List<double>();

                foreach (ObjectTileSet TS in All)
                {
                    List<int> RowSize = new List<int>();

                    for (int R = 0; R < TS.RowSchemas.Count; R++)
                    {
                        RowSize.Add((int)TS.RowSchemas[R].Dimensions.X + (int)TS.RowSchemas[R].Dimensions.Y);
                    }
                    TileSetAvgSize.Add(MathMethod.Average(RowSize));
                }
                if (WantLarge)
                {
                    return MathMethod.ReturnIndexBiggest(TileSetAvgSize);
                }
                else
                {
                    return MathMethod.ReturnIndexSmallest(TileSetAvgSize);
                }
            }
            else//is only 1 tileset
            {
                return 0;
            }


        }

        protected static bool CheckAreaOverlap( ref List<Rectangle> MethodAreas, List<Rectangle> FilledAreas)
        ///bool signifies whether there is any space left after the overlap check. The returned reference MethodArea is the
        ///same as it was, with the sections of overlap removed.
        {
            foreach (Rectangle FilledArea in FilledAreas)
            {

                for (int A = 0; A < MethodAreas.Count; A++)

                {
                    Rectangle MethodArea = MethodAreas[A];

                    if (RectMethod.TileIntersects(FilledArea, MethodArea))
                    {
                        Rectangle TileOverlap = RectMethod.TileIntersectArea(FilledArea, MethodArea);
                        MethodAreas.AddRange(RectMethod.Splice(TileOverlap, MethodArea));
                        MethodAreas.RemoveAt(A);
                        A--;
                    }
                }
            }
            if(MethodAreas.Count > 0)
            {
                return true;
            }
            return false;
        }

        protected static List<MapObject> FilterOverlaps(List<MapObject> Objects, List<Rectangle> FilledAreas)
        {
            for(int O = 0; O < Objects.Count; O++)
            {
                foreach(Rectangle FilledArea in FilledAreas)
                {
                    if (RectMethod.TileIntersects(FilledArea, Objects[O].FullTileLocation))
                    {
                        Objects.RemoveAt(O);
                        O--;
                        break;
                    }
                }
            }
            return Objects;

        }

        protected static bool ObjectFits(Rectangle RoomLoc, Vector2 ObjectSize)//is the object too wide/tall for the room?
        {
            if(ObjectSize.X > RoomLoc.Width)
            {
                return false;
            }
            if(ObjectSize.Y > RoomLoc.Height)
            {
                return false;
            }
            return true;
        }
    }

    public class ObjectFillArea
    {
        public Rectangle Area;
        public bool ExemptFromBans;

        public ObjectFillArea(Rectangle Area, bool Exempt)
        {
            this.Area = Area;
            ExemptFromBans = Exempt;
        }
    }
}
