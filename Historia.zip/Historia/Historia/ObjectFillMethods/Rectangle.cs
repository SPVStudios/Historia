﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace Historia.ObjectFillMethods
{
    public class Box:ObjectFillMethod
    {
        public override void FillRoom(Room Room, ref List<MapObject> Created, List<ObjectTileSet> Available, Random D, ref List<Rectangle> FilledAreas)
        {
            //no need to adjust for overlaps - 
            Rectangle RoomLoc = Room.Location[0];
            if (RoomLoc.Width > 4 && RoomLoc.Y > 4)
            {

                Rectangle BoxBounds = RectMethod.CreateRandomRectangle(RoomLoc, D);

                int ChosenInt = FindTileSetIndex(Available,true ,D);
                ObjectTileSet ChosenTileSet = Available[ChosenInt];


                Created.AddRange(FillWholeRectangle(BoxBounds, ChosenTileSet, ChosenInt, D, ref FilledAreas));

            }
        }
    }
}
