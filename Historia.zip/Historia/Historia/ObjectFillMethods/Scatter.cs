﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace Historia.ObjectFillMethods
{
    public class Scatter : ObjectFillMethod
    {
        public override void FillRoom(Room Room, ref List<MapObject> Created, List<ObjectTileSet> Available, Random D, ref List<Rectangle> FilledAreas)
        {
            Rectangle RoomLoc = Room.Location[0];
            //pick a small-object tileset for objects
            int WhichTileSet = FindTileSetIndex(Available, false, D);
            //Split the room into regions, as was the case with creating sections for rooms, about 4x4 in size




            List<MapObject> Scattered = new List<MapObject>();



            List<Rectangle> Sections = new List<Rectangle>();
            Sections.Add(RoomLoc);//the whole room as one section
            bool SectionsSmallEnough = false;
            int LargeRoomXTimesY = 16;

            Vector2 MinimumSectionSize = new Vector2(1, 1);

            while (!SectionsSmallEnough)
            {

                List<Rectangle> NewSections = new List<Rectangle>();//empties NewSections
                for (int I = 0; I < Sections.Count; I++)
                {
                    Rectangle Section = Sections[I];
                    int splitter = -1;
                    if (Section.Width > 3 * MinimumSectionSize.X)
                    {
                        if (Section.Height > 3 * MinimumSectionSize.Y)//both
                        {
                            splitter = D.Next(1, 100);
                        }
                        else//Wide enough but not tall enough
                        {
                            splitter = D.Next(1, 59);
                        }

                    }
                    else if (Section.Height > 4 * MinimumSectionSize.Y)//tall enough but not wide enough
                    {
                        splitter = D.Next(41, 100);
                    }

                    if (0 <= splitter && splitter <= 40)//40% chance to be a horizontal split
                    {
                        int halfway = Section.Width / 2;
                        int leeway = halfway - (int)MinimumSectionSize.X;
                        if (leeway >= 0)
                        {
                            int modMax = Math.Min(leeway, Section.Width / 4);
                            int splitmodifier = D.Next(-modMax, modMax);
                            Section.Width = halfway + splitmodifier;
                            NewSections.Add(new Rectangle(Section.X + Section.Width, Section.Y, halfway - splitmodifier, Section.Height));
                        }
                    }
                    else if (splitter >= 60)//40% chance to be a vertical split - to be changed if possible to do L shapes
                    {
                        int halfway = Section.Height / 2;
                        int leeway = halfway - (int)MinimumSectionSize.Y;
                        if (leeway >= 0)
                        {
                            int modMax = Math.Min(leeway, Section.Height / 4);
                            int splitmodifier = D.Next(-modMax, modMax);
                            Section.Height = halfway + splitmodifier;
                            NewSections.Add(new Rectangle(Section.X, Section.Y + Section.Height, Section.Width, halfway - splitmodifier));
                        }

                    }
                    else
                    {//20% to do nothing for this section. Also occurs if no split was rolled as section is too small.


                    }
                    Sections[I] = Section;
                }
                foreach (Rectangle NewSection in NewSections)
                {
                    Sections.Add(NewSection);
                }
                //check if the sections are small enough

                int TotalAreas = 0;

                foreach (Rectangle Section in Sections)
                {
                    TotalAreas += Section.Width * Section.Height;
                }

                double ActualAverageSectionArea = TotalAreas / Sections.Count;




                if (ActualAverageSectionArea <= LargeRoomXTimesY)
                {
                    SectionsSmallEnough = true;
                }

            }
            //put an item in a random position in each region.

            //create the directory of SchemaIndexes to balance the tileset by the object.
            ObjectTileSet Selected = Available[WhichTileSet];
            List<int> SchemaIndexes = new List<int>();
            for (int I = 0; I < Selected.RowSchemas.Count; I++)
            {
                for (int P = 0; P < Selected.RowSchemas[I].Instances; P++)
                {
                    SchemaIndexes.Add(I);
                }
            }
            //place these items in each region with this list.
            foreach (Rectangle Section in Sections)
            {
                int SelectedSchema = SchemaIndexes[D.Next(0, SchemaIndexes.Count - 1)];
                Vector2 ObjectSize = Selected.RowSchemas[SelectedSchema].Dimensions;
                if (ObjectFits(Room.Location[0], ObjectSize))
                {
                    int ObjectStartX = D.Next(Room.Location[0].X, Room.Location[0].Right - (int)ObjectSize.X);
                    int ObjectStartY = D.Next(Room.Location[0].Y, Room.Location[0].Bottom - (int)ObjectSize.Y);

                    Scattered.Add(new MapObject(Available[WhichTileSet], WhichTileSet, SelectedSchema, new Vector2(ObjectStartX, ObjectStartY), D));

                }
                //ADJUST FOR OVERLAP?
                foreach (MapObject O in Scattered)
                {
                    if (!RectMethod.TileIntersects(O.FullTileLocation, FilledAreas))
                    {//if doesn't intersect with anything
                        FilledAreas.Add(O.FullTileLocation);
                        Created.Add(O);
                    }
                }
            }
        }
    }
}
