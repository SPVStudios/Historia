﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Historia
{
    public class SplashScreen : GameScreen//This clones the GameScreen class for the Splash Screen to edit + use
        // that version itself ("override")if required. This is called "inheriting" (the GameScreen class) 
    {
        public Image Image = new Image();
        







        public override void LoadContent()
        { 
            base.LoadContent();//all the normal stuff defined in GameScreen where it's inherited from, plus...

            //Path = @"SplashScreen\GRE_ReverseLogo@0.5x-100.jpg";
            Image.LoadContent();
            //IMPORTANT: ALL CONTENT FILES MUST HAVE "Build Action" set to "Content"
            //and "Copy To Output Directory" set to "Copy Always", it seems, otherwise it won't load properly and raise an exception.

            

        }
        public override void UnloadContent()
        {
            base.UnloadContent();//all the normal stuff defined in GameScreen where it's inherited from, plus...
            Image.UnloadContent();
        }
        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);//all the normal stuff defined in GameScreen where it's inherited from, plus...
            Image.Update(gameTime);
            if (InputManager.Instance.KeyPressed(Keys.Enter, Keys.Z))
            {
                ScreenManager.Instance.ChangeScreens("TitleScreen");//goes to the main menu.
            }
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);//all the normal stuff defined in GameScreen where it's inherited from, plus...

            Image.Draw(spriteBatch);
        }

    }
}
