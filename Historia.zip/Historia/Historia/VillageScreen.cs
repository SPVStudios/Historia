﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Xml.Serialization;
using Microsoft.Xna.Framework.Input;

namespace Historia
{
    public class VillageScreen : GameScreen//also derives most of its structure from the menuManager - but edits it in various places such as having links DO something rather than just transition
    {
        Village village;
        LoadStats playerStats;
        Menu menu;
        bool IsTransitioning;
        bool PrevTransitionOver;
        public string menuPath;

        public VillageScreen()
        {
            menu = new Menu();
            menu.OnMenuChange += Menu_OnMenuChange;//triggers reaction to event
            PrevTransitionOver = true;
            menuPath = "";

        }

        public override void LoadContent()
        {
            base.LoadContent();

            village = GameState.Instance.WorldMap.Villages[GameState.Instance.WorldMapLocation];
            if (GameState.Instance.PlayerExists)
            {
                playerStats = GameState.Instance.PlayerStats;
            }
            else
            {
                Player player = new Player();
                XmlManager<Player> Load = new XmlManager<Player>();
                player = Load.Load("Load/Gameplay/Player.xml");
                playerStats = player.Stats;
                playerStats.LoadContent();
                GameState.Instance.PlayerExists = true;
            }

            if (menuPath != String.Empty)
            {
                menu.ID = menuPath;
            }
            ReplaceWithVillageInfo();
            menu.LoadContent();
        }

        public override void UnloadContent()
        {
            base.UnloadContent();
            menu.UnloadContent();

        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            if (!IsTransitioning)
            {
                menu.Update(gameTime);
            }
            if (InputManager.Instance.KeyPressed(Keys.Enter) == true && IsTransitioning == false)
            {

                if (menu.Items[menu.ItemNumber].LinkType == "Screen")
                {
                    GameStateToLeave();
                    ScreenManager.Instance.ChangeScreens(menu.Items[menu.ItemNumber].LinkID);
                }
                else if (menu.Items[menu.ItemNumber].LinkType == "Menu")
                {
                    StartMenuTransition();
                }
                else if (menu.Items[menu.ItemNumber].LinkType == "Stat and Menu")
                {//will adjust playerstats as dictated then change to the next menu
                    foreach (StatChange S in menu.Items[menu.ItemNumber].StatChanges)
                    {
                        playerStats.ApplyStatChange(S);
                    }
                    StartMenuTransition();
                }
                else if (menu.Items[menu.ItemNumber].LinkType == "Conditional Stat and Menu")
                {//according to a given measured stat, will adjust playerstats as dictated then change to the next menu
                    if (IsConditionMet(menu.Items[menu.ItemNumber].Condition))
                    {
                        foreach (StatChange S in menu.Items[menu.ItemNumber].StatChangesIfConditionMet)
                        {
                            playerStats.ApplyStatChange(S);
                        }
                        menu.Items[menu.ItemNumber].LinkID = menu.Items[menu.ItemNumber].LinkIDifConditionMet;
                        StartMenuTransition();

                    }
                    else
                    {
                        foreach (StatChange S in menu.Items[menu.ItemNumber].StatChangesIfConditionFail)
                        {
                            playerStats.ApplyStatChange(S);
                        }
                        menu.Items[menu.ItemNumber].LinkID = menu.Items[menu.ItemNumber].LinkIDifConditionFail;
                        StartMenuTransition();
                    }
                }
            }
            Transition(gameTime);//transitions if IsTransitioning is true

        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);
            menu.Draw(spriteBatch);
        }

        private void Menu_OnMenuChange(object sender, EventArgs e)//reaction to the event "OnMenuChange"
        {
            XmlManager<Menu> XmlMenuManager = new XmlManager<Menu>();
            menu.UnloadContent();

            menu = XmlMenuManager.Load(menu.ID);


            ReplaceWithVillageInfo();
            menu.LoadContent();
            menu.OnMenuChange += Menu_OnMenuChange;
            menu.Transition(0.0f);
            foreach (MenuItem item in menu.Items)
            {
                item.Image.StoreEffects();
                item.Image.ActivateEffect("FadeEffect");
            }
        }

        void Transition(GameTime gameTime)
        {
            if (IsTransitioning)
            {
                for (int i = 0; i < menu.Items.Count; i++)
                {
                    menu.Items[i].Image.Update(gameTime);
                    float first = menu.Items[0].Image.Alpha;
                    float last = menu.Items[menu.Items.Count - 1].Image.Alpha;
                    if (first == 0.0f && last == 0.0f && PrevTransitionOver == true)
                    {
                        PrevTransitionOver = false;
                        menu.ID = menu.Items[menu.ItemNumber].LinkID;//this also triggers _OnMenuChange

                    }
                    else if (first == 1.0f && last == 1.0f)
                    {
                        IsTransitioning = false;
                        PrevTransitionOver = true;
                        foreach (MenuItem item in menu.Items)
                        {
                            item.Image.RestoreEffects();
                        }
                    }
                }

            }
        }


        private void GameStateToLeave()
        {
            GameState.Instance.EnteringWorld = true;
            GameState.Instance.EnteringVillage = false;
            GameState.Instance.PlayerStats = playerStats;
            GameState.Instance.PlayerExists = true;
        }

        // ######## Methods specific to VillageScreen menus for dealing with Stat Changes #############

        private void ReplaceWithVillageInfo()
        {
            if (menu.HasTitle)
            {
                menu.Title.Text = menu.Title.Text.Replace("#", village.Name);
                menu.Title.Text = menu.Title.Text.Replace("*", village.InnName);
                menu.Title.Text = menu.Title.Text.Replace("^", village.Deity.Name);
                menu.Title.Text = menu.Title.Text.Replace("£", playerStats.GOLD.ToString());
                menu.Title.Text = menu.Title.Text.Replace("+", village.Deity.Description);
                menu.Title.Text = menu.Title.Text.Replace("%", village.Deity.Buff);
            }
            for (int I = 0; I < menu.Items.Count; I++)
            {
                menu.Items[I].Image.Text = menu.Items[I].Image.Text.Replace("#", village.Name);
                menu.Items[I].Image.Text = menu.Items[I].Image.Text.Replace("*", village.InnName);
                menu.Items[I].Image.Text = menu.Items[I].Image.Text.Replace("^", village.Deity.Name);
                menu.Items[I].Image.Text = menu.Items[I].Image.Text.Replace("£", playerStats.GOLD.ToString());
                menu.Items[I].Image.Text = menu.Items[I].Image.Text.Replace("%", village.Deity.Buff);
                foreach (StatChange S in menu.Items[I].StatChanges)
                {
                    S.StatToChange = S.StatToChange.Replace("%", village.Deity.Buff);
                }
                foreach(StatChange S in menu.Items[I].StatChangesIfConditionMet)
                {
                    S.StatToChange = S.StatToChange.Replace("%", village.Deity.Buff);
                }
                foreach(StatChange S in menu.Items[I].StatChangesIfConditionFail)
                {
                    S.StatToChange = S.StatToChange.Replace("%", village.Deity.Buff);
                }

                if (menu.Items[I].Condition != null)
                {
                    menu.Items[I].Condition.StatToMeasure = menu.Items[I].Condition.StatToMeasure.Replace("%", village.Deity.Buff);
                }
            }
        }


        private bool IsConditionMet(Condition C)
        {
            int Value = 0;
            switch (C.StatToMeasure)
            {
                case "SPD":
                    Value = playerStats.SPD;
                    break;
                case "ATK":
                    Value = playerStats.ATK;
                    break;
                case "DEF":
                    Value = playerStats.DEF;
                    break;
                case "ACC":
                    Value = playerStats.ACC;
                    break;
                case "EVA":
                    Value = playerStats.EVA;
                    break;
                case "Health":
                    Value = playerStats.HP;
                    break;
                case "HP":
                    Value = playerStats.HP;
                    break;
                case "MaxHealth":
                    Value = playerStats.MaxHP;
                    break;
                case "MaxHP":
                    Value = playerStats.MaxHP;
                    break;
                case "Gold":
                    Value = playerStats.GOLD;
                    break;
                default:
                    throw new Exception("No Such Stat");
            }
            if (C.MustBeAbove != 0)
            {
                if (Value < C.MustBeAbove)
                {
                    return false;
                }
            }
            if (C.MustBeBelow != 0)
            {
                if (Value > C.MustBeBelow)
                {
                    return false;
                }
            }
            if (C.MustBE != 0)
            {
                if (Value != C.MustBE)
                {
                    return false;
                }
            }
            return true;
        }

        private void StartMenuTransition()
        {
            IsTransitioning = true;
            menu.Transition(1.0f);
            foreach (MenuItem item in menu.Items)
            {
                item.Image.StoreEffects();
                item.Image.ActivateEffect("FadeEffect");
            }
        }

    }
}
