﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;


namespace Historia
{
    public class StealthManager
    //This Class manages all signs of suspicion created by the player and is called by each Enemy in their update loops to update their
    //own supspicion values.
    // It does NOT handle any individual enemy's suspicion levels, though.
    {
        Map mapRef;

        public Vector2 PlayerLoc { get; private set; }

        private static StealthManager instance;

        public static StealthManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new StealthManager();
                }
                return instance;
            }
        }

        public const int VisualPlayerSupicion = 120;//the amount of suspicion per loop a view of the player will generate.

        public Dictionary<Rectangle, int> Noises;//A "Noise" consists of a small rectangle of higher suspicion, and a larger rectangle of much lower suspicion.
                                          //Noises Reduce quickly in volume each Update, and each half of a Noise disappears from this list when silent again.

        public List<Dictionary<Vector2, int>> RoomSuspiciousPointsThisPass;
        //A list of all of the suspicious points and their corresponding suspicion values.
        //includes the player themselves, and all other things that are visibly suspicious - these should be checked via Line of Sight for each enemy.

        public List<Dictionary<Vector2, int>> PassageSuspiciousPointsThisPass;

        List<Dictionary<Vector2, int>>RoomNextSuspiciousThings;//Things are added to this list, which replaces the current list in each update loop.

        List<Dictionary<Vector2, int>> PassageNextSuspiciousThings;

        int NumRoomsNow;
        int NumPassagesNow;


        public void StartNewFloor(Map newMapRef)//wipes the slate clean.
        {
            Noises = new Dictionary<Rectangle, int>();
            //RoomTemplateArray = new List<Dictionary<Vector2, int>>();
            //PassageTemplateArray = new List<Dictionary<Vector2, int>>();
            RoomSuspiciousPointsThisPass = new List<Dictionary<Vector2, int>>();
            PassageSuspiciousPointsThisPass = new List<Dictionary<Vector2, int>>();
            RoomNextSuspiciousThings = new List<Dictionary<Vector2, int>>();
            PassageNextSuspiciousThings = new List<Dictionary<Vector2, int>>();

            PlayerLoc = Vector2.Zero;

            Noises = new Dictionary<Rectangle, int>();
            mapRef = newMapRef;
            /*foreach(Room R in newMapRef.Rooms)
            {
                RoomTemplateArray.Add(new Dictionary<Vector2, int>());
             
            }
            */
            NumRoomsNow = newMapRef.Rooms.Count;
            NumPassagesNow = newMapRef.Passages.Count;
            //RoomSuspiciousPointsThisPass.AddRange(RoomTemplateArray);
            //RoomNextSuspiciousThings.AddRange(RoomTemplateArray);

            ResetRoomArray(ref RoomSuspiciousPointsThisPass);
            ResetRoomArray(ref RoomNextSuspiciousThings);

            ResetPassageArray(ref PassageNextSuspiciousThings);
            ResetPassageArray(ref PassageSuspiciousPointsThisPass);

           
            //PassageSuspiciousPointsThisPass.AddRange(PassageTemplateArray);
            //PassageNextSuspiciousThings.AddRange(PassageTemplateArray);



            if(ReferenceEquals(RoomSuspiciousPointsThisPass, RoomNextSuspiciousThings))
            {
                throw new Exception("This Doesn't Work");
            }
            
            if (ReferenceEquals(RoomSuspiciousPointsThisPass, PassageSuspiciousPointsThisPass))
            {
                throw new Exception("Same here");
            }
        }

        public void Update()
        {//A Noise Source is a location - these need to be turned into Noise rectangles.

            UpdateNoises();

            RoomSuspiciousPointsThisPass.Clear();
            RoomSuspiciousPointsThisPass.AddRange(RoomNextSuspiciousThings);

            ResetRoomArray(ref RoomNextSuspiciousThings);

            PassageSuspiciousPointsThisPass.Clear();
            PassageSuspiciousPointsThisPass.AddRange(PassageNextSuspiciousThings);

            ResetPassageArray(ref PassageNextSuspiciousThings);

            if (ReferenceEquals(PassageSuspiciousPointsThisPass, PassageNextSuspiciousThings))
            {
                throw new Exception("This Doesn't Work.");
            }

        }

        public void MakeNewNoise(Vector2 Location, int Suspiciousness)//minimum suspicion is 5, really
        {
            int Radius = Suspiciousness / 5;
            int WideRadius = Suspiciousness;
            int CloseSuspicion = Suspiciousness;
            int WideSuspicion = (Suspiciousness +10) / 10;
            

            Rectangle Close = new Rectangle((int)Location.X - Radius, (int)Location.Y - Radius, 2 * Radius, 2 * Radius);

            Rectangle Vague = new Rectangle((int)Location.X - WideRadius, (int)Location.Y - WideRadius, 2 * WideRadius, 2 * WideRadius);

            if (Noises.ContainsKey(Close))
            {
                Noises[Close] += CloseSuspicion;
            }
            else
            {
                Noises.Add(Close, CloseSuspicion);
            }

            if (Noises.ContainsKey(Vague))
            {
                Noises[Vague] += WideSuspicion;
            }
            else
            {
                Noises.Add(Vague, WideSuspicion);
            }

           
        }

        private void UpdateNoises()
        {
            Dictionary<Rectangle, int> NewNoiseLevels = new Dictionary<Rectangle, int>();
           for(int I = 0; I < Noises.Count; I++)
            {
                Rectangle Key = Noises.ElementAt(I).Key;
                int NewVolume = Noises.ElementAt(I).Value - (1 + Noises.ElementAt(I).Value/8);
                if (NewVolume > 0)
                {
                    NewNoiseLevels.Add(Key, NewVolume);
                }
            }
            Noises = NewNoiseLevels;
        }

        public void AddOrMaintainSuspiciousThings(Vector2 Location, int Suspiciousness, int RoomOrPassagewayIn, bool IsARoom)
        {
            if (IsARoom)
            {
                
                if (RoomNextSuspiciousThings[RoomOrPassagewayIn].ContainsKey(Location))
                {
                    RoomNextSuspiciousThings[RoomOrPassagewayIn][Location] += Suspiciousness;
                }
                else
                {
                    RoomNextSuspiciousThings[RoomOrPassagewayIn].Add(Location, Suspiciousness);
                }
            }
            else
            {
                
                if (PassageNextSuspiciousThings[RoomOrPassagewayIn].ContainsKey(Location))
                {
                    PassageNextSuspiciousThings[RoomOrPassagewayIn][Location] += Suspiciousness;
                }
                else
                {
                    PassageNextSuspiciousThings[RoomOrPassagewayIn].Add(Location, Suspiciousness);
                }
            }

            if (ReferenceEquals(RoomNextSuspiciousThings, PassageNextSuspiciousThings))
            {
                throw new Exception("This Doesn't Work");
            }

           
        }

        public void AddOrMaintainSuspiciousThings(Vector2 Location, int Suspiciousness)//will calculate RoomIn with RectMethod.
        {
            int RoomIn = RectMethod.FindWhatRoomLocationIsIn(Location, mapRef, out bool IsInPassage);
            AddOrMaintainSuspiciousThings(Location, Suspiciousness, RoomIn, !IsInPassage);
        }

        public void ResetRoomArray(ref List<Dictionary<Vector2,int>> Array)
        {
            Array.Clear();
            for(int I = 0; I < NumRoomsNow;I++)
            {
                Array.Add(new Dictionary<Vector2, int>());
            }
        }

        public void ResetPassageArray(ref List<Dictionary<Vector2, int>> Array)
        {
            Array.Clear();
            for (int I = 0; I < NumPassagesNow;I++)
            {
                Array.Add(new Dictionary<Vector2, int>());
            }
        }

        public void UpdatePlayerLoc(Vector2 Loc)
        {
            PlayerLoc = Loc;
        }
    }
}
