﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Historia
{
    public static class RectMethod
    {
        public static Rectangle ExpandUp(Rectangle Original)
        {
            Original.Y--;
            Original.Height++;
            return Original;
        }

        public static Rectangle ExpandDown(Rectangle Original)
        {
            Original.Height++;
            return Original;
        }

        public static Rectangle ExpandLeft(Rectangle Original)
        {
            Original.X--;
            Original.Width++;
            return Original;
        }

        public static Rectangle ExpandRight(Rectangle Original)
        {
            Original.Width++;
            return Original;
        }

        public static Rectangle ShrinkHeight(Rectangle Original)
        {
            Original.Height--;
            return Original;
        }

        public static Rectangle ShrinkWidth(Rectangle Original)
        {
            Original.Width--;
            return Original;
        }

        public static Rectangle AddABorder(Rectangle original, int Extratilesaround)
        {
            int X = original.X - Extratilesaround;
            int Y = original.Y - Extratilesaround;
            return new Rectangle(X, Y, original.Width + (2 * Extratilesaround), original.Height + (2 * Extratilesaround));
        }

        public static Rectangle AddABorder(Vector2 original, int Extratilesaround)
        {
            int X = (int)original.X - Extratilesaround;
            int Y = (int)original.Y - Extratilesaround;
            return new Rectangle(X, Y, 1+ (2 * Extratilesaround), 1 + (2 * Extratilesaround));
        }

        
        //end of rect manipulation methods

        public static List<Rectangle> ReturnBoxyShape(Rectangle Bounds, Random D)
        {


            //start with a 'primary' rectangle
            List<Rectangle> Boxes = new List<Rectangle>();
            Rectangle First = CreateRandomRectangle(Bounds, D);

            Boxes.Add(First);

            //add a range of 1 - 3 other rectangles that intersect in some way, but are not surrounded entirely be the main shape
            if (First != Bounds)
            {
                int howManyMore = D.Next(1, 3);
                for (int I = 0; I < howManyMore; I++)
                {
                    int Iterations = 0;
                    while (true)
                    {

                        Rectangle New = CreateRandomRectangle(Bounds, D);

                        Rectangle Touchtest = TileIntersectArea(New, First);
                        if (Touchtest != New)
                        {
                            if (TileIntersects(New, First))
                            {
                                Boxes.Add(New);
                                break;
                            }
                        }

                        Iterations++;

                        if (Iterations > 30)
                        {
                            break;
                        }
                    }
                }
                Boxes = RemoveOverlaps(Boxes);
            }
            return Boxes;
        }

        public static Rectangle CreateRandomRectangle(Rectangle Bounds, Random D)
        {

            int X1 = D.Next(Bounds.X, Bounds.Right - 1);
            int Y1 = D.Next(Bounds.Y, Bounds.Bottom - 1);

            int X2 = D.Next(Bounds.X, Bounds.Right - 1);
            int Y2 = D.Next(Bounds.Y, Bounds.Bottom - 1);

            int Left = Math.Min(X1, X2);
            int Top = Math.Min(Y1, Y2);
            int Right = Math.Max(X1, X2);
            int Bottom = Math.Max(Y1, Y2);

            Rectangle created = new Rectangle(Left, Top, Right - Left, Bottom - Top);

            //expand by 1 to turn possible lines into boxes. Accounted for at the top, as only goes up to boundary - 1.
            created = ExpandDown(created);
            created = ExpandRight(created);
            return created;


        }

        public static List<Rectangle> RemoveOverlaps(List<Rectangle> Originals)
        {
            //remove the first from the list to use as the primary comparator.
            List<Rectangle> Comparators = new List<Rectangle>
            {
                Originals[0]
            };
            Originals.RemoveAt(0);

            foreach (Rectangle Addition in Originals)
            {//compare each against it. After one has been compared against the primary comparator,
             //put the recangle(s) into the list of rectangles that you are comparing it against.
                List<Rectangle> Pieces = new List<Rectangle>() { Addition };
                foreach (Rectangle Comparison in Comparators)
                {
                    List<Rectangle> Passed = new List<Rectangle>();
                    foreach (Rectangle Piece in Pieces)
                    {
                        Passed.AddRange(Splice(Comparison, Piece));
                    }
                    Pieces = Passed;
                }
                Comparators.AddRange(Pieces);//all are verified, so are added to the comparators.
            }

            return Comparators;
        }

        public static List<Rectangle> Splice(Rectangle Comparator, Rectangle Subject)
        {
            if (TileIntersects(Comparator, Subject))
            {
                List<Rectangle> OffCuts = new List<Rectangle>();
                if (Subject.Y < Comparator.Y && Subject.Bottom > Comparator.Y)//if the subject straddles the top of the shape
                {
                    Rectangle Extra = new Rectangle(Subject.X, Subject.Y, Subject.Width, Comparator.Top - (Subject.Top));
                    Subject = new Rectangle(Subject.X, Comparator.Top, Subject.Width, Subject.Height - Extra.Height);
                    OffCuts.Add(Extra);
                }
                if (Subject.Y < Comparator.Bottom && Subject.Bottom > Comparator.Bottom)//if the subject straddles the bottom of the shape
                {
                    Rectangle Extra = new Rectangle(Subject.X, Comparator.Bottom, Subject.Width, Subject.Bottom - (Comparator.Bottom));
                    Subject.Height -= Extra.Height;
                    OffCuts.Add(Extra);
                }
                if (Subject.X < Comparator.X && Subject.Right > Comparator.X)//if the subject straddles the left of the shape
                {
                    Rectangle Extra = new Rectangle(Subject.X, Subject.Y, Comparator.Left - (Subject.Left), Subject.Height);
                    Subject = new Rectangle(Comparator.Left, Subject.Y, Subject.Width - Extra.Width, Subject.Height);
                    OffCuts.Add(Extra);
                }
                if (Subject.X < Comparator.Right && Subject.Right > Comparator.Right)//if the subject the right of the shape
                {
                    Rectangle Extra = new Rectangle(Comparator.Right, Subject.Y, Subject.Right - (Comparator.Right), Subject.Height);
                    OffCuts.Add(Extra);
                }
                return OffCuts;
            }
            else///it doesn't actually overlap at all
            {
                return new List<Rectangle>() { Subject };
            }
        }

        public static bool TileIntersects(Rectangle A, Rectangle B)
        {
            bool Xoverlap = false;
            bool Yoverlap = false;

            if ((A.X >= B.X && A.X < B.Right) || (A.Right > B.X && A.Right <= B.Right))
            ///MORE THAN ensures only a tile or more of overlap is considered.
            ///More Than or Equal To would also return true if they are TOUCHING.
            /// To overlap in the X direction, at least one edge
            {
                Xoverlap = true;
            }
            else if ((B.X >= A.X && B.X < A.Right) || (B.Right > A.X && B.Right <= A.Right))
            {
                Xoverlap = true;
            }

            if ((A.Y >= B.Y && A.Y < B.Bottom) || (A.Bottom > B.Y && A.Bottom <= B.Bottom))
            //the same as above, but for the Y dimension. Bottom is the extreme border, and not the last tile.
            {
                Yoverlap = true;
            }
            else if ((B.Y >= A.Y && B.Y < A.Bottom) || (B.Bottom > A.Y && B.Bottom <= A.Bottom))
            {
                Yoverlap = true;
            }

            return Xoverlap & Yoverlap;
        }

        public static bool TileIntersects(Rectangle A, List<Rectangle> Set_B)
        {//checks that A intersects with SOMETHING in set B.
            foreach (Rectangle B in Set_B)
            {
                if (TileIntersects(A, B))
                {
                    return true;
                }
            }
            return false;
        }

        public static bool TileIntersects(List<Rectangle> Set_A, List<Rectangle> Set_B)
        {//checks whether ANYTHING in Set A intersects with ANYTHING in set B.
            foreach (Rectangle A in Set_A)
            {
                foreach (Rectangle B in Set_B)
                {
                    if (TileIntersects(A, B))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public static Rectangle TileIntersectArea(Rectangle A, Rectangle B)
        //before this is used, ensure that they DO intersect - it will still return a rectangle, although an unusual one,
        //if given rectangles that only actuallt touch or overlap
        {

            //X Direction
            int X_start;
            int X_end;//ABSOLUTE, not a full tile in itself

            //Y Direction
            int Y_start;
            int Y_end;//ABSOLUTE, not a full tile in itself
            X_start = Math.Max(A.X, B.X);
            X_end = Math.Min(A.Right, B.Right);
            Y_start = Math.Max(A.Y, B.Y);
            Y_end = Math.Min(A.Bottom, B.Bottom);
            return new Rectangle(X_start, Y_start, (X_end - X_start), (Y_end - Y_start));
        }

        public static bool LocationIsInRectangle(Vector2 Point, Rectangle Area)
        {
            if (Point.X >= Area.X && Point.X < Area.Right && Point.Y >= Area.Y && Point.Y < Area.Bottom)
            {
                return true;
            }
            return false;
        }

        public static bool TwoTilesAreAdjacentOrSame(Vector2 A, Vector2 B)
        {
            if (MathMethod.Modulus(A.X - B.X) == 0)

            {
                if (MathMethod.Modulus(A.Y - B.Y) <= 1)
                {
                    return true;
                }
            }
            else if (MathMethod.Modulus(A.X - B.X) == 1)
            {
                if (MathMethod.Modulus(A.Y - B.Y) == 0)
                {
                    return true;
                }
            }
            return false;
        }

        public static int FindWhatRoomLocationIsIn(Vector2 Point, Map mapRef, out bool IsInPassage)
        {
            for (int R = 0; R < mapRef.Rooms.Count; R++)
            {
                if (RectMethod.LocationIsInRectangle(Point, mapRef.Rooms[R].Location[0]))
                {

                    IsInPassage = false;
                    return R;
                }
            }
            //now checks passageways
            for (int P = 0; P < mapRef.Passages.Count; P++)
            {
                if (RectMethod.LocationIsInRectangle(Point, mapRef.Passages[P].Location))
                {
                    IsInPassage = true;
                    return P;
                }
            }
            throw new Exception("Not in a Room or a Passageway..");
        }

        public static int FindWhatRoomLocationIsIn(Vector2 Point, Map mapRef, out bool IsInPassage, out Rectangle CurrentLocaleBounds)
        {
            for (int R = 0; R < mapRef.Rooms.Count; R++)
            {
                if (RectMethod.LocationIsInRectangle(Point, mapRef.Rooms[R].Location[0]))
                {
                    CurrentLocaleBounds = mapRef.Rooms[R].Location[0];
                    IsInPassage = false;
                    return R;
                }
            }
            //now checks passageways
            for (int P = 0; P < mapRef.Passages.Count; P++)
            {
                if (RectMethod.LocationIsInRectangle(Point, mapRef.Passages[P].Location))
                {
                    CurrentLocaleBounds = mapRef.Passages[P].Location;
                    IsInPassage = true;
                    return P;
                }
            }
            throw new Exception("Not in a Room or a Passageway..");
        }

        

        public static Rectangle RadiusRectangle(Vector2 Centre, int Radius)
        {
            return new Rectangle((int)Centre.X - Radius, (int)Centre.Y - Radius, (2 * Radius) + 1, (2 * Radius) + 1);
        }

        public static int DistanceBetweenLocations(Vector2 A, Vector2 B)
        {
            Vector2 Movement = A - B;
            return (MathMethod.Modulus((int)Movement.X) + MathMethod.Modulus((int)Movement.Y));
        }


        public static Vector2 ReturnRandomEmptyTile(Rectangle Area, int[,] CollisionMap, Random R)//returns (-1,-1) if a failure
        {
            List<Vector2> Possibilities = new List<Vector2>();
            for(int X = Area.X; X < Area.Right; X++)
            {
                for(int Y = Area.Y; Y < Area.Bottom; Y++)
                {
                    if(CollisionCheck.Instance.CheckTargetBool(CollisionMap, new Vector2(X, Y)))
                    {
                        Possibilities.Add(new Vector2(X, Y));
                    }
                }
            }

            if(Possibilities.Count > 0)
            {
                return Possibilities[R.Next(0, Possibilities.Count - 1)];
            }
            else
            {
                return new Vector2(-1, -1);//No possibilities in this area, return a value regarded as false.
            }

            
        }

        public static bool IfValueIsInRectangleOfArray(int V, Rectangle R, int[,] Array, Vector2 ArraySize)
        {
            Rectangle A = TileIntersectArea(R, new Rectangle(0, 0, (int)ArraySize.X, (int)ArraySize.Y));
            for(int X = A.X; X < A.Right; X++)
            {
                for(int Y = A.Y; Y< A.Bottom;Y++)
                {
                    if(Array[X,Y] == V)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public static int CountValueInRectangleOfArray(int V, Rectangle R, int[,] Array, Vector2 ArraySize)
        {
            int Total = 0;
            Rectangle A = TileIntersectArea(R, new Rectangle(0, 0, (int)ArraySize.X, (int)ArraySize.Y));
            for (int X = A.X; X < A.Right; X++)
            {
                for (int Y = A.Y; Y < A.Bottom; Y++)
                {
                    if (Array[X, Y] == V)
                    {
                        Total++;
                    }
                }
            }
                return Total;
        }

        public static bool IfAboveValueIsInRectangleOfArray(int MinimumV, Rectangle R, int[,] Array, Vector2 ArraySize)
        {
            Rectangle A = TileIntersectArea(R, new Rectangle(0, 0, (int)ArraySize.X, (int)ArraySize.Y));
            for (int X = A.X; X < A.Right; X++)
            {
                for (int Y = A.Y; Y < A.Bottom; Y++)
                {
                    if (Array[X, Y] >= MinimumV)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// DOES NOT INCLUDE DIAGONALS.
        /// </summary>
        /// <param name="V">the value to check for</param>
        /// <param name="Loc">the location around which to check</param>
        /// <param name="Array">the array to check in</param>
        /// <param name="ArraySize">the size of that array</param>
        /// <returns></returns>
        public static bool IfValueIsAdjacentArray(int V, Vector2 Loc, int[,] Array, Vector2 ArraySize)
        {
            int XAdd1 = Math.Min((int)Loc.X + 1, (int)ArraySize.X - 1);
            int XTake1 = Math.Max((int)Loc.X - 1, 0);
            int YAdd1 = Math.Min((int)Loc.Y + 1, (int)ArraySize.Y - 1);
            int YTake1 = Math.Max((int)Loc.Y - 1, 0);


            if (Array[XAdd1, (int)Loc.Y] == V || Array[XTake1, (int)Loc.Y] == V || Array[(int)Loc.X, YAdd1] == V || Array[(int)Loc.X, YTake1] == V)
            {
                return true;
            }
            return false;
        }

        public static void ChangeValueForRect(ref int[,] A, int Replacement, Rectangle R)
        {
            for (int X = R.X; X < R.Right; X++)
            {
                for (int Y = R.Y; Y < R.Bottom; Y++)
                {
                    A[X, Y] = Replacement;
                }
            }
        }
        public static void ChangeValueForRect(ref int[,] A, int Replacement, Rectangle R, int ValueNotToOverrule)
        {
            for (int X = R.X; X < R.Right; X++)
            {
                for (int Y = R.Y; Y < R.Bottom; Y++)
                {
                    if (A[X, Y] != ValueNotToOverrule)
                    {
                        A[X, Y] = Replacement;
                    }
                }
            }
        }

        public static int CountSameValue(int[,] A, int Value, Vector2 ASize)
        {
            int Total = 0;
            for (int X = 0; X < ASize.X; X++)
            {
                for (int Y = 0; Y < ASize.Y; Y++)
                {
                    if (A[X, Y] == Value)
                    {
                        Total++;
                    }
                }
            }
            return Total;
        }
    }
}
