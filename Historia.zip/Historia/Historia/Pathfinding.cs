﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Xml.Serialization;
using System.Xml;

namespace Historia
{
    public static class Pathfinding
    {

        public static bool GetToLocation(Vector2 FinalLocation, Vector2 StartLocation, out List<Vector2> PathTaken, Map map)
        {
            PathTaken = new List<Vector2>();
            return GetToLocation(FinalLocation, StartLocation, out PathTaken, map, new List<Vector2>(), 0);
        }

        private static bool GetToLocation(Vector2 FinalLocation, Vector2 StartLocation, out List<Vector2> PathTaken, Map map, List<Vector2> AlreadyUsedMidpoints, int RecLayer)
        ///KnightPath algorithm
        ///creates a sequential list of co-ordinates to follow 1 by 1 to reach a destination.
        /// the boolean refers to whether such a location is accessible; the ouptut list is how you get there.
        {
            RecLayer++;

            if (FinalLocation == StartLocation)
            {
                PathTaken = new List<Vector2>();

                return true;
            }
            else if (RectMethod.TwoTilesAreAdjacentOrSame(StartLocation, FinalLocation))
            {
                PathTaken = new List<Vector2>() { FinalLocation };
                return true;
            }
            else if (RecLayer > 10)
            {
                PathTaken = new List<Vector2>();
                return false;
            }
            else if (CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, FinalLocation))
            {
                Vector2 Movement = FinalLocation - StartLocation;
                //try with horizntal-first L
                bool CanHoriFirst = Pathfinding_Check_Path(StartLocation, Movement, false, map, out Vector2 HoriProb, out bool HoriProbIsVertical);
                //try with vertical-first L
                bool CanVertiFirst = Pathfinding_Check_Path(StartLocation, Movement, true, map, out Vector2 VertiProb, out bool VertiProbIsVertical);

                if (CanVertiFirst)
                {
                    if (CanHoriFirst && map.D.Next(0, 100) > 50)
                    {
                        PathTaken = Pathfinding_Return_Path(StartLocation, Movement, false);
                        return true;
                    }
                    else
                    {
                        PathTaken = Pathfinding_Return_Path(StartLocation, Movement, true);
                        return true;
                    }
                }
                else if (CanHoriFirst)
                {
                    PathTaken = Pathfinding_Return_Path(StartLocation, Movement, false);
                    return true;
                }
                else
                {//if neither work, go along the obstacles from each to find a valid midpoint, if any.
                    List<Vector2> Midpoints = Pathfinding_Find_Midpoints(HoriProb, HoriProbIsVertical, VertiProb, VertiProbIsVertical, map, AlreadyUsedMidpoints);
                    //if none, return false
                    if (Midpoints.Count == 0)
                    {
                        PathTaken = new List<Vector2>();//irrelevant, but must set out variable
                        return false;
                    }

                    else
                    {//(else) if some, Pathfind from start to any of these 4 midpoints, and from those midpoints to the end point.
                        List<List<Vector2>> Options = new List<List<Vector2>>();
                        AlreadyUsedMidpoints.AddRange(Midpoints);
                        for (int O = 0; O < Midpoints.Count; O++)
                        {
                            bool Valid = GetToLocation(Midpoints[O], StartLocation, out List<Vector2> FirstStint, map, AlreadyUsedMidpoints, RecLayer);
                            if (Valid)
                            {
                                Valid = GetToLocation(FinalLocation, Midpoints[O], out List<Vector2> SecondStint, map, AlreadyUsedMidpoints, RecLayer);
                                if (Valid)
                                {
                                    FirstStint.AddRange(SecondStint);
                                    Options.Add(FirstStint);
                                }
                            }
                        }

                        if (Options.Count == 0)
                        {
                            PathTaken = new List<Vector2>();
                            return false;
                        }
                        else if (Options.Count == 1)
                        {//return the only valid route
                            PathTaken = Options[0];
                            return true;
                        }
                        else//2+different Options
                        {
                            //for the above <=4 valid solutions, pick the one with the shortest list of locations, as it is most efficient,
                            //and return that.
                            int Shortest = Options[0].Count;
                            int ShortestIndex = 0;
                            for (int I = 1; I < Options.Count; I++)
                            {
                                if (Options[I].Count < Shortest)
                                {
                                    Shortest = Options[I].Count;
                                    ShortestIndex = I;
                                }
                            }
                            PathTaken = Options[ShortestIndex];
                            return true;
                        }
                    }
                }
            }
            else//target location isn't even valid
            {
                PathTaken = new List<Vector2>();
                return false;
            }
        }
        // ^^^ Not handled List<Vector2> PreviousLocations to prevent doubling back - add it to CheckPath vv

        public static bool Pathfinding_Check_Path(Vector2 StartLocation, Vector2 Movement,
            bool VerticalFirst, Map map, out Vector2 FirstProblem, out bool ProblemWasVertical)
        {
            if (VerticalFirst)
            {
                for (int Y = 0; MathMethod.Modulus(Y) < MathMethod.Modulus(Movement.Y); Y += Math.Sign(Movement.Y))
                {
                    if (!CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, StartLocation + new Vector2(0, Y)))
                    {
                        FirstProblem = StartLocation + new Vector2(0, Y);
                        ProblemWasVertical = true;
                        return false;
                    }
                }
                //now horizontal
                for (int X = (int)0; MathMethod.Modulus(X) < MathMethod.Modulus(Movement.X); X += Math.Sign(Movement.X))
                {
                    if (!CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, StartLocation + new Vector2(X, Movement.Y)))
                    {
                        FirstProblem = StartLocation + new Vector2(X, Movement.Y);
                        ProblemWasVertical = false;
                        return false;
                    }
                }
                FirstProblem = Vector2.Zero;
                ProblemWasVertical = false;
                return true;
            }
            else
            {//horizontal first
                for (int X = 0; MathMethod.Modulus(X) < MathMethod.Modulus(Movement.X); X += Math.Sign(Movement.X))
                {
                    if (!CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, StartLocation + new Vector2(X, 0)))
                    {
                        FirstProblem = StartLocation + new Vector2(X, 0);
                        ProblemWasVertical = false;
                        return false;
                    }
                }
                //now vertical
                for (int Y = 0; MathMethod.Modulus(Y) < MathMethod.Modulus(Movement.Y); Y += Math.Sign(Movement.Y))
                {
                    if (!CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, StartLocation + new Vector2(Movement.X, Y)))
                    {
                        FirstProblem = StartLocation + new Vector2(Movement.X, Y);
                        ProblemWasVertical = true;
                        return false;
                    }
                }
                FirstProblem = Vector2.Zero;
                ProblemWasVertical = false;
                return true;
            }
        }

        private static List<Vector2> Pathfinding_Return_Path(Vector2 StartLocation, Vector2 Movement,
            bool VerticalFirst)
        {
            List<Vector2> Path = new List<Vector2>();
            if (VerticalFirst)
            {
                for (int Y = Math.Sign(Movement.Y); MathMethod.Modulus(Y) < MathMethod.Modulus(Movement.Y); Y += Math.Sign(Movement.Y))
                {
                    Path.Add(new Vector2(StartLocation.X, StartLocation.Y + Y));
                }
                //now horizontal
                for (int X = 0; MathMethod.Modulus(X) < MathMethod.Modulus(Movement.X); X += Math.Sign(Movement.X))
                {
                    Path.Add(new Vector2(StartLocation.X + X, StartLocation.Y + Movement.Y));
                }
                Path.Add(StartLocation + Movement);

                return Path;
            }
            else
            {//horizontal first
                for (int X = Math.Sign(Movement.X); MathMethod.Modulus(X) < MathMethod.Modulus(Movement.X); X += Math.Sign(Movement.X))
                {
                    Path.Add(StartLocation + new Vector2(X, 0));

                }
                //now vertical
                for (int Y = 0; MathMethod.Modulus(Y) < MathMethod.Modulus(Movement.Y); Y += Math.Sign(Movement.Y))
                {
                    Path.Add(StartLocation + new Vector2(Movement.X, Y));
                }
                Path.Add(StartLocation + Movement);
                return Path;
            }
        }

        private static List<Vector2> Pathfinding_Find_Midpoints(Vector2 FirstIssue, bool FirstIssueEncounteredWhenVertical, Vector2 Second, bool SecondVerti, Map map, List<Vector2> AlreadyUsedMidpoints)
        {
            List<Site> Options = new List<Site>();

            if (FirstIssueEncounteredWhenVertical)
            {
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(1, 0) });
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(-1, 0) });
            }
            else
            {
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(0, 1) });
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(0, -1) });
            }

            if (SecondVerti)
            {
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(1, 0) });
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(-1, 0) });
            }
            else
            {
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(0, 1) });
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(0, -1) });
            }

            List<Vector2> ConfirmedLocations = new List<Vector2>();

            while (Options.Count > 0)
            {
                List<Site> NewOptions = new List<Site>();
                for (int I = 0; I < Options.Count; I++)
                {

                    Vector2 NewLoc = Options[I].Loc + Options[I].NextDirection;
                    int Result = CollisionCheck.Instance.CheckTarget(map.Collision.CMap, NewLoc);
                    if (Result == 0)
                    {//encounters void
                        //failed, don't add to next round
                    }
                    else if (Result >= 30)
                    {
                        if (!ConfirmedLocations.Contains(NewLoc))
                        {
                            //pass - don't add to options, but to confirmedlocations
                            ConfirmedLocations.Add(NewLoc);
                        }
                    }
                    else
                    {
                        if (Pathfinding_SiteIsUnique(Options, new Site { Loc = NewLoc, NextDirection = Options[I].NextDirection }, NewOptions))
                        {
                            NewOptions.Add(new Site { Loc = NewLoc, NextDirection = Options[I].NextDirection });
                        }
                    }
                }
                Options = new List<Site>();
                Options.AddRange(NewOptions);
            }

            return ListMethod.FilterBOutOfA(ConfirmedLocations, AlreadyUsedMidpoints);
        }

        private static bool Pathfinding_SiteIsUnique(List<Site> Previous, Site Addition, List<Site> New)
        {
            for (int S = 0; S < Previous.Count; S++)
            {
                if (Previous[S].Loc == Addition.Loc && Addition.NextDirection * -1 == Previous[S].NextDirection)
                {
                    return false;
                }
            }
            for (int S = 0; S < New.Count; S++)
            {
                if (New[S].Loc == Addition.Loc && (Addition.NextDirection * -1 == New[S].NextDirection || Addition.NextDirection == New[S].NextDirection))
                {
                    return false;
                }
            }
            return true;
        }

        public static bool TraverseMapToLocation(Vector2 FinalLocation, int FL_RoomOrPassageIn, bool FL_IsInRoom,
            Vector2 StartLocation, int SL_RoomOrPassageIn, bool SL_IsInRoom, out List<Vector2> PathTaken, Map map)
        {
            List<Vector2> CurrentPath = new List<Vector2>();
            if (FL_RoomOrPassageIn == SL_RoomOrPassageIn && FL_IsInRoom == SL_IsInRoom)
            {
                bool S = GetToLocation(FinalLocation, StartLocation, out PathTaken, map);
                return S;
            }
            else
            {
                if (SL_IsInRoom && FL_IsInRoom)
                {
                    return TraverseMapToLocation(FinalLocation, FL_RoomOrPassageIn, StartLocation, SL_RoomOrPassageIn, out PathTaken, map);
                }
                else if (FL_IsInRoom)//StartLocations is NOT in a room, but the end target is
                {
                    List<int> RoomsToPassThrough = new List<int>();
                    int RoomA = map.Passages[SL_RoomOrPassageIn].End1.EndPointID;
                    int RoomB = map.Passages[SL_RoomOrPassageIn].End2.EndPointID;
                    NetworkMethod.Dijkstras(map, FL_RoomOrPassageIn, new List<int>() { RoomA, RoomB }, out int Selected);
                    Vector2 RoomStartWaypoint, WorstRoomStartWaypoint = Vector2.Zero;//these value will be changed
                    int BestRoom, WorstRoom;
                    if (Selected == 0)
                    {//Room A is closer to end of route
                        BestRoom = RoomA;
                        WorstRoom = RoomB;
                        //find the correct entry point to room B from your location, and the other one in case this is impossible
                        RoomStartWaypoint = map.Passages[SL_RoomOrPassageIn].End1.Location;
                        WorstRoomStartWaypoint = map.Passages[SL_RoomOrPassageIn].End2.Location;
                    }
                    else
                    {//Room B is closer to end of route
                        BestRoom = RoomB;
                        WorstRoom = RoomA;
                        //find the correct entry point to room B from your location, and the other one in case this is impossible
                        RoomStartWaypoint = map.Passages[SL_RoomOrPassageIn].End2.Location;
                        WorstRoomStartWaypoint = map.Passages[SL_RoomOrPassageIn].End1.Location;
                    }


                    if (GetToLocation(RoomStartWaypoint, StartLocation, out List<Vector2> FirstBit, map))
                    {
                        if (TraverseMapToLocation(FinalLocation, FL_RoomOrPassageIn, FL_IsInRoom,
             RoomStartWaypoint, BestRoom, true, out List<Vector2> RegularSection, map))
                        {
                            PathTaken = FirstBit;
                            PathTaken.AddRange(RegularSection);
                            return true;
                        }
                    }
                    if (GetToLocation(WorstRoomStartWaypoint, StartLocation, out FirstBit, map))
                    {//if the first way does not work for some reason, try the other way
                        if (TraverseMapToLocation(FinalLocation, FL_RoomOrPassageIn, FL_IsInRoom,
             WorstRoomStartWaypoint, WorstRoom, true, out List<Vector2> RegularSection, map))
                        {
                            PathTaken = FirstBit;
                            PathTaken.AddRange(RegularSection);
                            return true;
                        }
                    }

                    // otherwise, neither route is possible
                    PathTaken = new List<Vector2>();
                    return false;

                }
                else if (SL_IsInRoom)
                {//final location is in a passageway
                    List<int> RoomsToPassThrough = new List<int>();
                    int RoomA = map.Passages[FL_RoomOrPassageIn].End1.EndPointID;
                    int RoomB = map.Passages[FL_RoomOrPassageIn].End2.EndPointID;
                    NetworkMethod.Dijkstras(map, SL_RoomOrPassageIn, new List<int>() { RoomA, RoomB }, out int Selected);
                    Vector2 RoomEndWaypoint = Vector2.Zero;//this value will be changed
                    int BestRoom;
                    if (Selected == 0)
                    {//Room A is closer to start of route
                        //find the correct entry point to room B from your location
                        BestRoom = RoomA;
                        for (int I = 0; I < map.Rooms[RoomA].EntryPoints.Count; I++)
                        {
                            if (map.Rooms[RoomA].EntryPoints[I].PassagewayUsing == SL_RoomOrPassageIn)
                            {
                                RoomEndWaypoint = map.Rooms[RoomA].EntryPoints[I].Location;
                                break;
                            }
                        }
                    }
                    else
                    {//Room B is closer to start of route
                        BestRoom = RoomB;
                        //find the correct entry point to room B from your location
                        for (int I = 0; I < map.Rooms[RoomB].EntryPoints.Count; I++)
                        {
                            if (map.Rooms[RoomB].EntryPoints[I].PassagewayUsing == SL_RoomOrPassageIn)
                            {
                                RoomEndWaypoint = map.Rooms[RoomB].EntryPoints[I].Location;
                            }
                        }
                    }

                    if (GetToLocation(RoomEndWaypoint, StartLocation, out List<Vector2> LastBit, map))
                    {
                        if (TraverseMapToLocation(RoomEndWaypoint, BestRoom, StartLocation, SL_RoomOrPassageIn, out List<Vector2> RegularSection, map))
                        {
                            PathTaken = RegularSection;
                            PathTaken.AddRange(LastBit);
                            return true;
                        }
                    }

                    throw new Exception();

                }
                else
                {//NEITHER is in a room
                    List<int> RoomsToPassThrough = new List<int>();
                    int RoomA = map.Passages[FL_RoomOrPassageIn].End1.EndPointID;
                    int RoomB = map.Passages[FL_RoomOrPassageIn].End2.EndPointID;

                    int RoomC = map.Passages[SL_RoomOrPassageIn].End1.EndPointID;
                    int RoomD = map.Passages[SL_RoomOrPassageIn].End2.EndPointID;

                    NetworkMethod.Dijkstras(map, RoomC, new List<int>() { RoomA, RoomB }, out int SelectedAB_C, out int Distance_C);
                    NetworkMethod.Dijkstras(map, RoomD, new List<int>() { RoomA, RoomB }, out int SelectedAB_D, out int Distance_D);

                    int BestFirstRoom = 0;
                    int BestLastRoom = 0;
                    Vector2 RoomStartPoint = new Vector2();
                    Vector2 RoomEndPoint = new Vector2();

                    if (Distance_C < Distance_D)
                    {
                        BestLastRoom = RoomC;
                        if (SelectedAB_C == 0)
                        {
                            BestFirstRoom = RoomA;
                        }
                        else
                        {
                            BestFirstRoom = RoomB;
                        }
                    }
                    else
                    {
                        BestLastRoom = RoomD;
                        if (SelectedAB_D == 0)
                        {
                            BestFirstRoom = RoomA;
                        }
                        else
                        {
                            BestFirstRoom = RoomB;
                        }
                    }
                    //find the correct entry point to room B from your location
                    for (int I = 0; I < map.Rooms[BestFirstRoom].EntryPoints.Count; I++)
                    {
                        if (map.Rooms[BestFirstRoom].EntryPoints[I].PassagewayUsing == SL_RoomOrPassageIn)
                        {
                            RoomStartPoint = map.Rooms[BestFirstRoom].EntryPoints[I].Location;
                        }
                    }
                    for (int I = 0; I < map.Rooms[BestLastRoom].EntryPoints.Count; I++)
                    {
                        if (map.Rooms[BestLastRoom].EntryPoints[I].PassagewayUsing == FL_RoomOrPassageIn)
                        {
                            RoomStartPoint = map.Rooms[BestLastRoom].EntryPoints[I].Location;
                        }
                    }

                    if (RoomStartPoint != null && RoomEndPoint != null)
                    {
                        GetToLocation(RoomStartPoint, StartLocation, out List<Vector2> FirstBit, map);
                        GetToLocation(FinalLocation, RoomEndPoint, out List<Vector2> LastBit, map);



                        if (TraverseMapToLocation(RoomEndPoint, BestLastRoom, RoomStartPoint, BestFirstRoom, out List<Vector2> RegularBit, map))
                        {

                            PathTaken = FirstBit;
                            PathTaken.AddRange(RegularBit);
                            PathTaken.AddRange(LastBit);
                            return true;
                        }
                        else
                        {
                            throw new Exception();
                        }
                    }
                    else
                    {
                        throw new Exception();
                    }
                }
            }
        }

        public static bool TraverseMapToLocation(Vector2 FinalLocation, int FL_RoomIn, Vector2 StartLocation, int SL_RoomIn, out List<Vector2> PathTaken, Map map)
        //assumes that both target and start are in (different) rooms
        {



            List<Vector2> CurrentPath = new List<Vector2>();
            List<int> RoomsToPassThrough = new List<int>();
            RoomsToPassThrough.AddRange(NetworkMethod.Dijkstras(map, SL_RoomIn, FL_RoomIn));
            List<Vector2> Waypoints = new List<Vector2>() { StartLocation };
            Waypoints.AddRange(TraverseMap_Make_Waypoints(RoomsToPassThrough, FinalLocation, FL_RoomIn, out List<int> WaypointRooms, map));
            Waypoints = ListMethod.RemoveConsecDuplicates(Waypoints);
            for (int W = 1; W < Waypoints.Count; W++)
            {
                List<Vector2> NewPath = new List<Vector2>();
                if (GetToLocation(Waypoints[W], Waypoints[W - 1], out NewPath, map))
                {
                    if (CurrentPath.Count > 0)
                    {
                        if (NewPath[0] == CurrentPath[CurrentPath.Count - 1])
                        {
                            NewPath.RemoveAt(0);
                        }
                    }

                    CurrentPath.AddRange(NewPath);
                }
                else
                {
                    PathTaken = new List<Vector2>();
                    return false;
                }
            }
            PathTaken = CurrentPath;
            return true;
        }

        public static List<Vector2> TraverseMap_Make_Waypoints(List<int> RoomIDsInOrder, Vector2 FinalLocation, int FinalLocationRoom, out List<int> WaypointsRooms, Map map)//for circular routes.
        //NOTE: These rooms should all be connected. Call Dijkstra's Algorithm to  organise the list first.
        {

            List<Vector2> Waypoints = new List<Vector2>();
            List<int> RoomsOfWaypoints = new List<int>();

            for (int I = 1; I < RoomIDsInOrder.Count; I++)
            {
                int RoomFrom = RoomIDsInOrder[I - 1];
                int RoomTo = RoomIDsInOrder[I];
                for (int E = 0; E < map.Rooms[RoomFrom].EntryPoints.Count; E++)
                {
                    if (map.Rooms[RoomFrom].EntryPoints[E].RoomTo == RoomTo)
                    {
                        Waypoints.Add(map.Rooms[RoomFrom].EntryPoints[E].Location);
                        RoomsOfWaypoints.Add(RoomFrom);
                        break;
                    }
                }
                for (int E = 0; E < map.Rooms[RoomTo].EntryPoints.Count; E++)
                {
                    if (map.Rooms[RoomTo].EntryPoints[E].RoomTo == RoomFrom)
                    {
                        Waypoints.Add(map.Rooms[RoomTo].EntryPoints[E].Location);
                        RoomsOfWaypoints.Add(RoomTo);
                        break;
                    }
                }

            }
            Waypoints.Add(FinalLocation);
            RoomsOfWaypoints.Add(FinalLocationRoom);

            WaypointsRooms = RoomsOfWaypoints;
            return Waypoints;
        }



        //handling extra sets of Vector2 Obstacles
        public static bool GetToLocation(Vector2 FinalLocation, Vector2 StartLocation, out List<Vector2> PathTaken, Map map, List<Vector2> ExtraObstacles)
        {
            PathTaken = new List<Vector2>();
            return GetToLocation(FinalLocation, StartLocation, out PathTaken, map, new List<Vector2>(), 0, ExtraObstacles);
        }

        private static bool GetToLocation(Vector2 FinalLocation, Vector2 StartLocation, out List<Vector2> PathTaken, Map map, List<Vector2> AlreadyUsedMidpoints, int RecLayer, List<Vector2> ExtraObstacles)
        ///KnightPath algorithm
        ///creates a sequential list of co-ordinates to follow 1 by 1 to reach a destination.
        /// the boolean refers to whether such a location is accessible; the ouptut list is how you get there.
        {
            RecLayer++;

            if (FinalLocation == StartLocation)
            {
                PathTaken = new List<Vector2>();

                return true;
            }
            else if (RecLayer > 6)
            {
                PathTaken = new List<Vector2>();
                return false;
            }
            else
            {


                if (CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, ExtraObstacles, FinalLocation))
                {
                    int DistanceX = (int)FinalLocation.X - (int)StartLocation.X;
                    int DistanceY = (int)FinalLocation.Y - (int)StartLocation.Y;
                    Vector2 Movement = new Vector2(DistanceX, DistanceY);
                    //try with horizntal-first L
                    bool CanHoriFirst = Pathfinding_Check_Path(StartLocation, Movement, false, map, out Vector2 HoriProb, out bool HoriProbIsVertical, ExtraObstacles);
                    //try with vertical-first L
                    bool CanVertiFirst = Pathfinding_Check_Path(StartLocation, Movement, true, map, out Vector2 VertiProb, out bool VertiProbIsVertical, ExtraObstacles);

                    if (CanVertiFirst)
                    {
                        if (CanHoriFirst && map.D.Next(0, 100) > 50)
                        {
                            PathTaken = Pathfinding_Return_Path(StartLocation, Movement, false);
                            return true;
                        }
                        else
                        {
                            PathTaken = Pathfinding_Return_Path(StartLocation, Movement, true);
                            return true;
                        }
                    }
                    else if (CanHoriFirst)
                    {
                        PathTaken = Pathfinding_Return_Path(StartLocation, Movement, false);
                        return true;
                    }
                    else
                    {//if neither work, go along the obstacles from each to find a valid midpoint, if any.
                        List<Vector2> Midpoints = Pathfinding_Find_Midpoints(HoriProb, HoriProbIsVertical, VertiProb, VertiProbIsVertical, map, ExtraObstacles);
                        Midpoints = ListMethod.FilterBOutOfA(Midpoints, AlreadyUsedMidpoints);
                        //if none, return false
                        if (Midpoints.Count == 0)
                        {
                            PathTaken = new List<Vector2>();//irrelevant, but must set out variable
                            return false;
                        }

                        else
                        {//(else) if some, Pathfind from start to any of these 4 midpoints, and from those midpoints to the end point.
                            List<List<Vector2>> Options = new List<List<Vector2>>();
                            AlreadyUsedMidpoints.AddRange(Midpoints);
                            for (int O = 0; O < Midpoints.Count; O++)
                            {
                                bool Valid = GetToLocation(Midpoints[O], StartLocation, out List<Vector2> FirstStint, map, AlreadyUsedMidpoints, RecLayer, ExtraObstacles);
                                if (Valid)
                                {
                                    Valid = GetToLocation(FinalLocation, Midpoints[O], out List<Vector2> SecondStint, map, AlreadyUsedMidpoints, RecLayer, ExtraObstacles);
                                    if (Valid)
                                    {
                                        FirstStint.AddRange(SecondStint);
                                        Options.Add(FirstStint);
                                    }
                                }
                            }

                            if (Options.Count == 0)
                            {
                                PathTaken = new List<Vector2>();
                                return false;
                            }
                            else if (Options.Count == 1)
                            {//return the only valid route
                                PathTaken = Options[0];
                                return true;
                            }
                            else//2+different Options
                            {
                                //for the above <=4 valid solutions, pick the one with the shortest list of locations, as it is most efficient,
                                //and return that.
                                int Shortest = Options[0].Count;
                                int ShortestIndex = 0;
                                for (int I = 1; I < Options.Count; I++)
                                {
                                    if (Options[I].Count < Shortest)
                                    {
                                        Shortest = Options[I].Count;
                                        ShortestIndex = I;
                                    }
                                }
                                PathTaken = Options[ShortestIndex];
                                return true;
                            }
                        }
                    }
                }
                else//target location isn't even valid
                {
                    PathTaken = new List<Vector2>();
                    return false;
                }
            }
        }
        // ^^^ Not handled List<Vector2> PreviousLocations to prevent doubling back - add it to CheckPath vv

        public static bool Pathfinding_Check_Path(Vector2 StartLocation, Vector2 Movement,
           bool VerticalFirst, Map map, out Vector2 FirstProblem, out bool ProblemWasVertical, List<Vector2> ExtraObstacles)
        {
            if (VerticalFirst)
            {
                for (int Y = (int)0; MathMethod.Modulus(Y) < MathMethod.Modulus(Movement.Y); Y += Math.Sign(Movement.Y))
                {
                    if (!CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, ExtraObstacles, StartLocation + new Vector2(0, Y)))
                    {
                        FirstProblem = StartLocation + new Vector2(0, Y);
                        ProblemWasVertical = true;
                        return false;
                    }
                }
                //now horizontal
                for (int X = (int)0; MathMethod.Modulus(X) < MathMethod.Modulus(Movement.X); X += Math.Sign(Movement.X))
                {
                    if (!CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, ExtraObstacles, StartLocation + new Vector2(X, Movement.Y)))
                    {
                        FirstProblem = StartLocation + new Vector2(X, Movement.Y);
                        ProblemWasVertical = false;
                        return false;
                    }
                }
                FirstProblem = Vector2.Zero;
                ProblemWasVertical = false;
                return true;
            }
            else
            {//horizontal first
                for (int X = 0; MathMethod.Modulus(X) < MathMethod.Modulus(Movement.X); X += Math.Sign(Movement.X))
                {
                    if (!CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, ExtraObstacles, StartLocation + new Vector2(X, 0)))
                    {
                        FirstProblem = StartLocation + new Vector2(X, 0);
                        ProblemWasVertical = false;
                        return false;
                    }
                }
                //now vertical
                for (int Y = 0; MathMethod.Modulus(Y) < MathMethod.Modulus(Movement.Y); Y += Math.Sign(Movement.Y))
                {
                    if (!CollisionCheck.Instance.CheckTargetBool(map.Collision.CMap, ExtraObstacles, StartLocation + new Vector2(Movement.X, Y)))
                    {
                        FirstProblem = StartLocation + new Vector2(Movement.X, Y);
                        ProblemWasVertical = true;
                        return false;
                    }
                }
                FirstProblem = Vector2.Zero;
                ProblemWasVertical = false;
                return true;
            }
        }

        private static List<Vector2> Pathfinding_Find_Midpoints(Vector2 FirstIssue, bool FirstIssueEncounteredWhenVertical, Vector2 Second, bool SecondVerti, Map map, List<Vector2> ExtraObstacles, List<Vector2> AlreadyUsedMidpoints)
        {
            List<Site> Options = new List<Site>();

            if (FirstIssueEncounteredWhenVertical)
            {
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(1, 0) });
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(-1, 0) });
            }
            else
            {
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(0, 1) });
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(0, -1) });
            }

            if (SecondVerti)
            {
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(1, 0) });
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(-1, 0) });
            }
            else
            {
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(0, 1) });
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(0, -1) });
            }

            List<Vector2> ConfirmedLocations = new List<Vector2>();

            while (Options.Count > 0)
            {
                List<Site> NewOptions = new List<Site>();
                for (int I = 0; I < Options.Count; I++)
                {

                    Vector2 NewLoc = Options[I].Loc + Options[I].NextDirection;
                    int Result = CollisionCheck.Instance.CheckTarget(map.Collision.CMap, ExtraObstacles, NewLoc);
                    if (Result == 0)
                    {//encounters void
                        //failed, don't add to next round
                    }
                    else if (Result >= 30)
                    {
                        if (!ConfirmedLocations.Contains(NewLoc))
                        {
                            //pass - don't add to options, but to confirmedlocations
                            ConfirmedLocations.Add(NewLoc);
                        }
                    }
                    else
                    {
                        if (Pathfinding_SiteIsUnique(Options, new Site { Loc = NewLoc, NextDirection = Options[I].NextDirection }, NewOptions))
                        {
                            NewOptions.Add(new Site { Loc = NewLoc, NextDirection = Options[I].NextDirection });
                        }
                    }
                }
                Options = new List<Site>();
                Options.AddRange(NewOptions);
            }
            return ListMethod.FilterBOutOfA(ConfirmedLocations, AlreadyUsedMidpoints);
        }
    }

    public struct Site
    {
        public Vector2 Loc;
        public Vector2 NextDirection;
    }
}
