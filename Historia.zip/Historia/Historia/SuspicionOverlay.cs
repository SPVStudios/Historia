﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Xml.Serialization;

namespace Historia
{
    class SuspicionOverlay//Dev Tool; an overlay to draw over the map to show currently suspicious tiles.
    {
        public void Draw(Vector2 MapSize)
        {/*
            int[,] Suspicions = new int[(int)MapSize.X, (int)MapSize.Y];

            foreach(KeyValuePair<Vector2, int>Suspicious in StealthManager.Instance.RoomSuspiciousPointsThisPass)
            {
                Suspicions[(int)Suspicious.Key.X, (int)Suspicious.Key.Y] += Suspicious.Value;
            }

            foreach(KeyValuePair<Rectangle,int>Noise in StealthManager.Instance.Noises)
            {
                for (int X = Noise.Key.X; X < Noise.Key.Right; X++)
                {
                    for (int Y = Noise.Key.Y; Y < Noise.Key.Bottom; Y++)
                    {
                        Suspicions[X, Y] += Noise.Value;
                    }
                }
            }
            */
        }
    }
}
