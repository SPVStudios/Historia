﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;

namespace Historia
{
    public static class WorldCollision// this is a Static class: it doesn't need instantiation, it's just for methods
    {
        ///Overview of the Land values:
        /// 0 : Ocean (impassable)
        /// 1 : shallow water (impassable)
        /// 2 : Mountains (impassable)
        /// 3 : River (impasssable)
        /// 4 : Cliff (impassable)
        /// 5 : Lake (impassable)
        /// ------------Any value >= 6 is walkable
        /// 6 : Bridge
        /// 7 : Desert
        /// 8 : Plains
        /// 9 : Grassland
        /// 10 : Forest
        /// ------------NO SWAMPS NEEDED IN THIS GAME!!!!
        /// 12 : Beach
        /// 13 : Ford
        /// 
        /// THERE WILL NOT BE ANY HILLS IN THIS GAME!!!!
        
        public static int CheckTarget(int[,] CollisionMap, Vector2 Location)
        {
            try
            {
                return CollisionMap[(int)Location.X, (int)Location.Y];
            }
            catch
            {
                return 0;
            }
        }

        public static int CheckTarget(int[,] CollisionMap, List<Vector2> ExtraObstacles, Vector2 Location)
        {
            if (!ExtraObstacles.Contains(Location))
            {
                try
                {

                    return CollisionMap[(int)Location.X, (int)Location.Y];
                }
                catch (IndexOutOfRangeException)
                {
                    return -1;
                }
            }
            else
            {
                return 0;
            }

        }

        // A numerical CheckTarget for a BeingColl only cannot exist, as a pass collision has no set value


        public static bool CheckTargetBool(int[,] CollisionMap, Vector2 Location, int MinPass)
        {
            try
            {
                if (CollisionMap[(int)Location.X, (int)Location.Y] >= MinPass)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (IndexOutOfRangeException)
            {
                return false;
            }
        }

        public static bool CheckTargetBool(int[,] CollisionMap, List<Vector2> ExtraObstacles, Vector2 Location, int MinPass)
        {
            try
            {
                if (CollisionMap[(int)Location.X, (int)Location.Y] >= MinPass)
                {
                    if (!ExtraObstacles.Contains(Location))
                    {
                        return true;
                    }
                    else
                    {
                        return false;//definitely false, given as Extra Obstacle
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (IndexOutOfRangeException)
            {
                return false;
            }
        }

        public static bool CheckListBool(int[,] ColllisionMap, List<Vector2> Locations, int MinPass)
        {
            for (int I = 0; I < Locations.Count; I++)
            {
                if (!CheckTargetBool(ColllisionMap, Locations[I], MinPass))
                {//checked on the individual basis for overrides

                    return false;


                }
            }
            return true;
        }

        public static List<Vector2> FilterList(int[,] CollisionMap, List<Vector2> Filtering, int MinPass)
        {
            for (int I = 0; I < Filtering.Count; I++)
            {
                if (!CheckTargetBool(CollisionMap, Filtering[I],MinPass))//checked for overrules on the individual basis
                {
                    Filtering.RemoveAt(I);
                    I--;
                }

            }
            return Filtering;
        }

        
    }
}
