﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Xml.Serialization;
using System.Xml;


namespace Historia
{
    public class SuspicionBar
    {
        public Image Foreground;
        public Image Background;

        [XmlElement("LevelIcon")]
        public List<Image> LevelIcons;

        double AmountofPixelsInFull;

        int BottomOfSourceBar;
        int StandardBottomBarY;

        public SuspicionBar()
        {
            Foreground = new Image();
            Background = new Image();

            LevelIcons = new List<Image>();
        }


        public void LoadContent()
        {
            Foreground.LoadContent();
            AmountofPixelsInFull = Foreground.SourceRect.Height;

            Background.LoadContent();
            StandardBottomBarY = Background.LocationOnScreen.Bottom;
            BottomOfSourceBar = Background.SourceRect.Bottom;
            for(int I = 0; I < LevelIcons.Count; I++)
            {
                LevelIcons[I].LoadContent();
            }
        }

        public void Draw(SpriteBatch spriteBatch, int CurrentAverageSuspicionPoints)
         {
            Background.Draw(spriteBatch);
            int AvgSuspicionLevel = CurrentAverageSuspicionPoints / Enemy.AlertPointsPerLevel;
            double LeftOverPoints = CurrentAverageSuspicionPoints % Enemy.AlertPointsPerLevel;
            double PixelsTall = Math.Round(((AmountofPixelsInFull * LeftOverPoints) / Enemy.AlertPointsPerLevel));
            
            Foreground.SourceRect.Height = (int)PixelsTall;
            int PixelsOnScreenTall = (int)(PixelsTall * Foreground.Scale.Y);
            Foreground.SourceRect.Y = BottomOfSourceBar - (int)PixelsTall;
            Foreground.Position.Y = StandardBottomBarY - PixelsOnScreenTall;
            //int AdjustPixels = Foreground.LocationOnScreen.Bottom - StandardBottomBarY;
            //Foreground.Position.Y -= AdjustPixels;

            Foreground.Draw(spriteBatch);

            LevelIcons[AvgSuspicionLevel].Draw(spriteBatch);

        }


    }
}
