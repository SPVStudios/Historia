﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Xml.Serialization;

namespace Historia
{
    public class Player : Being
    {
        

        public Player()
        {
            CollisionType = 6;
        }

        //load content as a Being would

        //unload content as a Being would

        protected override bool DecideWhattoDo(GameTime gameTime, out int Action)
        {
            switch (InputManager.Instance.ActionKey)
            {
                /// <summary ActionFrameSet>
                /// The multiple of 4 referrring to the animation of whichever current action should be ocurring.
                /// Key:
                /// 0 = idle
                /// 1 = movement
                /// 2 = running
                /// 3 = regular attacking
                /// 4 = heavy attacking
                /// 5 = dodging
                /// 6 = blocking
                /// 7 = parrying
                /// 8 = sneaking
                /// 9 = climbing into a container
                /// 10 = climbing out of a container
                /// 
                /// These numbers are used both by animations and to determine by update logic what action is currently being taken.
                /// 
                /// </summary>
                
                case Keys.R://Facing
                    Action = -1;
                    break;
                    
                case Keys.Space://Attack
                    if (InputManager.Instance.ModifierKey == Keys.LeftShift)
                    {
                        Action = 4;
                        break;
                    }
                    else
                    {
                        Action = 3;
                        break;
                    }
                case Keys.C://Dodge
                    Action = 5;
                    break;
                case Keys.B://Block
                    Action = 6;
                    break;
                case Keys.V://Parry
                    Action = 7;
                    break;
                case Keys.F://Interact
                    Action = 9;
                    break;
                case Keys.G://Special Moves 1 + 2
                    if (InputManager.Instance.ModifierKey == Keys.LeftShift)
                    {
                        Action = 10;
                        break;
                    }
                    else
                    {
                        Action = 11;
                        break;
                    }
                case Keys.H://Special Moves 3 + 4
                    if (InputManager.Instance.ModifierKey == Keys.LeftShift)
                    {
                        Action = 12;
                        break;
                    }
                    else
                    {
                        Action = 13;
                        break;
                    }
                case Keys.N://Special Moves 5 + 6
                    if (InputManager.Instance.ModifierKey == Keys.LeftShift)
                    {
                        Action = 14;
                        break;
                    }
                    else
                    {
                        Action = 15;
                        break;
                    }

                case Keys.Sleep://no action buttons; default is walking if there is a target location
                    Action = 0;
                    break;
                    
                default:
                    throw new Exception("NewActionButton");
            }
            if (Action != 0)//if is doing something in particular
            {
                if(Action == -1)//if is a facing command, correct the -1 that got through this step back to idle's animation
                {
                    Action = 0;
                }
                switch (InputManager.Instance.DirectionKey)
                {
                    case Keys.W:
                        FacingAddup = 3;
                        return true;
                    case Keys.A:
                        FacingAddup = 1;
                        return true;
                    case Keys.S:
                        FacingAddup = 0;
                        return true;
                    case Keys.D:
                        FacingAddup = 2;
                        return true;
                    default:
                        return true;
                }
            }
           else//isn't acting... check if moving in some way instead.
            {
                switch (InputManager.Instance.DirectionKey)
                {
                    case Keys.W:
                FacingAddup = 3;
                        Action = CheckWalkType();
                        return true;
                    case Keys.A:
                        FacingAddup = 1;
                        Action = CheckWalkType();
                        return true;
                    case Keys.S:
                        FacingAddup = 0;
                        Action = CheckWalkType();
                        return true;

                    case Keys.D:
                        FacingAddup = 2;
                        Action = CheckWalkType();
                        return true;

                    default:
                        Action = 0;
                        return false;
            }
                
            }
        }

        public override void Update(GameTime gameTime, out bool Died)
        {
            base.Update(gameTime, out Died);
            if (IsInRoom)
            {
                StealthManager.Instance.AddOrMaintainSuspiciousThings(TilePosition, StealthManager.VisualPlayerSupicion, CurrentRoomIn, true);
            }
            else
            {
                StealthManager.Instance.AddOrMaintainSuspiciousThings(TilePosition, StealthManager.VisualPlayerSupicion, CurrentPassagewayIn, false);
            }
            
            StealthManager.Instance.MakeNewNoise(TilePosition, CurrentNoiseOutput);
            StealthManager.Instance.UpdatePlayerLoc(TilePosition);
        }
        //adds actions as a suspicious thing

        private int CheckWalkType()
        {
            switch (InputManager.Instance.ModifierKey)
            {
                case Keys.LeftShift://Run
                    return 2;
                case Keys.LeftControl://sneak
                    return 8;
                default:
                    return 1;
            }
        }

        protected override void StartMove()
        {
            if (CheckWalkValid())
            {
                IsBusy = true;
                mapRef.BC.Claim(CollisionType,TilePosition);
            }
        }
    }
}
