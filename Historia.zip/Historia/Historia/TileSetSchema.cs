﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;

namespace Historia
{
    public class FloorTileSetSchema
    {
        public class TileThemeSchema
        {
            public bool BaseTile_HasAlternate;
            public int BaseTile_NumAlternates;
            
        }

        [XmlElement("TileTheme")]
        public List<TileThemeSchema> TileThemes;
        public string Path;

    }
}
