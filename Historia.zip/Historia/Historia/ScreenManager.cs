﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System.IO;
using Historia;
using System.Xml.Serialization;

public class ScreenManager//this will manage all loading to and from the various screens in the game.
{
    private static ScreenManager instance;//All the functions of the class are called through this "instance". The
                                          //Following get loop means the instance is created if none are already present but otherwise uses the current
                                          //one, meaning there will only ever be one instance of the ScreenManager running.
    [XmlIgnore]
    public Vector2 Dimensions { private set; get; }
    [XmlIgnore]
    public ContentManager Content { private set; get; }
    XmlManager<GameScreen> xmlGameScreenManager;

    public Image Image;
    [XmlIgnore]
    public bool IsTransitioning { get; private set; }

    [XmlIgnore]
    public Game1 GameRef;



    public static ScreenManager Instance
    {
        get
        {
            if (instance == null)
            {
                XmlManager<ScreenManager> xml = new XmlManager<ScreenManager>();
                instance = xml.Load("Load/ScreenManager.xml");
                
            }

            return instance;
        }
    }

    [XmlIgnore]
   public GameScreen CurrentScreen
    {
        get
        {
            return currentScreen;
        }
    }
    
    GameScreen currentScreen;//keeps track of which screen class is being used to be used as an
    //identifier, so the code runs the method loading content from the class assigned as the current screen.
    GameScreen newScreen;

    [XmlIgnore]
    public GraphicsDevice GraphicsDevice;//don't want these messed with by the XmlManager - ever!
    [XmlIgnore]
    public SpriteBatch SpriteBatch;//again, important bits - not to be messed with!
    
    public ScreenManager()//on initialisation of ScreenManager....
    {
        //Initiate Splash Screen
        Dimensions = new Vector2(640, 480);
        currentScreen = new SplashScreen();
        xmlGameScreenManager = new XmlManager<GameScreen>();
        xmlGameScreenManager.Type = currentScreen.Type;//sets the type of the 
        currentScreen = xmlGameScreenManager.Load("Load/SplashScreen.xml");
        //^^ This creates a new class of the current screen, but also loads the data for its variables from
        //the xml file in the given file path, courtesy of the xmlScreenManager.
    }


    public void ChangeScreens(string screenName)
    {
        if (!IsTransitioning)
        {
            newScreen = (GameScreen)Activator.CreateInstance(Type.GetType("Historia." + screenName));
            //creates a new screen of whatever is called in the method
            Image.IsActive = true;
            Image.FadeEffect.Increase = true;
            Image.Alpha = 0.0f;
            IsTransitioning = true;
        }
    }

    void Transition(GameTime gameTime)//this will be called in the main loop
    {
        if (IsTransitioning == true)
        {
            Image.Update(gameTime);
            if(Image.Alpha == 1.0f)
            {
                currentScreen.UnloadContent();
                currentScreen = newScreen;
                xmlGameScreenManager.Type = currentScreen.Type;
                if (File.Exists(currentScreen.XmlPath))
                {
                    currentScreen = xmlGameScreenManager.Load(currentScreen.XmlPath);
                }
                currentScreen.LoadContent();
            }
            else if(Image.Alpha == 0.0f)//if the fade out/in has finished
            {
                Image.IsActive = false;//remove the (now invisible) mega black rectangle from the screen
                IsTransitioning = false;
            }
        }
    }

    public void LoadContent(ContentManager Content)//this loads content to memory for a given screen
    {
        this.Content = new ContentManager(Content.ServiceProvider, "Content");
        currentScreen.LoadContent();
        Image.LoadContent();
    }

    public void UnloadContent()//this unloads content from memory that is no longer required, eg title screen
                               //images, to free up space.
    {
        currentScreen.UnloadContent();
        Image.UnloadContent();
    }

    public void Update(GameTime gameTime)//this will update game elements
    {
        currentScreen.Update(gameTime);
        Transition(gameTime);

    }

    public void Draw(SpriteBatch spriteBatch)//this will draw everything to the screen.
    {
        currentScreen.Draw(spriteBatch);
        if (IsTransitioning)
        {
            Image.Draw(spriteBatch);
        }
    }

    public void GiveGameRef(Game1 GameRef)
    {
        this.GameRef = GameRef;
    }
    
}
