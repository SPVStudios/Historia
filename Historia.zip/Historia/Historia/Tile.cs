﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Historia
{
    public class Tile
    {
        
        protected Vector2 texturePoint;
        public int WhichTileSet;

        public Vector2 SourcePoint//public version that is read-only
        {
            get { return texturePoint; }

        }

        public virtual void LoadContent( Vector2 sourceRect, int whichTileSet)
        {
            
            this.texturePoint = sourceRect;
            this.WhichTileSet = whichTileSet;
        }

        public virtual void UnloadContent()
        {

        }
        



    }
}
