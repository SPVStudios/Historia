﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Xml.Serialization;
using Microsoft.Xna.Framework.Input;

namespace Historia
{
    public class WorldScreen : GameScreen
    {

        public WorldAvatar player;
        [XmlIgnore]
        public WorldMap map;
        Camera camera;

        [XmlIgnore]
        public Vector2 TileDimensions;

        SpriteFont font;

        Vector2 tilesOnScreen;
        const int NumOfEnemies = 2;
        Random D;
        public InfoPanel infoPanel;
        bool CanTravel;

        public WorldScreen()
        {
            player = new WorldAvatar();
            map = new WorldMap();
            D = new Random();
            infoPanel = new InfoPanel();
            CanTravel = false;
        }

        public override void LoadContent()
        {
            base.LoadContent();
            Vector2 PlayerLoc;
            if (GameState.Instance.EnteringWorld && GameState.Instance.WorldMap != null)
            {
                map = GameState.Instance.WorldMap;
                map.LoadContent(true);
                TileDimensions = map.TileDimensions;
                PlayerLoc = GameState.Instance.WorldMapLocation;

            }
            else
            {
                map.Create(new Vector2(120, 120));
                map.LoadContent(true);
                TileDimensions = map.TileDimensions;
                PlayerLoc = FindValidSpawn(map.Collision, map.Size);
            }

            XmlManager<WorldAvatar> playerLoader = new XmlManager<WorldAvatar>();
            player = playerLoader.Load("Load/Gameplay/WorldAvatar.xml");

            ContentManager content = new ContentManager(ScreenManager.Instance.Content.ServiceProvider, "Content");
            font = content.Load<SpriteFont>("Gameplay/Fonts/Font1");
            XmlManager<InfoPanel> IL = new XmlManager<InfoPanel>();
            infoPanel = IL.Load("Load/Gameplay/InfoPanel.xml");
            infoPanel.LoadContent(map);


            int tilesacross;
            if (ScreenManager.Instance.Dimensions.X % map.TileDimensions.X != 0)
            {
                tilesacross = ((int)ScreenManager.Instance.Dimensions.X / (int)map.TileDimensions.X) + 1;
            }
            else
            {
                tilesacross = ((int)ScreenManager.Instance.Dimensions.X / (int)map.TileDimensions.X);
            }
            int tilesdown;
            if (ScreenManager.Instance.Dimensions.Y % map.TileDimensions.Y != 0)
            {
                tilesdown = ((int)ScreenManager.Instance.Dimensions.Y / (int)map.TileDimensions.Y) + 1;
            }
            else
            {
                tilesdown = ((int)ScreenManager.Instance.Dimensions.Y / (int)map.TileDimensions.Y);
            }
            tilesOnScreen = new Vector2(tilesacross, tilesdown);
            
            player.LoadContent(TileDimensions, PlayerLoc,map);


            camera = new Camera(map.Size, tilesOnScreen, map.TileDimensions, player.TilePosition);
            GameState.Instance.EnteringWorld = GameState.Instance.EnteringVillage = GameState.Instance.EnteringDungeon = false;
        }
        public override void UnloadContent()
        {
            base.UnloadContent();
            map.UnloadContent();
            player.UnloadContent();
        }

        public Vector2 FindValidSpawn(int[,] Coll, Vector2 size)
        {
            while (true)
            {


                int X = D.Next((int)size.X / 10, ((int)size.X * 9) / 10);
                int Y = D.Next((int)size.Y / 10, ((int)size.Y * 9) / 10);
                Vector2 Loc = new Vector2(X, Y);
                if(WorldCollision.CheckTargetBool(Coll,Loc, 6))
                {
                    if(WorldPathfinding.GetToLocation(WorldMap.NearestVillage(Loc,map.Villages).Location,Loc,out List<Vector2> useless, Coll, D, 6))
                    {
                        return Loc;
                    }
                }
            }
        }


        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            if (CanTravel && InputManager.Instance.KeyPressed(Keys.Enter, Keys.Z))
            {
                if (infoPanel.IsVillage)
                {
                    EnterVillage();
                }
                else
                {
                    EnterDungeon();
                }
            }
            InputManager.Instance.Update(gameTime);
            infoPanel.Update(gameTime, player.TilePosition);
            CanTravel = infoPanel.IsActive;
            player.Update(gameTime);
            map.Update(gameTime);
            
            camera.Update(gameTime, player.TilePosition, player.Offset, map.FullMap);
        }
        //as a matter of course, it is probably wise to update your map AFTER your player, but
        //draw your map BEFORE your player.
        //some map elements are based on how the player moves, but you do not want the map drawn OVER the player.

        public override void Draw(SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);
            map.Draw(spriteBatch, camera);
            infoPanel.Draw(spriteBatch);
            player.Draw(spriteBatch, camera);
        }

        public void EnterDungeon()
        {
            SaveGameState(false);

            ScreenManager.Instance.ChangeScreens("GameplayScreen");

        }

        public void EnterVillage()
        {
            SaveGameState(true);
            ScreenManager.Instance.ChangeScreens("VillageScreen");
        }

        public void SaveGameState(bool ForVillage)
        {
            GameState.Instance.WorldMap = map;
            GameState.Instance.WorldMapLocation = player.TilePosition;
            if (ForVillage)
            {
                GameState.Instance.VillageName = infoPanel.CurrentPlaceName;
                GameState.Instance.EnteringVillage = true;
                GameState.Instance.EnteringDungeon = GameState.Instance.EnteringWorld = false;
                
            }
            else
            {
                GameState.Instance.DungeonName = infoPanel.CurrentPlaceName;
                GameState.Instance.EnteringDungeon = true;
                GameState.Instance.EnteringVillage = GameState.Instance.EnteringWorld = false;
                
                
            }
        }
    }
}