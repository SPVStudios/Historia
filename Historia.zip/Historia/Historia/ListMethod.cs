﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Xml.Serialization;
using System.Xml;

namespace Historia
{
    public static class ListMethod
    {
        public static List<Vector2> RemoveConsecDuplicates(List<Vector2> Originals)
        {
            List<Vector2> New = new List<Vector2>();
            if (Originals.Count > 0)
            {
                New.Add(Originals[0]);

                for (int I = 1; I < Originals.Count; I++)
                {
                    if(Originals[I] != New[New.Count - 1])
                    {
                        New.Add(Originals[I]);
                    }
                }
                return New;
                    
            }
            else
            {
                return new List<Vector2>();

            }
        }

        public static List<Vector2> FilterBOutOfA(List<Vector2> A, List<Vector2> B)
        {
            for (int I = 0; I < A.Count; I++)
            {
                for (int J = 0; J < B.Count; J++)
                {
                    if (A[I] == B[J])
                    {
                        A.RemoveAt(I);
                        I--;
                        break;
                    }
                }
            }
            return A;
        }

        public static List<Vector2> FilterBOutOfA(List<Vector2> A, List<Vector2> B, int MaxTimesTheSame_B_isTakenFrom_A)
        {
            int[] TimesRemoved = new int[B.Count];
            for (int I = 0; I < A.Count; I++)
            {
                for (int J = 0; J < B.Count; J++)
                {
                    if (A[I] == B[J])
                    {
                        if (TimesRemoved[J] < MaxTimesTheSame_B_isTakenFrom_A)
                        {
                            A.RemoveAt(I);
                            TimesRemoved[J]++;
                            I--;
                            break;
                        }
                    }
                }
            }
            return A;
        }

        public static List<int> FilterBOutOfA(List<int> A, List<int> B, int MaxTimesTheSame_B_isTakenFrom_A)
        {
            int[] TimesRemoved = new int[B.Count];
            for (int I = 0; I < A.Count; I++)
            {
                for (int J = 0; J < B.Count; J++)
                {
                    if (A[I] == B[J])
                    {
                        if (TimesRemoved[J] < MaxTimesTheSame_B_isTakenFrom_A)
                        {
                            A.RemoveAt(I);
                            TimesRemoved[J]++;
                            I--;
                            break;
                        }
                    }
                }
            }
            return A;
        }

        public static bool ReturnIfListsShareTerm(List<Vector2> A, List<Vector2> B, out int FirstLocA, out int LastLocB)
        {
            for (int I = 0; I < A.Count; I++)
            {
                for (int J = B.Count - 1; J >= 0; J--)
                {
                    if (A[I] == B[J])
                    {
                        FirstLocA = I;
                        LastLocB = J;
                        return true;
                    }
                }
            }
            FirstLocA = LastLocB = -1;
            return false;
        }

        public static int NumberUnique(List<int> A)
        {
            List<int> Check = new List<int>();
            int Total = 0;
            for(int I = 0; I < A.Count; I++)
            {
                if (!Check.Contains(A[I]))
                {
                    Total++;
                    Check.Add(A[I]);
                }
            }
            return Total;
        }

        public static List<Vector2> DictToKeysList(Dictionary<Vector2,int> Dict)
        {
            
            return  Dict.Keys.ToList();
        }

        public static bool IfLocIsWithinDisatnceOfList(Vector2 A, List<Vector2> SetB, int MinDistance)
        {
            foreach(Vector2 B in SetB)
            {
                Vector2 Movement = B - A;
                int Dist = MathMethod.Modulus((int)Movement.X) + MathMethod.Modulus((int)Movement.Y);
                if(Dist<= MinDistance)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
