﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;



namespace Historia
{
    public class CollFactFile
    {
        public int CollisionType;
        public bool IsPresent;//false means that the tile is merely claimed to be moved into
        public int EnemyIndex;//index in list of CurrentEnemies if it is an enemy (CollisionType 4)

        public CollFactFile(int CollisionType, bool IsPresent)
        {
            this.CollisionType = CollisionType;
            this.IsPresent = IsPresent;
        }

        public CollFactFile(int CollisionType, bool IsPresent, int EnemyIndex)
        {
            this.CollisionType = CollisionType;
            this.IsPresent = IsPresent;
            this.EnemyIndex = EnemyIndex;
        }

        public CollFactFile(CollFactFile Old)//creates a clone of the given CollFactFile that isn't just a reference to the same class
        {
            this.CollisionType = Old.CollisionType;
            this.IsPresent = Old.IsPresent;
            this.EnemyIndex = Old.EnemyIndex;
        }
       
    }

    public class Map
    {
        public class LevelCollisionMap
        {
            [XmlElement("Column")]
            public List<string> CollisionColumns;

            [XmlIgnore]
            public int[,] CMap;
            /// <summary>
            /// Determines the collision status of each tile in the map.
            /// 
            /// Key:
            /// 0 = Impassable - Void
            /// 1 = Impassable - Wall
            /// 2 = Impassable - Object
            /// 
            /// (the numbers 3-9 are reserved for beings, in the BeingCollisionMap.
            /// 
            /// 10 = Object You can climb into, with the relevant perk
            /// 
            /// 20 = Local Transition tile          -therefore 20 or more is passable, although they can have varying effects
            /// 21 = Global Transition tile
            /// 
            /// 30 = Free to move into
            /// 
            /// </summary>
            const int Passable = 30;

            public LevelCollisionMap()
            {
                CollisionColumns = new List<string>();

            }

            public LevelCollisionMap(int[,] HandedCollisionMap)//for use with Mapmaking Only.
            {
                CMap = HandedCollisionMap;
            }


            public void LoadContent(Vector2 MapSize)// for XmlManager
            {
                CMap = new int[(int)MapSize.X, (int)MapSize.Y];
                if (CollisionColumns.Count == 0)
                {
                    for (int X = 0; X < MapSize.X; X++)
                    {
                        for (int Y = 0; Y < MapSize.Y; Y++)
                        {
                            CMap[X, Y] = Passable;
                        }
                    }

                }
                else
                {
                   
                    for (int X = 0; X < MapSize.X; X++)
                    {
                        string column = CollisionColumns[X];
                        string[] split = column.Split(']');

                        for (int Y = 0; Y < MapSize.Y; Y++)
                        {
                            string str = split[Y];
                            CMap[X, Y] = int.Parse(str.Replace("[", string.Empty));
                        }
                    }
                }
            }

            
                
        }

        public class BeingCollisions
        {
            /// <summary>
            /// Overview
            ///  3 = NPC
            ///  4 = Enemy
            ///  5 = Boss
            ///  6 = Player
            /// 
            /// </summary>
            [XmlIgnore]
            public Dictionary<Vector2, CollFactFile> BC;
            private Dictionary<CollFactFile, List<Vector2>> Claims;

            public BeingCollisions()
            {
                BC = new Dictionary<Vector2, CollFactFile>();
                Claims = new Dictionary<CollFactFile, List<Vector2>>();
            }

            public bool MoveAlong(Vector2 OldLoc, Vector2 NewLoc)//returns whether it was successful or not
            {
                CollFactFile Transfer = BC[OldLoc];
                BC.Remove(OldLoc);
                if (!BC.ContainsKey(NewLoc))
                {
                    Transfer.IsPresent = true;
                    BC.Add(NewLoc, Transfer);
                    return true;
                }
                
                else if (BC[NewLoc].IsPresent == false)
                {//was claimed by someone
                    Claims.Remove(BC[NewLoc]);//remove the claim from the person's list of claims
                    BC.Remove(NewLoc);//remove the claim from the collision check system
                    Transfer.IsPresent = true;
                    BC.Add(NewLoc, Transfer);//add the new occupant of this tile
                    return true;
                }
                else
                {
                    return false;
                    //throw new Exception("Trying to move into a tile already occupied");
                }
            }

            public List<Vector2> OccupiedLocations(Rectangle InThisArea)
             {
                List<Vector2> OccLocs = new List<Vector2>();

                foreach(KeyValuePair<Vector2,CollFactFile> PosOccLoc in BC)
                {
                    if (PosOccLoc.Value.IsPresent && RectMethod.LocationIsInRectangle(PosOccLoc.Key, InThisArea))
                    {
                        OccLocs.Add(PosOccLoc.Key);
                    }
                }
                return OccLocs;
            }

            public List<Vector2> OccupiedLocations(Rectangle InThisArea, int IgnoreThisIndex)
            {
                List<Vector2> OccLocs = new List<Vector2>();

                foreach (KeyValuePair<Vector2, CollFactFile> PosOccLoc in BC)
                {
                    if (PosOccLoc.Value.IsPresent && RectMethod.LocationIsInRectangle(PosOccLoc.Key, InThisArea) && PosOccLoc.Value.EnemyIndex!=IgnoreThisIndex)
                    {
                        OccLocs.Add(PosOccLoc.Key);
                    }
                }
                return OccLocs;
            }

            public void Claim(int Index, int CollType, Vector2 NewClaim)
            {
                CollFactFile Claimant = new CollFactFile(CollType, false, Index);
                if (!BC.ContainsKey(NewClaim))
                {
                    BC.Add(NewClaim, Claimant);
                }
                
                if (Claims.ContainsKey(Claimant))
                {
                    if (Claims[Claimant].Count > 0)
                    {
                        for (int I = 0; I < Claims[Claimant].Count; I++)
                        {
                            Vector2 ToRemove = Claims[Claimant][I];
                            if (!BC[ToRemove].IsPresent)
                            {
                                BC.Remove(ToRemove);
                                Claims[Claimant].RemoveAt(I);
                                I--;
                            }
                        }
                    }
                    Claims[Claimant].Add(NewClaim);
                }
                else
                {
                    Claims.Add(Claimant, new List<Vector2>() { NewClaim });
                }

            }

            public void Claim(int CollType, Vector2 NewClaim)
            {
                CollFactFile Claimant = new CollFactFile(CollType, false);
                if (!BC.ContainsKey(NewClaim))
                {
                    BC.Add(NewClaim, Claimant);
                }
                
                if (Claims.ContainsKey(Claimant))
                {
                    if (Claims[Claimant].Count > 0)
                    {
                        for (int I = 0; I < Claims[Claimant].Count; I++)
                        {
                            Vector2 ToRemove = Claims[Claimant][I];
                            if (!BC[ToRemove].IsPresent)
                            {
                                BC.Remove(ToRemove);
                                Claims[Claimant].RemoveAt(I);
                                I--;
                            }
                        }
                    }
                    Claims[Claimant].Add(NewClaim);
                }
                else
                {
                    Claims.Add(Claimant, new List<Vector2>() { NewClaim });
                }

            }

            public void RemoveMyClaims(int MyIndex, int MyCollisionValue)
            {

                List<CollFactFile> ClaimsToRemove = new List<CollFactFile>();

                foreach (KeyValuePair<CollFactFile, List<Vector2>> I in Claims)
                {
                    if (I.Key.EnemyIndex == MyIndex && I.Key.CollisionType == MyCollisionValue)
                    {
                        ClaimsToRemove.Add(I.Key);
                    }
                }

                for (int I = 0; I < ClaimsToRemove.Count; I++)
                {
                    Claims.Remove(ClaimsToRemove[I]);
                }
            }
        }

        [XmlIgnore]
        public bool[,] Opaques;//The one for objects only is in ObjectLayer - this is for Objects and Walls/Voids.


        [XmlElement("Layer")]
        public List<Layer> Layers;
        public ObjectLayer Objects;
        public Vector2 TileDimensions;
        public Vector2 Size;
        public string Name;

        public Vector2 EntryLoc;

        [XmlIgnore]
        public List<Node> MapNetwork;
        public LevelCollisionMap Collision;
        public BeingCollisions BC;

        [XmlElement("Enemy")]
        public Dictionary<int,Enemy> CurrentEnemies;

        [XmlIgnore]
        public int LivingEnemies
        {
            get
            {
                int Total = 0;
                foreach(KeyValuePair<int,Enemy> E in CurrentEnemies)
                {
                    if (E.Value.IsAlive)
                    {
                        Total++;
                    }
                }
                return Total;
            }
        }
        [XmlIgnore]
        public int CurrentAvgSuspicion
        {
            get
            {
                if (CurrentEnemies.Count > 0)
                {
                    int Susp = 0;

                    foreach(KeyValuePair<int,Enemy> E in CurrentEnemies)
                    {
                        if (E.Value.IsAlive)
                        {
                            Susp += E.Value.TotalofAlertPoints;
                        }
                    }
                    return Susp / LivingEnemies;
                }
                else
                {
                    return 0;
                }
            }
        }

        [XmlIgnore]
        public int NextEnemyIndex
        { get; private set; }

        [XmlElement("EnemyTypePath")]
        public List<string> EnemyTypePaths;

        [XmlElement("Room")]
        public List<Room> Rooms;

        [XmlElement("Passage")]
        public List<Passageway> Passages;

        [XmlIgnore]
        public Random D;


        public Rectangle FullMap;//the size of the Map, from 0 to the MapSize - 1. DON'T use this to get the width of the map,
        // as it will always be 1 short.


        public Map()//for when creating a map that is to be filled with the data from the XmlLoader
        {
            Layers = new List<Layer>();
            TileDimensions = Vector2.Zero;
            Collision = new LevelCollisionMap();
            BC = new BeingCollisions();
            EnemyTypePaths = new List<string>();
            CurrentEnemies = new Dictionary<int, Enemy>() ;
            D = new Random();
            NextEnemyIndex = 0;
            
        }

        public Map(List<Layer> _Layers, ObjectLayer Objects,
            int[,] _CollisionMap, Vector2 _Size,
            Vector2 _TileDimensions, List<Room> Rooms, List<Passageway> Passages, List<string> EnemyTypes
           )
            // for creating a brand new Map with external data, without the XmlManager
        {
            Layers = _Layers;
            Collision = new LevelCollisionMap(_CollisionMap);
            BC = new BeingCollisions();
            Size = _Size;
            TileDimensions = _TileDimensions;
            this.Objects = Objects;
            this.Rooms = Rooms;
            this.Passages = Passages;
            this.FullMap = new Rectangle(0, 0, (int)Size.X, (int)Size.Y);
            this.EnemyTypePaths = EnemyTypes;
            CurrentEnemies = new Dictionary<int, Enemy>();
           NextEnemyIndex = 0;
            D = new Random();

        }

        public void LoadContent()//for use with XmlManager
        {
            
            foreach (Layer l in Layers)
            {
                l.LoadContent(TileDimensions);
                if (l.Size.X > Size.X)
                {
                    Size.X = l.Size.X;
                }
                if (l.Size.Y > Size.Y)
                {
                    Size.Y = l.Size.Y;
                }
            }
            foreach(KeyValuePair<int,Enemy> Enemy in CurrentEnemies)
            {
                Enemy.Value.LoadContent(TileDimensions);
                
            }
            
            Collision.LoadContent(Size);

            FullMap = new Rectangle(0, 0, (int)Size.X - 1, (int)Size.Y - 1);

            CreateOpacityLayer();

            GenerateMapNetwork();

        }

        public void LoadContent(bool IsBeingMade)//for use with being generated
        {
            if (IsBeingMade)
            {
                foreach (Layer l in Layers)
                {
                    l.LoadContent(true);
                    if (l.Size.X > Size.X)
                    {
                        Size.X = l.Size.X;
                    }
                    if (l.Size.Y > Size.Y)
                    {
                        Size.Y = l.Size.Y;
                    }
                }
                FullMap = new Rectangle(0, 0, (int)Size.X - 1, (int)Size.Y - 1);
                CreateOpacityLayer();
                GenerateMapNetwork();
            }
            else
            {
                throw new Exception("given a false, somehow");
            }
        }

        public void UnloadContent()
        {
            foreach (Layer l in Layers)
            {
                l.UnloadContent();
            }
            foreach (KeyValuePair<int, Enemy> Enemy in CurrentEnemies)
            {
                Enemy.Value.UnloadContent();

            }
            Objects.UnloadContent();
        }

        public void Update(GameTime gameTime)
        {
            foreach (Layer l in Layers)
            {
                l.Update(gameTime);
            }
            List<int> dead = new List<int>();
            foreach(KeyValuePair<int,Enemy> E  in CurrentEnemies)
            {
                E.Value.Update(gameTime, out bool Died);
                if (Died)
                {
                    
                    dead.Add(E.Key);
                   
                }
            }
            foreach(int Ind in dead)
            {
                CurrentEnemies.Remove(Ind);
                //Create a body, or stack the body on another
                //Add the body to the MAP - maintained list of such bodies, NOT under XmlIgnore, at the top.
            }

        }

        public void Draw(SpriteBatch spriteBatch, Camera camera)
        {
            foreach (Layer l in Layers)
            {
                l.Draw(spriteBatch, camera);
            }
            Objects.Draw(spriteBatch,camera);
            foreach (KeyValuePair<int, Enemy> Enemy in CurrentEnemies)
            {
                Enemy.Value.Draw(spriteBatch, camera);

            }
        }

        public void Draw(SpriteBatch spriteBatch, Camera camera, bool CollisionOverlay)
        {
            foreach (Layer l in Layers)
            {
                l.Draw(spriteBatch, camera);
            }
            Image Overlay = new Image
            {
                Path = "Dungeon Imaging/Collision Overlays"
            };
            Overlay.LoadContent();
            Overlay.Alpha = 0.4f;

            for (int X = 0; X < Size.X; X++)
            {
                for (int Y = 0; Y < Size.Y; Y++)
                {
                    int Coll = Collision.CMap[X, Y];
                    int CollisionY = (Coll / 10) * 32;
                    int CollisionX = (Coll % 10) * 32;
                    spriteBatch.Draw(Overlay.Texture, new Rectangle(X * 8, Y * 8, 8, 8), new Rectangle(CollisionX, CollisionY, 32, 32), Color.White * Overlay.Alpha);
                }
            }


            Objects.Draw(spriteBatch, camera);
            for(int I=0; I < CurrentEnemies.Count; I++) 
            {
                Enemy E = CurrentEnemies[I];
                E.Draw(spriteBatch, camera);
            }
        }

        public void Draw(SpriteBatch spriteBatch, Rectangle DrawArea, Vector2 DrawPoint, Vector2 Offset)
        {
            Vector2 Origin = new Vector2(DrawArea.X - DrawPoint.X, DrawArea.Y - DrawPoint.Y);//the top-left tile

            foreach (Layer l in Layers)
            {
                l.Draw(spriteBatch, DrawArea, DrawPoint, Offset);
            }
            Objects.Draw(spriteBatch, DrawArea, DrawPoint, Offset);

            foreach(KeyValuePair<int,Enemy> E in CurrentEnemies)
            {
                E.Value.Draw(spriteBatch, Offset, Origin);
            }
        }

        public void SpawnEnemies(int NumOfNewEnemies, int RoomOfPlayer)
        {
            
            for(int I = 0; I < NumOfNewEnemies; I++)
            {
                string NewFoeType = EnemyTypePaths[D.Next(0, EnemyTypePaths.Count - 1)];
                Enemy NewFoe = Enemy.LoadEnemyFromTemplate(NewFoeType);
                Map obj =this;
                AIMoveManager.Instance.TopUpRoomsForRoutes();
                Vector2 SpawnLoc = DungeonMethod.SpawnInValidLocation(ref obj,NextEnemyIndex, RoomOfPlayer);
                NewFoe.LoadContent(TileDimensions, SpawnLoc, this);
                NewFoe.AssignIndex(NextEnemyIndex);
                CurrentEnemies.Add(NextEnemyIndex,NewFoe);
                NextEnemyIndex++;
            }
        }

        private void CreateOpacityLayer()
        {
            Opaques = new bool[(int)Size.X, (int)Size.Y];

            for (int X = 0;X< Size.X; X++)
            {
                for (int Y = 0; Y < Size.Y; Y++)
                {
                    if (Objects.Opaques[X, Y])
                    {
                        Opaques[X, Y] = true;
                    }
                    else if(Collision.CMap[X,Y] <= 1)// ie Is 1 or 0 - a wall or void
                    {
                        Opaques[X, Y] = true;
                    }
                }
            }
        }

        private void GenerateMapNetwork()//generates a Network of this map with nodes as rooms and Passages as Arcs
        {
            MapNetwork = new List<Node>();
            for (int R = 0; R < Rooms.Count; R++)
            {
                Dictionary<int, int> Arcs = new Dictionary<int, int>();
                foreach (Room.EntryPoint Connection in Rooms[R].EntryPoints)
                {
                    int RoomSizeVar = (Rooms[R].Location[0].Width + Rooms[R].Location[0].Height) / 2;
                    Arcs.Add(Connection.RoomTo, Passages[Connection.PassagewayUsing].Length + RoomSizeVar);
                }
                MapNetwork.Add(new Node { NodeID = R, ConnecetionsToOtherNodes = Arcs });
            }
        }
    }

    
}
