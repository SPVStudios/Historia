﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Xml.Serialization;
using System.Xml;
using Microsoft.Xna.Framework.Input;



namespace Historia
{
    public class InfoPanel
    {
        
        Rectangle ScreenLoc;
        public Image BorderCorners;
        public Image BorderEdges;
        public Image Background;
        [XmlIgnore]
        WorldMap mapRef;

        [XmlIgnore]
        public Image Texture;
        public Image VillageScene;
        public Image DungeonScene;

        

        public string CurrentPlaceName;
        public bool IsActive;
        public bool IsVillage;//false means dungeon
        string ViDeityName;

        Rectangle InnerArea;
        SpriteFont font;
        const string FontName = "Gameplay/Fonts/Font1";//Change this to something actually stored (Maybe)
        Rectangle Size;

        string[] Lines;
        int CurrentLine;

        public InfoPanel()
        {
            BorderCorners = new Image();
            BorderEdges = new Image();
            Background = new Image();
            VillageScene = new Image();
            DungeonScene = new Image();
            Size = new Rectangle(0, 0, 160, 256);
            ScreenLoc = new Rectangle(8, 200, 160, 256);
            
        }

        public void LoadContent(WorldMap mapRef)

        {
            ContentManager content = new ContentManager(ScreenManager.Instance.Content.ServiceProvider, "Content");
            this.mapRef = mapRef;
            font = content.Load<SpriteFont>(FontName);
            XmlManager<Image> ImgLoader = new XmlManager<Image>();
            BorderCorners.LoadContent();
            BorderEdges.LoadContent();
            Background.LoadContent();
            VillageScene.LoadContent();
            DungeonScene.LoadContent();

            Rectangle TL = new Rectangle(0, 0, BorderEdges.Texture.Width / 2, BorderEdges.Texture.Height / 2);
            Rectangle TR = new Rectangle(BorderEdges.Texture.Width / 2,0, BorderEdges.Texture.Width / 2, BorderEdges.Texture.Height / 2);
            Rectangle BL = new Rectangle(0,BorderEdges.Texture.Height / 2, BorderEdges.Texture.Width / 2, BorderEdges.Texture.Height / 2);
            Rectangle BR = new Rectangle(BorderEdges.Texture.Height / 2, BorderEdges.Texture.Height / 2, BorderEdges.Texture.Width / 2, BorderEdges.Texture.Height / 2);
            int BitWidth = BorderEdges.Texture.Width / 2;
            int BitHeight = BorderEdges.Texture.Height / 2;


            int NumPiecesAcross = Size.Width / BitWidth;
            int NumPiecesDown = Size.Height / BitHeight;

            if (Size.Width % BitWidth != 0)
            {
                Size.Width -= (Size.Width % BitWidth);
            }
            if (Size.Height % BitHeight != 0)
            {
                Size.Height -= (Size.Height % BitHeight);
            }

            //The bit about changing render targets, then..
            RenderTarget2D renderTarget = new RenderTarget2D(ScreenManager.Instance.GraphicsDevice, (int)Size.Width, (int)Size.Height);
            ScreenManager.Instance.GraphicsDevice.SetRenderTarget(renderTarget);
            ScreenManager.Instance.GraphicsDevice.Clear(Color.Transparent);
            ScreenManager.Instance.SpriteBatch.Name = "Imaging";
            ScreenManager.Instance.SpriteBatch.Begin();
            //The bit making a spritebatch

            ScreenManager.Instance.SpriteBatch.Draw(Background.Texture, Size, Color.White);
            InnerArea = new Rectangle(ScreenLoc.X + BitWidth, ScreenLoc.Y + BitHeight, ScreenLoc.Width - (2 * BitWidth), ScreenLoc.Height - (2 * BitHeight));


            ScreenManager.Instance.SpriteBatch.Draw(BorderCorners.Texture, new Rectangle(0, 0, BitWidth, BitHeight), TL, Color.White);
            ScreenManager.Instance.SpriteBatch.Draw(BorderCorners.Texture, new Rectangle((NumPiecesAcross - 1) * BitWidth, 0, BitWidth, BitHeight), TR, Color.White);
            ScreenManager.Instance.SpriteBatch.Draw(BorderCorners.Texture, new Rectangle(0, (NumPiecesDown - 1) * BitHeight, BitWidth, BitHeight), BL, Color.White);
            ScreenManager.Instance.SpriteBatch.Draw(BorderCorners.Texture, new Rectangle((NumPiecesAcross - 1) * BitWidth, (NumPiecesDown - 1) * BitHeight, BitWidth, BitHeight), BR, Color.White);

            for (int NA = 1; NA < NumPiecesAcross - 1; NA++)
            {
                ScreenManager.Instance.SpriteBatch.Draw(BorderEdges.Texture,  new Rectangle(NA * BitWidth, 0, BitWidth, BitHeight), TL,Color.White);
                ScreenManager.Instance.SpriteBatch.Draw(BorderEdges.Texture, new Rectangle(NA * BitWidth, (NumPiecesDown - 1) * BitHeight, BitWidth, BitHeight), BL,Color.White);

            }

            for (int ND = 1; ND < NumPiecesDown - 1; ND++)
            {
                ScreenManager.Instance.SpriteBatch.Draw(BorderEdges.Texture, new Rectangle(0, ND * BitHeight, BitWidth, BitHeight), BR,Color.White);
                ScreenManager.Instance.SpriteBatch.Draw(BorderEdges.Texture,  new Rectangle((NumPiecesAcross - 1) * BitWidth, ND * BitHeight, BitWidth, BitHeight), TR,Color.White);
            }

            //save this drawn image back to something
            ScreenManager.Instance.SpriteBatch.End();
            ScreenManager.Instance.SpriteBatch.Name = string.Empty;
            //everything has now been drawn to the render target
            Texture = new Image
            {
                Texture = renderTarget
            };
            //this sets the texture to the drawn image of both the text AND the image so will be dealt with in one go in th future.

            ScreenManager.Instance.GraphicsDevice.SetRenderTarget(null);
        }

        public void Update(GameTime gameTime,Vector2 PlayerLoc)
        {
            //check for villages or dungeons in this tile
            if (mapRef.Villages.ContainsKey(PlayerLoc))
            {//if so, populate this panel with its info
                if (CurrentPlaceName != mapRef.Villages[PlayerLoc].Name)
                { 
                    CurrentPlaceName = mapRef.Villages[PlayerLoc].Name;
                    IsActive = true;
                    IsVillage = true;
                    ViDeityName = mapRef.Villages[PlayerLoc].Deity.Name;
                    string[] NameWords = CurrentPlaceName.Split(' ');
                    Lines = new string[NameWords.Length];
                    int Length = NameWords[0].Length;
                    CurrentLine = 0;
                    Lines[0] = NameWords[0];
                    for (int I = 1; I < NameWords.Length; I++)
                    {
                        if (Length + NameWords[I].Length <= 11)
                        {
                            Lines[CurrentLine] += " "+ NameWords[I];
                            Length += NameWords[I].Length;
                        }
                        else
                        {
                            CurrentLine++;
                            Lines[CurrentLine] = NameWords[I];
                            Length = NameWords[I].Length;
                        }
                    }
                }



            }
            else if (mapRef.Dungeons.ContainsKey(PlayerLoc))
            {//if so, populate this panel with its info
                if(CurrentPlaceName != mapRef.Dungeons[PlayerLoc].Name)
                {
                    CurrentPlaceName = mapRef.Dungeons[PlayerLoc].Name;
                    IsActive = true;
                    IsVillage = false;
                    string[] NameWords = CurrentPlaceName.Split(' ');
                    Lines = new string[NameWords.Length];
                    int Length = NameWords[0].Length;
                    CurrentLine = 0;
                    Lines[0] = NameWords[0];
                    for (int I = 1; I < NameWords.Length; I++)
                    {
                        if (Length + NameWords[I].Length <= 11)
                        {
                            Lines[CurrentLine] += " "+NameWords[I];
                            Length += NameWords[I].Length;
                        }
                        else
                        {
                            CurrentLine++;
                            Lines[CurrentLine] = NameWords[I];
                            Length = NameWords[I].Length;
                        }
                    }
                }
                
            }

            //else empty the panel
            else
            {
                CurrentPlaceName = "";
                IsActive = false;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(Texture.Texture, ScreenLoc, Color.White);
            if (IsActive)
            {
                
                for(int I = 0; I <= CurrentLine; I++)
                {
                    spriteBatch.DrawString(font, Lines[I], new Vector2(InnerArea.X, InnerArea.Y + (14*I)), Color.White);
                }
                
                if (IsVillage)
                {
                    VillageScene.Draw(spriteBatch);
                }
                else
                {
                    DungeonScene.Draw(spriteBatch);
                }

            }
        }
    }
}
