﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Xml.Serialization;
using System.Xml;

namespace Historia
{
    public static class NetworkMethod
    {
        public static List<int> Dijkstrafy_Routes(Map mapRef, List<int> PossUnconnectedRooms)
        {
            List<int> ConnectedRooms = new List<int>();
            for (int I = 1; I < PossUnconnectedRooms.Count; I++)
            {
                ConnectedRooms.AddRange(Dijkstras(mapRef, PossUnconnectedRooms[I - 1], PossUnconnectedRooms[I % PossUnconnectedRooms.Count]));
            }
            return ConnectedRooms;
        }

        public static List<int> Dijkstras(Map mapRef, int A, int B)
        {
            List<Node> Network = mapRef.MapNetwork;
            int NumOfNodes = Network.Count;

            List<bool> ConnectedToA = new List<bool>();
            List<int> DistanceFromA = new List<int>();
            List<List<int>> RouteFromA = new List<List<int>>();

            for (int I = 0; I < NumOfNodes; I++)
            {
                ConnectedToA.Add(false);
                DistanceFromA.Add(int.MaxValue);
                RouteFromA.Add(new List<int>());
            }
            ConnectedToA[A] = true;
            DistanceFromA[A] = 0;
            RouteFromA[A].Add(A);
            foreach (KeyValuePair<int, int> C in Network[A].ConnecetionsToOtherNodes)
            {
                DistanceFromA[C.Key] = C.Value;
                RouteFromA[C.Key].Add(A);
                RouteFromA[C.Key].Add(C.Key);
            }

            while (!ConnectedToA[B])
            {
                //find the closest unconnected node to A
                int ClosestID = -1;
                int ClosestDistance = int.MaxValue;
                for (int I = 0; I < NumOfNodes; I++)
                {
                    if (!ConnectedToA[I])
                    {
                        if (DistanceFromA[I] < ClosestDistance)
                        {
                            ClosestDistance = DistanceFromA[I];
                            ClosestID = I;
                        }
                    }
                }
                //connect it
                ConnectedToA[ClosestID] = true;
                //alter values of all unconnected nodes it is connected to
                foreach (KeyValuePair<int, int> C in Network[ClosestID].ConnecetionsToOtherNodes)
                {
                    if (DistanceFromA[ClosestID] + C.Value < DistanceFromA[C.Key])
                    {
                        DistanceFromA[C.Key] = DistanceFromA[ClosestID] + C.Value;
                        RouteFromA[C.Key] = new List<int>();
                        RouteFromA[C.Key].AddRange(RouteFromA[ClosestID]);
                        RouteFromA[C.Key].Add(C.Key);
                    }
                }
            }
            return RouteFromA[B];

        }

        public static List<int> Dijkstras(Map mapRef, int A, int B, out int ShortestDistance)
        {
            List<Node> Network = mapRef.MapNetwork;
            int NumOfNodes = Network.Count;

            List<bool> ConnectedToA = new List<bool>();
            List<int> DistanceFromA = new List<int>();
            List<List<int>> RouteFromA = new List<List<int>>();

            for (int I = 0; I < NumOfNodes; I++)
            {
                ConnectedToA.Add(false);
                DistanceFromA.Add(int.MaxValue);
                RouteFromA.Add(new List<int>());
            }
            ConnectedToA[A] = true;
            DistanceFromA[A] = 0;
            RouteFromA[A].Add(A);
            foreach (KeyValuePair<int, int> C in Network[A].ConnecetionsToOtherNodes)
            {
                DistanceFromA[C.Key] = C.Value;
                RouteFromA[C.Key].Add(A);
                RouteFromA[C.Key].Add(C.Key);
            }

            while (!ConnectedToA[B])
            {
                //find the closest unconnected node to A
                int ClosestID = -1;
                int ClosestDistance = int.MaxValue;
                for (int I = 0; I < NumOfNodes; I++)
                {
                    if (!ConnectedToA[I])
                    {
                        if (DistanceFromA[I] < ClosestDistance)
                        {
                            ClosestDistance = DistanceFromA[I];
                            ClosestID = I;
                        }
                    }
                }
                //connect it
                ConnectedToA[ClosestID] = true;
                //alter values of all unconnected nodes it is connected to
                foreach (KeyValuePair<int, int> C in Network[ClosestID].ConnecetionsToOtherNodes)
                {
                    if (DistanceFromA[ClosestID] + C.Value < DistanceFromA[C.Key])
                    {
                        DistanceFromA[C.Key] = DistanceFromA[ClosestID] + C.Value;
                        RouteFromA[C.Key] = new List<int>();
                        RouteFromA[C.Key].AddRange(RouteFromA[ClosestID]);
                        RouteFromA[C.Key].Add(C.Key);
                    }
                }
            }
            ShortestDistance = DistanceFromA[B];
            return RouteFromA[B];

        }

        public static List<int> Dijkstras(Map mapRef, int A, List<int> Set_B, out int ChosenFromB)//ChosenFromB refers to the INDEX of the item in the list.
        {
            List<Node> Network = mapRef.MapNetwork;
            int NumOfNodes = Network.Count;

            List<bool> ConnectedToA = new List<bool>();
            List<int> DistanceFromA = new List<int>();
            List<List<int>> RouteFromA = new List<List<int>>();

            for (int I = 0; I < NumOfNodes; I++)
            {
                ConnectedToA.Add(false);
                DistanceFromA.Add(int.MaxValue);
                RouteFromA.Add(new List<int>());
            }
            ConnectedToA[A] = true;
            DistanceFromA[A] = 0;
            RouteFromA[A].Add(A);
            foreach (KeyValuePair<int, int> C in Network[A].ConnecetionsToOtherNodes)
            {
                DistanceFromA[C.Key] = C.Value;
                RouteFromA[C.Key].Add(A);
                RouteFromA[C.Key].Add(C.Key);
            }
            int ClosestLoc;
            while (!CheckListBool(ConnectedToA,Set_B, out ClosestLoc))
            {
                //find the closest unconnected node to A
                int ClosestID = -1;
                int ClosestDistance = int.MaxValue;
                for (int I = 0; I < NumOfNodes; I++)
                {
                    if (!ConnectedToA[I])
                    {
                        if (DistanceFromA[I] < ClosestDistance)
                        {
                            ClosestDistance = DistanceFromA[I];
                            ClosestID = I;
                        }
                    }
                }
                //connect it
                ConnectedToA[ClosestID] = true;
                //alter values of all unconnected nodes it is connected to
                foreach (KeyValuePair<int, int> C in Network[ClosestID].ConnecetionsToOtherNodes)
                {
                    if (DistanceFromA[ClosestID] + C.Value < DistanceFromA[C.Key])
                    {
                        DistanceFromA[C.Key] = DistanceFromA[ClosestID] + C.Value;
                        RouteFromA[C.Key] = new List<int>();
                        RouteFromA[C.Key].AddRange(RouteFromA[ClosestID]);
                        RouteFromA[C.Key].Add(C.Key);
                    }
                }
            }
            ChosenFromB = ReturnIndexOfClosest(Set_B, ClosestLoc);
            return RouteFromA[ClosestLoc];
        }

        public static List<int> Dijkstras(Map mapRef, int A, List<int> Set_B, out int ChosenFromB, out int DistanceToChosen)//ChosenFromB refers to the INDEX of the item in the list.
        {
            List<Node> Network = mapRef.MapNetwork;
            int NumOfNodes = Network.Count;

            List<bool> ConnectedToA = new List<bool>();
            List<int> DistanceFromA = new List<int>();
            List<List<int>> RouteFromA = new List<List<int>>();

            for (int I = 0; I < NumOfNodes; I++)
            {
                ConnectedToA.Add(false);
                DistanceFromA.Add(int.MaxValue);
                RouteFromA.Add(new List<int>());
            }
            ConnectedToA[A] = true;
            DistanceFromA[A] = 0;
            RouteFromA[A].Add(A);
            foreach (KeyValuePair<int, int> C in Network[A].ConnecetionsToOtherNodes)
            {
                DistanceFromA[C.Key] = C.Value;
                RouteFromA[C.Key].Add(A);
                RouteFromA[C.Key].Add(C.Key);
            }
            int ClosestLoc;
            while (!CheckListBool(ConnectedToA, Set_B, out ClosestLoc))
            {
                //find the closest unconnected node to A
                int ClosestID = -1;
                int ClosestDistance = int.MaxValue;
                for (int I = 0; I < NumOfNodes; I++)
                {
                    if (!ConnectedToA[I])
                    {
                        if (DistanceFromA[I] < ClosestDistance)
                        {
                            ClosestDistance = DistanceFromA[I];
                            ClosestID = I;
                        }
                    }
                }
                //connect it
                ConnectedToA[ClosestID] = true;
                //alter values of all unconnected nodes it is connected to
                foreach (KeyValuePair<int, int> C in Network[ClosestID].ConnecetionsToOtherNodes)
                {
                    if (DistanceFromA[ClosestID] + C.Value < DistanceFromA[C.Key])
                    {
                        DistanceFromA[C.Key] = DistanceFromA[ClosestID] + C.Value;
                        RouteFromA[C.Key] = new List<int>();
                        RouteFromA[C.Key].AddRange(RouteFromA[ClosestID]);
                        RouteFromA[C.Key].Add(C.Key);
                    }
                }
            }
            ChosenFromB = ReturnIndexOfClosest(Set_B, ClosestLoc);
            DistanceToChosen = DistanceFromA[ClosestLoc];
            return RouteFromA[ClosestLoc];
        }

        private static int ReturnIndexOfClosest(List<int> Set, int Value)
        {
            for(int I = 0; I < Set.Count; I++)
            {
                if(Set[I] == Value)
                {
                    return I;
                }
            }
            throw new Exception("Not in the set");
        }


        private static bool CheckListBool(List<bool> In, List<int>TargetsInList, out int FirstIndex)
        {
            for (int I = 0; I < In.Count; I++)
            {
                if (In[I] && TargetsInList.Contains(I))
                {
                    FirstIndex = I;
                    return true;
                }
            }
            FirstIndex = -1;
            return false;
        }

    }
    public struct Node
    {
        public int NodeID;
        public Dictionary<int, int> ConnecetionsToOtherNodes;//Key is Other Node's ID, Value is Length of Arc.
    }
}
