﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using System.Xml.Serialization;

namespace Historia
{
    public class Layer
    {
        public Vector2 Size;
        public Vector2 TileDimensions;
        

        public class TileMap
            ///<summary>
            ///This class is NESTED - it means you can only call or reference a TileMap from within it's Layer
            ///This makes it harder to mess around with the tilemap of a random layer by accident - you have to reference 
            ///WHICH layer it is a tilemap of.
            ///</summary>
        {
            [XmlElement ("Column")]
            public List<string> Column;

            public TileMap()
            {
                Column = new List<string>();
            }
        }

        [XmlElement ("TileMap")]
        protected TileMap Tile_Map;

        [XmlIgnore]
        public Tile[,] Tiles;

        [XmlElement ("TileSet")]
        public List<TileSet> TileSets;

        public Layer(List<TileSet> _TileSets, Tile[,] _Tiles, Vector2 _Size, Vector2 _TileDimensions)
            //for when creating a layer from scratch, without loading anything....
        {
            Tiles = _Tiles;
            TileDimensions = _TileDimensions;
            TileSets = _TileSets;
            Size = _Size;
            
        }
        
        
        public Layer()//for when creating a layer that will be filled with data loaded from the XmlLoader
        {
            
        }

        public virtual void LoadContent(Vector2 tileDimensions)//for use just after having loaded from an Xml file
        {
            foreach (TileSet tileset in TileSets)
            {
                tileset.LoadContent();
            }
            
            Tiles = new Tile[(int)Size.X, (int)Size.Y];
            TileDimensions = tileDimensions;


            for (int X = 0; X < Size.X; X++)
            {
                string column = Tile_Map.Column[X];
                string[] split = column.Split(']');

                for (int Y = 0; Y < split.Length; Y++)
                {
                    string s = split[Y];
                    if (s != string.Empty)
                    {
                        string str = s.Replace("[", string.Empty);
                        int textureColumn = int.Parse(str.Substring(str.IndexOf(':') + 1));

                        int textureRow = int.Parse(str.Substring(0, str.IndexOf(':')));
                        Tiles[X, Y] = new Tile();
                        Tiles[X, Y].LoadContent(
                            new Vector2((int)tileDimensions.X * textureColumn, (int)tileDimensions.Y * textureRow),
                            
                            0);//THE ZERO NEEDS TO REFER TO WHICH TILESET IN FUTURE
                        
                    }
                }
            }
        }

        public void LoadContent(bool IsNewMap)//always hand this "true", else it will throw an exception.
        {
            if (IsNewMap)
            {
                foreach (TileSet tileset in TileSets)
                {
                    tileset.LoadContent();
                }
            }
            else
            {
                throw new Exception("You've given it a false value for the new Map version of LoadContent.Give it true or nothing at all!");
            }
            
        }

        public void UnloadContent()
        {
            foreach(TileSet tileset in TileSets)
            {
                tileset.UnloadContent();
            }
                
        }

        public void Update(GameTime gameTime)
        {

        }

        public void Draw(SpriteBatch spriteBatch, Rectangle DrawArea, Vector2 DrawPoint, Vector2 Offset)
        {
            for (int X = (int)DrawPoint.X; X <= DrawArea.Width; X++)
            {
                for (int Y = (int)DrawPoint.Y; Y <= DrawArea.Height; Y++)
                {
                    Vector2 Position = new Vector2((DrawPoint.X + X) * TileDimensions.X, (DrawPoint.Y + Y) * TileDimensions.Y);
                    Position -= Offset;

                    Tile This = Tiles[X + DrawArea.X, Y + DrawArea.Y];

                    spriteBatch.Draw(
                       
                        TileSets[This.WhichTileSet].Image.Texture,
                        
                        new Rectangle(
                        (int)Position.X,(int)Position.Y,
                        (int)TileDimensions.X, (int)TileDimensions.Y), 
                        
                        new Rectangle((int)This.SourcePoint.X,(int)This.SourcePoint.Y,
                        (int)TileDimensions.X,(int)TileDimensions.Y),
                        
                        Color.White);

                }
            }

        }

        public void Draw(SpriteBatch spriteBatch, Camera camera)
        {
            for (int X = (int)camera.DrawPoint.X; X < camera.DrawArea.Width; X++)
            {
                for (int Y = (int)camera.DrawPoint.Y; Y < camera.DrawArea.Height; Y++)
                {
                    Vector2 Position = new Vector2((camera.DrawPoint.X + X) * TileDimensions.X, (camera.DrawPoint.Y + Y) * TileDimensions.Y);
                    Position -= camera.Offset;

                    Tile This = Tiles[X + camera.DrawArea.X, Y + camera.DrawArea.Y];

                    spriteBatch.Draw(

                        TileSets[This.WhichTileSet].Image.Texture,

                        new Rectangle(
                        (int)Position.X, (int)Position.Y,
                        (int)TileDimensions.X, (int)TileDimensions.Y),

                        new Rectangle((int)This.SourcePoint.X, (int)This.SourcePoint.Y,
                        (int)TileDimensions.X, (int)TileDimensions.Y),

                        Color.White);
                }
            }

        }
    }
}
