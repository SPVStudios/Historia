﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Xml.Serialization;


namespace Historia
{
    public class Village
    {
        public Vector2 Location;

        public string Name;

        public Deity Deity;

        public string InnName;

        public Village(Vector2 Location)
        {
            this.Location = Location;
        }

        public void Populate(string Name, Deity Deity, string InnName)
        {
            this.Name = Name;
            this.Deity = Deity;
            this.InnName = InnName;
        }
    }

    public struct Deity
    {
        public string Name;
        public string Description;
        public string Buff;
        public string Ward;//the thing they're associated with.
        public char Gender;
    }
}
