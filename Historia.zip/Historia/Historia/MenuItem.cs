﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Xml.Serialization;
using Microsoft.Xna.Framework.Input;


namespace Historia
{
    public class MenuItem
    {
        public string LinkType;//whether it is linked to a screen or another menu
        public string LinkID;//what it is linked to
        public Image Image;

        [XmlElement("StatChange")]
        public List<StatChange> StatChanges;

        public Condition Condition;

        [XmlElement("SuccessStatChange")]
        public List<StatChange> StatChangesIfConditionMet;
        public string LinkIDifConditionMet;

        [XmlElement("FailStatChange")]
        public List<StatChange> StatChangesIfConditionFail;
        public string LinkIDifConditionFail;

        public MenuItem()
        {
            StatChanges = new List<StatChange>();
            StatChangesIfConditionMet = new List<StatChange>();
            StatChangesIfConditionFail = new List<StatChange>();
        }

    }
    



    public class Condition
    {
        public string StatToMeasure;

        public int MustBeBelow;
        public int MustBeAbove;
        public int MustBE;///<remarks>NOTE: Cannot require exactly 0 as null values aren't a thing for integers, so requiring 0 wold be to set no limit.</remarks>
                          

        //Use only the integers above that require being enforced.
    }


}
