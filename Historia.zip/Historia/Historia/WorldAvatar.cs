﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

using Microsoft.Xna.Framework.Input;


namespace Historia
{
    

    public class WorldAvatar
    {
        public WorldAvatar()
        {
        }

      

        public Image Image;

        [XmlIgnore]
        protected WorldMap mapRef;

        [XmlIgnore]
        public Vector2 Direction
        {
            get
            {
                switch (FacingAddup)
                {
                    case 0:
                        return new Vector2(0, 1);
                    case 1:
                        return new Vector2(-1, 0);
                    case 2:
                        return new Vector2(1, 0);
                    case 3:
                        return new Vector2(0, -1);
                    default:
                        throw new Exception("given invalid FacingAddup");
                }
            }
        }

        public Vector2 TileDimensions;
        [XmlIgnore]

        

        public int CollisionType;

        protected int FacingAddup;
        protected int ActionFrameSet;

        public int CurrentAction { get { return ActionFrameSet; } }

        protected Vector2 offset;
        public Vector2 Offset { get { return offset; } }
        public Vector2 TilePosition;
        protected Vector2 TileAllign;


        protected int SPD;//Speed, as a % of base movement speed, where a standard action takes .5 seconds to complete.
        [XmlIgnore]
        public int MoveSpeed
        {
            get
            { return SPD; }
        }


        private bool HasBegunAction;
        private bool IsBusy;
        int ActionTimeOverflow;//the number of milliseconds of passed time that didn't get used for anything in the last update pass.


        int moveTime;// in Milliseconds. ensure that this is divisible by 2.
        protected int walkOffsetPixelTime;// in milliseconds
        protected int runOffsetPixelTime;//in ms. Half of the above.
        protected int sneakOffsetPixelTime;//in ms. 3 times the above(<--run time. 1.5x slower than normal walking; 2/3 speed)
        protected int dodgeOffsetPixelTime;
        int pixelsMoved;

        protected const int BaseMoveTime = 50000;//the amount of time, times 100 (the base speed stat). A MoveSpeed greater than
                                                 //100 will therefore cut the time it takes to move.
                                                 //A base speed of 100 means that moving tiles will take 500ms, or .5 seconds.

        int BlockStatus;
       



        public virtual void LoadContent(Vector2 TileDimensions, Vector2 SpawnLocation, WorldMap map)
        {
            this.mapRef = map;
            Image.LoadContent();
            Image.IsActive = true;
            TilePosition = SpawnLocation;
            SPD = 100;
            Image.Position = TilePosition * TileDimensions;
            this.TileDimensions = TileDimensions;
           
            AssignNewMoveTime(100);
            TileAllign = new Vector2((TileDimensions.X - Image.SpriteSheetEffect.FrameWidth) / 2, TileDimensions.Y - Image.SpriteSheetEffect.FrameHeight);
           


            var obj = this;
            
        }

        public virtual void LoadContent(Vector2 TileDimensions)//AS ABOVE - but no specified spawn, as either has one (Xml) or doesn't need one(blueprint)
        {
            Image.LoadContent();
            Image.IsActive = true;
            Image.Position = TilePosition * TileDimensions;
            this.TileDimensions = TileDimensions;
            
            AssignNewMoveTime(MoveSpeed);
            TileAllign = new Vector2((TileDimensions.X - Image.SpriteSheetEffect.FrameWidth) / 2, TileDimensions.Y - Image.SpriteSheetEffect.FrameHeight);
            
        }

        public virtual void UnloadContent()
        {
            Image.UnloadContent();
        }

        public virtual void Update(GameTime gameTime)
        {
            
                if (!IsBusy)
                {
                    HasBegunAction = DecideWhattoDo(gameTime, out ActionFrameSet);//see summary below

                }
                if (HasBegunAction)
                {
                    StartAction(gameTime);
                }
                if (IsBusy)//if the character is moving (either since previously, or having only just started)
                {
                    Act(gameTime);
                    if (!IsBusy)
                    {
                        ReturnToIdle();
                    }
                }
            AdjustOffsetsX(gameTime);
            AdjustOffsetsY(gameTime);
            
            Image.Update(gameTime);
        }

        public virtual void Act(GameTime gameTime)//decides what actions are to be taken. Override to add or change actions, but remember that some int codes are taken.
        {
            switch (ActionFrameSet)
            {
                case 0:
                    throw new Exception("This Should be Idle, therefore not doing anything");
                case 1:
                    Move(gameTime);
                    break;
                case 2:
                    Run(gameTime);
                    break;
                case 3:
                    Attack(gameTime);
                    break;
                case 4:
                    HeavyAttack(gameTime);
                    break;
                case 5:
                    Dodge(gameTime);
                    break;
                case 6:
                    Block(gameTime);
                    break;
                case 7:
                    Parry(gameTime);
                    break;
                case 8:
                    Sneak(gameTime);
                    break;
                case 9:
                    throw new NotImplementedException();
                case 10:
                    
                    break;
                case 11:
                    
                    break;
                case 12:
                    
                    break;
                case 13:
                   
                    break;
                case 14:
                   
                    break;
                case 15:
                    
                    break;
                default:
                    throw new Exception("This Move Shouldn't Exist!");
            }
        }
        /// <summary ActionFrameSet>
        /// The multiple of 4 referrring to the animation of whichever current action should be ocurring.
        /// Key:
        /// 0 = idle
        /// 1 = movement
        /// 2 = running
        /// 3 = regular attacking
        /// 4 = heavy attacking
        /// 5 = dodging
        /// 6 = blocking
        /// 7 = parrying
        /// 8 = sneaking
        /// 9 = Interact
        /// 
        /// 10-15 = Special Moves 0-5 (DO NOT MOVE THESE, THE ATTACKMANAGER RELIES ON THEM BEING HERE) (Defined separately)
        /// 
        /// Special Moves, However, provide their own spritesheets to draw from, so after the first 10 animations (0-9), the 11th is Death, 1 for each facing.
        /// 
        /// 
        /// 
        /// These numbers are used both by animations and to determine by update logic what action is currently being taken.
        /// 
        /// </summary>

        protected void AdjustOffsetsX(GameTime gameTime)//adjusts tile positions and offsets if offset is such that it is onto the next tile.
        {
            if ((TileDimensions.X / 2) <= offset.X)
            {
                
                    TilePosition.X++;
                    offset.X -= TileDimensions.X;
                
                

            }
            else if (offset.X < -(TileDimensions.X / 2))
            {
                
                   
                    offset.X += TileDimensions.X;
                    TilePosition.X--;
                
            }

        }

        protected void AdjustOffsetsY(GameTime gameTime)//as above, for Y.
        {
            if ((TileDimensions.Y / 2) <= offset.Y)
            {
                
                    // has vacated the old square and inhabit new square on BeingColl as was successful
                    TilePosition.Y++;
                    offset.Y -= TileDimensions.Y;
               
            }
            else if (offset.Y < -(TileDimensions.Y / 2))
            {
                
                    // has vacated the old square and inhabit new square on BeingColl as was successful
                    offset.Y += TileDimensions.Y;
                    TilePosition.Y--;
                
            }

        }

        //Start Action Methods

        protected virtual void StartAction(GameTime gameTime)
        {
            HasBegunAction = false;
            Image.SpriteSheetEffect.CurrentFrame.Y = (ActionFrameSet * 4) + FacingAddup;
            if (ActionFrameSet > 0)
            {

                switch (ActionFrameSet)
                {

                    case 1:
                        StartMove();
                        break;
                    case 2://or running
                        StartMove();
                        break;
                    case 3:
                        StartAttack(false);
                        break;
                    case 4:
                        StartAttack(true);
                        break;
                    case 5:
                        StartDodge();
                        break;
                    case 6:
                        StartBlock();
                        break;
                    case 7:
                        StartParry();
                        break;
                    case 8://for sneaking
                        StartMove();
                        break;
                    case 9:
                        Interact(gameTime);//is an instant thing atm, so deosn't reach process of interact at ACT stage, but at START stage.
                        break;
                    case 10:
                        
                        break;
                    case 11:
                        
                        break;
                    case 12:
                        
                        break;
                    case 13:
                        
                        break;
                    case 14:
                      
                        break;
                    case 15:
                       
                        break;
                }
            }
        }

        protected void StartAttack(bool IsHeavy)
        {
            IsBusy = true;
            if (IsHeavy)
            {
                Image.SpriteSheetEffect.StartLimitedLoop((ActionFrameSet * 4) + FacingAddup, 1, FacingAddup,
                    (Image.SpriteSheetEffect.SwitchFrame * 3) / 2);
            }
            else
            {
                Image.SpriteSheetEffect.StartLimitedLoop((ActionFrameSet * 4) + FacingAddup, 1, FacingAddup);
            }

            ActionTimeOverflow = 0;
            
        }

        protected void StartBlock()
        {
            IsBusy = true;
            Image.SpriteSheetEffect.StartLimitedLoop((ActionFrameSet * 4) + FacingAddup, 1, FacingAddup);
            ActionTimeOverflow = 0;
           
        }

        protected void StartParry()
        {
            IsBusy = true;
            Image.SpriteSheetEffect.StartLimitedLoop((ActionFrameSet * 4) + FacingAddup, 1, FacingAddup);
            ActionTimeOverflow = 0;
          
        }

        protected void StartDodge()
        {
            if (CheckWalkValid())
            {
                IsBusy = true;
                ActionTimeOverflow = 0;
               
                pixelsMoved = 0;
            }
        }

        protected virtual void StartMove()
        {
            if (CheckWalkValid())
            {
                IsBusy = true;
                
            }
        }

        //Action Set Methods
        /// <summary>
        /// Below are the methods that are run for each action a being can complete.
        /// 
        /// These are run when the update logic has called for them to do so, but this occurs mainly due to the AI and due to input for the player.
        /// </summary>
        /// <param name="gameTime"></param>

        protected virtual void Move(GameTime gameTime)
        {
            int runningtotal = ActionTimeOverflow + gameTime.ElapsedGameTime.Milliseconds;//pun intended
           
            if (runningtotal >= walkOffsetPixelTime)
            {
                int pixelsNow = runningtotal / walkOffsetPixelTime;
                ActionTimeOverflow = runningtotal % walkOffsetPixelTime;
                pixelsMoved += pixelsNow;

                if (pixelsMoved >= TileDimensions.X)
                {
                    if (pixelsMoved > TileDimensions.X)
                    {
                        int Reduction = pixelsMoved - (int)TileDimensions.X;
                        pixelsNow -= Reduction;
                    }
                    IsBusy = false;
                    pixelsMoved = 0;
                    ActionTimeOverflow = 0;
                    
                }
                offset += Direction * pixelsNow;
            }
            else
            {
                ActionTimeOverflow += runningtotal;
            }

        }

        protected virtual void Run(GameTime gameTime)//like walking, but with a diff animation, faster, and noisier
        {
            int runningtotal = ActionTimeOverflow + gameTime.ElapsedGameTime.Milliseconds;//pun intended
           
            if (runningtotal >= runOffsetPixelTime)
            {
                int pixelsNow = runningtotal / runOffsetPixelTime;
                ActionTimeOverflow = runningtotal % walkOffsetPixelTime;
                pixelsMoved += pixelsNow;
                if (pixelsMoved >= TileDimensions.X)
                {

                    if (pixelsMoved > TileDimensions.X)
                    {
                        int Reduction = pixelsMoved - (int)TileDimensions.X;
                        pixelsNow -= Reduction;
                    }
                    pixelsMoved = 0;
                    IsBusy = false;
                    ActionTimeOverflow = 0;
                    
                }
                offset += Direction * pixelsNow;
            }

        }

        protected virtual void Attack(GameTime gameTime)//see blocks and stuff for idea on Attack Manager singleton class to handle attacks in levels
        {
            ActionTimeOverflow += gameTime.ElapsedGameTime.Milliseconds;
            if (ActionTimeOverflow >= Image.SpriteSheetEffect.TimeforOneLoop)
            {
                //process attack with AttackManager
               
                IsBusy = false;
                ActionTimeOverflow = 0;
            }
        }

        protected virtual void HeavyAttack(GameTime gameTime)//as above, but takes 2x as long to set-up, and deals 2.5x the damage.
        {
            ActionTimeOverflow += gameTime.ElapsedGameTime.Milliseconds;
            if (ActionTimeOverflow >= Image.SpriteSheetEffect.TimeforOneLoop)
            {
                
                IsBusy = false;
                ActionTimeOverflow = 0;
            }
            //will return to 0+FacingAddup (idle) once completed animation.
        }

        protected virtual void Dodge(GameTime gameTime)//quickly change tile(perhaps up to 2 in one go) but be extra-vulnerable (and slow down) during the end-stage of the move to delay the next action. 
        {
            int runningtotal = ActionTimeOverflow + gameTime.ElapsedGameTime.Milliseconds;
            int pixelsNow = 0;

            if (pixelsMoved < (TileDimensions.X * 2) / 3)
            {
                if (runningtotal >= dodgeOffsetPixelTime)
                {
                    pixelsNow = runningtotal / dodgeOffsetPixelTime;
                    ActionTimeOverflow = runningtotal % dodgeOffsetPixelTime;
                    pixelsMoved += pixelsNow;
                }
                else
                {
                    ActionTimeOverflow += runningtotal;
                }
            }
            else//last third
            {
                if (runningtotal >= sneakOffsetPixelTime)
                {
                    pixelsNow = runningtotal / sneakOffsetPixelTime;
                    ActionTimeOverflow = runningtotal % sneakOffsetPixelTime;
                    pixelsMoved += pixelsNow;
                }
                else
                {
                    ActionTimeOverflow += runningtotal;
                }
            }

            if (pixelsMoved >= TileDimensions.X)//if finished
            {
                if (pixelsMoved > TileDimensions.X)
                {
                    int Reduction = pixelsMoved - (int)TileDimensions.X;
                    pixelsNow -= Reduction;
                }
                IsBusy = false;
                ActionTimeOverflow = 0;
                pixelsMoved = 0;
            }
            offset += Direction * pixelsNow;

        }

        protected virtual void Parry(GameTime gameTime)
        /// <summary>
        ///  stand still, and if well-timed for when an enemy strikes from the facing direction, they will stumble.
        ///  
        /// If "perfectly timed", enemies from the target direction are stumbled for more, and attacks from OTHER directions are also knocked bakc.
        /// 
        /// This should be achieved by the Parry move affecting an integer value for BlockStatus, with one number for 'Parrying' and one for 'PerfectParrying' over the course of the action
        /// (which will take a set amount of time like a block)
        /// 
        /// When an "AttackManager" instance calls for the attack to be carried out on this being, it will check BlockStatus to decide what will happen.
        /// </summary>
        {
            ActionTimeOverflow += gameTime.ElapsedGameTime.Milliseconds;
            if (ActionTimeOverflow >= Image.SpriteSheetEffect.TimeforOneLoop / 3)
            {
                if (BlockStatus < 9)
                {
                    BlockStatus++;
                    ActionTimeOverflow -= (Image.SpriteSheetEffect.TimeforOneLoop / 3);
                }
                else
                {
                    IsBusy = false;
                    ActionTimeOverflow = 0;
                }
            }

        }

        protected virtual void Block(GameTime gameTime)
        /// <summary>
        ///  stand still, and suffer very little damage from the attack approaching from the tile you are facing.
        ///  
        /// If "perfectly timed", enemies from the target direction are completely blocked damage-wise, and attacks from the left or right are also blocked as normal.
        /// 
        /// This should be achieved by the Block move affecting an integer value for BlockStatus, with one number for 'Blocking' and one for 'PerfectBlocking' over the course of the action
        /// (which will take a set amount of time like a parry)
        /// 
        /// When an "AttackManager" instance calls for the attack to be carried out on this being, it will check BlockStatus to decide what will happen.
        /// </summary>
        {
            ActionTimeOverflow += gameTime.ElapsedGameTime.Milliseconds;
            if (ActionTimeOverflow >= Image.SpriteSheetEffect.TimeforOneLoop / 3)
            {
                if (BlockStatus < 3)
                {
                    BlockStatus++;
                    ActionTimeOverflow -= (Image.SpriteSheetEffect.TimeforOneLoop / 3);
                }
                else
                {
                    IsBusy = false;
                    ActionTimeOverflow = 0;
                }
            }
        }

        protected virtual void Sneak(GameTime gameTime)//like walking, but 2/3 the speed, making little noise.
        {
            int runningtotal = ActionTimeOverflow + gameTime.ElapsedGameTime.Milliseconds;//pun intended
           
            if (runningtotal >= sneakOffsetPixelTime)
            {
                int pixelsNow = runningtotal / sneakOffsetPixelTime;
                ActionTimeOverflow = runningtotal % sneakOffsetPixelTime;
                pixelsMoved += pixelsNow;
                if (pixelsMoved >= TileDimensions.X)
                {
                    if (pixelsMoved > TileDimensions.X)
                    {
                        int Reduction = pixelsMoved - (int)TileDimensions.X;
                        pixelsNow -= Reduction;
                    }
                    pixelsMoved = 0;
                    IsBusy = false;
                    ActionTimeOverflow = 0;
                }
                offset += Direction * pixelsNow;
            }
            else
            {
                ActionTimeOverflow += runningtotal;
            }
            
        }

        protected virtual void Interact(GameTime gameTime)
        {

        }

        //end Action Methods

        protected virtual void ReturnToIdle()
        {
            IsBusy = false;
            ActionFrameSet = 0;
            Image.SpriteSheetEffect.SwitchFrame = Image.SpriteSheetEffect.BaseAnimationSpeed;
            Image.SpriteSheetEffect.CurrentFrame.Y = FacingAddup;

        }

        protected bool DecideWhattoDo(GameTime gameTime, out int Action)
        {
            switch (InputManager.Instance.ActionKey)
            {
                /// <summary ActionFrameSet>
                /// The multiple of 4 referrring to the animation of whichever current action should be ocurring.
                /// Key:
                /// 0 = idle
                /// 1 = movement
                /// 2 = running
                /// 3 = regular attacking
                /// 4 = heavy attacking
                /// 5 = dodging
                /// 6 = blocking
                /// 7 = parrying
                /// 8 = sneaking
                /// 9 = climbing into a container
                /// 10 = climbing out of a container
                /// 
                /// These numbers are used both by animations and to determine by update logic what action is currently being taken.
                /// 
                /// </summary>

                case Keys.R://Facing
                    Action = -1;
                    break;

                case Keys.Space://Attack
                    if (InputManager.Instance.ModifierKey == Keys.LeftShift)
                    {
                        Action = 4;
                        break;
                    }
                    else
                    {
                        Action = 3;
                        break;
                    }
                case Keys.C://Dodge
                    Action = 5;
                    break;
                case Keys.B://Block
                    Action = 6;
                    break;
                case Keys.V://Parry
                    Action = 7;
                    break;
                case Keys.F://Interact
                    Action = 9;
                    break;
                case Keys.G://Special Moves 1 + 2
                    if (InputManager.Instance.ModifierKey == Keys.LeftShift)
                    {
                        Action = 10;
                        break;
                    }
                    else
                    {
                        Action = 11;
                        break;
                    }
                case Keys.H://Special Moves 3 + 4
                    if (InputManager.Instance.ModifierKey == Keys.LeftShift)
                    {
                        Action = 12;
                        break;
                    }
                    else
                    {
                        Action = 13;
                        break;
                    }
                case Keys.N://Special Moves 5 + 6
                    if (InputManager.Instance.ModifierKey == Keys.LeftShift)
                    {
                        Action = 14;
                        break;
                    }
                    else
                    {
                        Action = 15;
                        break;
                    }

                case Keys.Sleep://no action buttons; default is walking if there is a target location
                    Action = 0;
                    break;

                default:
                    throw new Exception("NewActionButton");
            }
            if (Action != 0)//if is doing something in particular
            {
                if (Action == -1)//if is a facing command, correct the -1 that got through this step back to idle's animation
                {
                    Action = 0;
                }
                switch (InputManager.Instance.DirectionKey)
                {
                    case Keys.W:
                        FacingAddup = 3;
                        return true;
                    case Keys.A:
                        FacingAddup = 1;
                        return true;
                    case Keys.S:
                        FacingAddup = 0;
                        return true;
                    case Keys.D:
                        FacingAddup = 2;
                        return true;
                    default:
                        return true;
                }
            }
            else//isn't acting... check if moving in some way instead.
            {
                switch (InputManager.Instance.DirectionKey)
                {
                    case Keys.W:
                        FacingAddup = 3;
                        Action = CheckWalkType();
                        return true;
                    case Keys.A:
                        FacingAddup = 1;
                        Action = CheckWalkType();
                        return true;
                    case Keys.S:
                        FacingAddup = 0;
                        Action = CheckWalkType();
                        return true;

                    case Keys.D:
                        FacingAddup = 2;
                        Action = CheckWalkType();
                        return true;

                    default:
                        Action = 0;
                        return false;
                }

            }
        }
        private int CheckWalkType()
        {
            switch (InputManager.Instance.ModifierKey)
            {
                case Keys.LeftShift://Run
                    return 2;
                case Keys.LeftControl://sneak
                    return 8;
                default:
                    return 1;
            }
        }
        public virtual void Draw(SpriteBatch spriteBatch, Camera camera)
        {
            Image.Position = (TilePosition - camera.Origin) * TileDimensions;
            Image.Position -= camera.Offset;
            Image.Position += offset;
            Image.Position += TileAllign;

            Image.Draw(spriteBatch);
        }

        public virtual void Draw(SpriteBatch spriteBatch, Vector2 CameraOffset, Vector2 Origin)
        {
            Image.Position = (TilePosition - Origin) * TileDimensions;
            Image.Position -= CameraOffset;
            Image.Position += offset;
            Image.Position += TileAllign;

            Image.Draw(spriteBatch);
        }

        public void AssignNewMoveTime(int NewMoveSpeed)
        {
            SPD = NewMoveSpeed;
            moveTime = BaseMoveTime / NewMoveSpeed;//how long it takes to walk 1 tile.
            walkOffsetPixelTime = moveTime / (int)TileDimensions.X;
            runOffsetPixelTime = walkOffsetPixelTime / 2;
            sneakOffsetPixelTime = runOffsetPixelTime * 3;
            dodgeOffsetPixelTime = walkOffsetPixelTime / 3;
        }

        protected bool CheckWalkValid()
        {
            if (WorldCollision.CheckTargetBool(mapRef.Collision, TilePosition + Direction,6))
            {//if Is Passable (collision check)
                return true;
            }
            else
            {
                //Play "thud" sound effect [Unimplemented!!]
                return false;
            }
        }

        

       

        protected static int GetFacing(Vector2 Direction)//reverses the process that gives the Bing's Direction value to fin facing based on a vector direction.
        {
            if (Direction == new Vector2(0, 1))
            {
                return 0;
            }
            if (Direction == new Vector2(-1, 0))
            {
                return 1;
            }
            if (Direction == new Vector2(1, 0))
            {
                return 2;
            }
            if (Direction == new Vector2(0, -1))
            {
                return 3;
            }
            else
            {
                throw new Exception("given invalid Direction - must only have a value for X OR Y");
            }
        }

        public static Vector2 GetDirection(int Facing)//Mimics the process to give the Being's Direction for other uses.
        {

            {
                switch (Facing)
                {
                    case 0:
                        return new Vector2(0, 1);
                    case 1:
                        return new Vector2(-1, 0);
                    case 2:
                        return new Vector2(1, 0);
                    case 3:
                        return new Vector2(0, -1);
                    default:
                        throw new Exception("given invalid FacingAddup");
                }

            }

        }

      

    }
}
