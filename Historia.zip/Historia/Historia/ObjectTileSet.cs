﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Xml.Serialization;

namespace Historia
{
    public class ObjectTileSet: TileSet
    {

        public class ObjectRowSchema
        {
            public Vector2 Dimensions;
            public int Instances;
            public bool CanClimbInto;
            public bool Opaque;
            public bool Traversable;
            public bool Destructible;
            public int PresenceY;
        }
        

        [XmlElement("RowSchema")]
        public List<ObjectRowSchema> RowSchemas;

        public string Purpose;

        public override void LoadContent()
        {
            Image.LoadContent();
        }
        public override void UnloadContent()
        {
            Image.UnloadContent();
        }

        public int WhereRowStarts(int RowIndex)
        {
            int offset = 0;
            for(int I = 0; I < RowIndex; I++)
            {
                offset += (int)RowSchemas[I].Dimensions.Y * (int)TileDimensions.Y;
            }
            return offset;
        }

    }
}
