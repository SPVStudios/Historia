﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Xml.Serialization;

namespace Historia
{
    public class TileSet
    {
        public Image Image;
        public string Name;
        public Vector2 TileDimensions;
        public FloorTileSetSchema Schema;

        public TileSet(string Path, Vector2 TileSize, string SchemaPath)//for when loading the image with no XmlLoader...
        {
            Image.Path = Path;
            TileDimensions = TileSize;
            XmlManager<FloorTileSetSchema> Loader = new XmlManager<FloorTileSetSchema>();
            Schema = Loader.Load(SchemaPath);
        }

        public TileSet()//for when loading the image WITH an XmlLoader...
        {

        }


        public virtual void LoadContent()
        {
            Image.LoadContent();
        }
        public virtual void UnloadContent()
        {
            Image.UnloadContent();
        }

    }
}
