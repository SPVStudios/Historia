﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Historia
{
    public class Passageway
    {
        public Rectangle Location;

        public class Endpoint
        {
            public Vector2 Location;
            public int EndPointID;

            public Endpoint(Vector2 location, int endPointID)
            {
                Location = location;
                EndPointID = endPointID;
            }

        }

        public Endpoint End1;
        public Endpoint End2;
        public bool IsVertical;
        public int Length;

        public Passageway(Rectangle Site, Endpoint _End1, Endpoint _End2)
        {
            Location = Site;
            End1 = _End1;
            End2 = _End2;
            Vector2 distance = End2.Location - (End1.Location) ;
            if (distance.X == 0)//if there is no X movement...
            {
                IsVertical = true;
                Length = (int)distance.Y;
            }
            else
            {
                IsVertical = false;
                Length = (int)distance.X;
            }
            if (RectMethod.LocationIsInRectangle(End1.Location, this.Location))
            {
                throw new Exception("Shouldn't Be!");
            }
            else if(RectMethod.LocationIsInRectangle(End2.Location, this.Location))
            {
                throw new Exception("Shouldn't Be!");
            }
        }


    }
}
