﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Historia;

namespace Historia.Abilities
{
    public abstract class Special_Move
    {
        Image AlternateAnimation;//if requires a new animation. This should be an image with a SpriteSheet effect.
        bool ReqAlternateAnimation;
        int ExistingAnimationSet;//if does not require a new animation
        [XmlIgnore]
        protected Being Master;

        public string DamageType;
        public int ExtraAttack;//Attack added on to the user's total during an attack.
        public int AttackModifier;//The Percentage attack that the move is multiplied by, before adding additional attack as above. >100 is better.

        public string IsOffensive;//can deal damage
        public bool RequiresAccuracyCheck;
        public bool CanBeDodged;




        public virtual void LoadContent(ref Being Master)
        {
            this.Master = Master;
            if (ReqAlternateAnimation)
            {
                AlternateAnimation.LoadContent();
            }

        }

        public virtual void UnloadContent()
        {
            AlternateAnimation.UnloadContent();
        }

        public abstract bool StartAction();//Bool is whether or not the move should go ahead.(Check this as part of the system.
        
        public abstract void ActOut();


    }
}
