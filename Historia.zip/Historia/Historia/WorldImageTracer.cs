﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Xna.Framework.Graphics;
using System.Drawing;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;


namespace Historia
{
    class WorldImageTracer
    {
        const string terrainsPath = "Load/WorldMap_ref16.xml";

        public static void CreateandSaveFloorMapImage(int[,] Map, Vector2 MapSize, int Version)
        {
            RenderTarget2D Target = new RenderTarget2D(ScreenManager.Instance.GraphicsDevice, (int)MapSize.X * 16, (int)MapSize.Y * 16);
            ContentManager content = new ContentManager(ScreenManager.Instance.Content.ServiceProvider, "Content");


            ScreenManager.Instance.GraphicsDevice.SetRenderTarget(Target);
            ScreenManager.Instance.GraphicsDevice.Clear(Color.Transparent);
            ScreenManager.Instance.SpriteBatch.Begin();

            XmlManager<Image> ImgLoad = new XmlManager<Image>();
            Image Terrains = ImgLoad.Load(terrainsPath);
            List<Rectangle> terrainSourceRects = new List<Rectangle>()
            {
                // 0 : Ocean (impassable)
                new Rectangle(0,0,16,16),
                // 1 : shallow water (impassable)
                new Rectangle(16,0,16,16),
                // 2 : Mountains (impassable)
                 new Rectangle(32,0,16,16),
                // 3 : River (impasssable)
                 new Rectangle(48,0,16,16),
                // 4 : Cliff (impassable)
                 new Rectangle(64,0,16,16),
                // 5 : Ford
                 new Rectangle(80,0,16,16),
                // 6 : Bridge
                 new Rectangle(96,0,16,16),
                // 7 : Desert
                 new Rectangle(112,0,16,16),
                // 8 : Plains
                 new Rectangle(0,16,16,16),
                // 9 : Grassland
                 new Rectangle(16,16,16,16),
                // 10 : Forest
                 new Rectangle(32,16,16,16),
                // 11 : Swamp
                 new Rectangle(48,16,16,16),
                // 12 : Beach
                 new Rectangle(64,16,16,16),
                 // 13 : Lake
                 new Rectangle(96,16,16,16),
            };
            Terrains.LoadContent();
            for (int X = 0; X < MapSize.X; X++)
            {
                for (int Y = 0; Y < MapSize.Y; Y++)
                {
                    Rectangle ThisSource = terrainSourceRects[Map[X, Y]];
                    {
                        ScreenManager.Instance.SpriteBatch.Draw(Terrains.Texture, new Rectangle(X * 16, Y * 16, 16, 16),ThisSource, Color.White);
                    }
                    
                }
            }
            ScreenManager.Instance.SpriteBatch.End();



            var ImageStream = new FileStream("Content/Dungeon Imaging/Output/WMap_" + Version + "_Terrains.png", FileMode.Create);


            Target.SaveAsPng(ImageStream, Target.Width, Target.Height);

            ImageStream.Close();


            ScreenManager.Instance.GraphicsDevice.SetRenderTarget(null);
            content.Unload();
        }

        public static void CreateandSaveFloorMapImage(int[,] Map, Vector2 MapSize, List<Vector2> Villages, List<Vector2> Dungeons, int Version)
        {
            RenderTarget2D Target = new RenderTarget2D(ScreenManager.Instance.GraphicsDevice, (int)MapSize.X * 16, (int)MapSize.Y * 16);
            ContentManager content = new ContentManager(ScreenManager.Instance.Content.ServiceProvider, "Content");


            ScreenManager.Instance.GraphicsDevice.SetRenderTarget(Target);
            ScreenManager.Instance.GraphicsDevice.Clear(Color.Transparent);
            ScreenManager.Instance.SpriteBatch.Begin();

            XmlManager<Image> ImgLoad = new XmlManager<Image>();
            Image Terrains = ImgLoad.Load(terrainsPath);
            List<Rectangle> terrainSourceRects = new List<Rectangle>()
            {
                // 0 : Ocean (impassable)
                new Rectangle(0,0,16,16),
                // 1 : shallow water (impassable)
                new Rectangle(16,0,16,16),
                // 2 : Mountains (impassable)
                 new Rectangle(32,0,16,16),
                // 3 : River (impasssable)
                 new Rectangle(48,0,16,16),
                // 4 : Cliff (impassable)
                 new Rectangle(64,0,16,16),
                // 5 : Ford
                 new Rectangle(80,0,16,16),
                // 6 : Bridge
                 new Rectangle(96,0,16,16),
                // 7 : Desert
                 new Rectangle(112,0,16,16),
                // 8 : Plains
                 new Rectangle(0,16,16,16),
                // 9 : Grassland
                 new Rectangle(16,16,16,16),
                // 10 : Forest
                 new Rectangle(32,16,16,16),
                // 11 : Swamp
                 new Rectangle(48,16,16,16),
                // 12 : Beach
                 new Rectangle(64,16,16,16),
                 // 13 : Lake
                 new Rectangle(80,16,16,16),
            };
            Terrains.LoadContent();
            for (int X = 0; X < MapSize.X; X++)
            {
                for (int Y = 0; Y < MapSize.Y; Y++)
                {
                    Rectangle ThisSource = terrainSourceRects[Map[X, Y]];
                    {
                        ScreenManager.Instance.SpriteBatch.Draw(Terrains.Texture, new Rectangle(X * 16, Y * 16, 16, 16), ThisSource, Color.White);
                        if(Villages.Contains(new Vector2(X, Y)))
                        {
                            ScreenManager.Instance.SpriteBatch.Draw(Terrains.Texture, new Rectangle(X * 16, Y * 16, 16, 16), new Rectangle(96, 16, 16, 16), Color.White);
                        }
                        if (Dungeons.Contains(new Vector2(X, Y)))
                        {
                            ScreenManager.Instance.SpriteBatch.Draw(Terrains.Texture, new Rectangle(X * 16, Y * 16, 16, 16), new Rectangle(112, 16, 16, 16), Color.White);
                        }
                    }

                }
            }
            ScreenManager.Instance.SpriteBatch.End();



            var ImageStream = new FileStream("Content/Dungeon Imaging/Output/WMap_" + Version + "_Terrains.png", FileMode.Create);


            Target.SaveAsPng(ImageStream, Target.Width, Target.Height);

            ImageStream.Close();


            ScreenManager.Instance.GraphicsDevice.SetRenderTarget(null);
            content.Unload();
        }
    }
}
