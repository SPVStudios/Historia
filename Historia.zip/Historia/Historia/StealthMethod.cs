﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using System.Threading.Tasks;

namespace Historia
{
    public static class StealthMethod
    {
        public static Dictionary<Vector2, int> CombineSuspicionLists(Dictionary<Vector2, int> A, Dictionary<Vector2, int> B)
        {
            foreach (KeyValuePair<Vector2, int> I in B)
            {
                if (A.ContainsKey(I.Key))
                {
                    A[I.Key] += I.Value;
                }
                else
                {
                    A.Add(I.Key, I.Value);
                }
            }
            return A;
        }

        public static Dictionary<Vector2, int> TallySuspicionInLists(Dictionary<Vector2, int> A, Dictionary<Vector2, int> B)
        {
            foreach (KeyValuePair<Vector2, int> I in B)
            {
                if (A.ContainsKey(I.Key))
                {
                    A[I.Key] += I.Value;
                }
            }
            return A;
        }

        public static Dictionary<Vector2, int> TallySuspicionInLists(Dictionary<Vector2, int> A, Dictionary<Vector2, int> B,
            out Dictionary<Vector2, int> NotInA)
        {
            NotInA = new Dictionary<Vector2, int>();
            foreach (KeyValuePair<Vector2, int> I in B)
            {
                if (A.ContainsKey(I.Key))
                {
                    A[I.Key] += I.Value;
                }

                else
                {
                    NotInA.Add(I.Key, I.Value);
                }
            }
            return A;
        }

        public static Dictionary<Vector2, int> TallySuspicionInLists(Dictionary<Vector2, int> A, Dictionary<Vector2, int> B,
            out Dictionary<Vector2, int> NotInA, bool DecrementNotInA)
        {
            NotInA = new Dictionary<Vector2, int>();
            foreach (KeyValuePair<Vector2, int> I in B)
            {
                if (A.ContainsKey(I.Key))
                {
                    A[I.Key] += I.Value;
                }

                else if (I.Value > 1)
                {
                    NotInA.Add(I.Key, I.Value - (I.Value/1000 + 1)*(I.Value/1000 + 1));
                }
            }

            return A;
        }

        public static void AddNewSuspiciousness(ref Dictionary<Vector2, int> Current, Vector2 NewLoc, int NewSusp)
        {
            if (Current.ContainsKey(NewLoc))
            {
                Current[NewLoc] += NewSusp;
            }
            else
            {
                Current.Add(NewLoc, NewSusp);
            }
        }

        public static Dictionary<Vector2, int> MassCheckLineOfSight(Map MapRef, Vector2 YourLocation, Vector2 YourDirection, Dictionary<Vector2, int> Targets)
            //run L.O.S Checks and FOV checks to update suspicions
        {
            if(Targets.Count > 0)
            {
                Dictionary<Vector2, int> InFieldOfView = new Dictionary<Vector2, int>();
                foreach (KeyValuePair<Vector2, int> I in Targets)
                {
                    if (CheckFOV(YourLocation, I.Key, YourDirection))
                    {
                        InFieldOfView.Add(I.Key, I.Value);
                    }
                }
                if(InFieldOfView.Count > 0)
                {
                    Dictionary<Vector2, int> Visible = new Dictionary<Vector2, int>();
                    foreach (KeyValuePair<Vector2, int> I in InFieldOfView)
                    {
                        if (CheckLOS(MapRef, YourLocation, I.Key))
                        {
                            Visible.Add(I.Key, I.Value);
                        }
                    }
                    return Visible;
                }
            }
            return new Dictionary<Vector2, int>();
            
        }

        public static bool CheckFOV(Vector2 YourLocation, Vector2 Target, Vector2 Direction)//returns whether the target is in a 90 degree FOV in front of them.
        {
            int X = (int)Target.X - (int)YourLocation.X;
            int Y = (int)Target.Y - (int)YourLocation.Y;
            if (Direction.X != 0)///if t
            {
                if (Math.Sign(X) == Math.Sign(Direction.X) && MathMethod.Modulus(Y) <= MathMethod.Modulus(X))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else if (Direction.Y != 0)
            {
                if (Math.Sign(Y) == Math.Sign(Direction.Y) && MathMethod.Modulus(X) <= MathMethod.Modulus(Y))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                throw new Exception("not seeming to be looking anywhere at all");
            }


        }

        public static bool CheckLOS(Map mapRef, Vector2 YourLocation, Vector2 Target)
        {
            int X = 0;
            int Y = 0;
            double bitsX = 0;
            double bitsY = 0;
            double CalcX;
            double CalcY;

            int DifferenceInX = (int)Target.X - (int)YourLocation.X;
            int DifferenceInY = (int)Target.Y - (int)YourLocation.Y;
            int IncrementX = Math.Sign(DifferenceInX);
            int IncrementY = Math.Sign(DifferenceInY);

            double Move1X = (double)DifferenceInY / DifferenceInX;
            double Move1Y = (double)DifferenceInX / DifferenceInY;

            while (true)
            {
                CalcX = (1 - bitsX) / MathMethod.Modulus(Move1Y);
                CalcY = (1 - bitsY) / MathMethod.Modulus(Move1X);


                if (CalcX < CalcY)
                {
                    X+= IncrementX;

                    bitsX = 0;

                    bitsY+=CalcX;
                }
                else if (CalcY < CalcX)
                {
                    Y+= IncrementY;

                    bitsY = 0;

                    bitsX+=CalcY;
                }
                else
                {
                    if (mapRef.Opaques[(int)YourLocation.X + X + 1, (int)YourLocation.Y + Y] == true
                        && mapRef.Opaques[(int)YourLocation.X + X, (int)YourLocation.Y + Y + 1] == true)
                    {
                        return false;
                    }
                    Y+= IncrementY;
                    X+=IncrementX;
                    bitsX = 0;
                    bitsY = 0;
                }
                if (mapRef.Opaques[(int)YourLocation.X + X, (int)YourLocation.Y + Y] == true)
                {
                    return false;
                }
                if (YourLocation.X + X == Target.X && YourLocation.Y + Y == Target.Y)
                {
                    return true;
                }
            }
        }

        public static Dictionary<Vector2,int> TemperSuspicionsByDistance(Dictionary<Vector2, int> NewSuspicions, Vector2 YourLocation)
        {
            Dictionary<Vector2, int> Replacement = new Dictionary<Vector2, int>();
            foreach(KeyValuePair<Vector2,int> Sus in NewSuspicions)
            {
                int DistanceFrom = RectMethod.DistanceBetweenLocations(YourLocation, Sus.Key);
                DistanceFrom = DistanceFrom / 2;
                int NewSuspiciousness = Sus.Value / (DistanceFrom  + 1);
                Replacement.Add(Sus.Key, NewSuspiciousness);
            }

            return Replacement;
        }

        public static int TallyTotalSuspicion(Dictionary<Vector2, int>S)
        {
            int Total = 0;
            foreach(KeyValuePair<Vector2,int> I in S)
            {
                Total += I.Value;
            }
            return Total;
        }
    }

}
