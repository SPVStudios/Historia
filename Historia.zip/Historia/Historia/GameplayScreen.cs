﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Historia
{
    public class GameplayScreen : GameScreen
    {
        public Player player;
        public Map map;
        Camera camera;

        HealthBar HPBar;
        SuspicionBar suspicionBar;
        SpriteFont font;

        Vector2 tilesOnScreen;
        const int NumOfEnemies = 0;

        bool exiting;

        public override void LoadContent()
        {
            

            base.LoadContent();
            XmlManager<Player> playerLoader = new XmlManager<Player>();
            player = playerLoader.Load("Load/Gameplay/Player.xml");

            //if loading from a GameState info....
            if (GameState.Instance.EnteringDungeon)
            {
                if (GameState.Instance.PlayerExists)
                {
                    player.Stats = GameState.Instance.PlayerStats;
                }//else the default value will be used as normal having not been overwritten
                
                map = DungeonCreator.CreateMap(3, GameState.Instance);
            }
            else
            {
                map = DungeonCreator.CreateMap(3);
            }
            

            AIMoveManager.Instance.StartNewFloor(map, NumOfEnemies);
            map.LoadContent(true);
           

            ContentManager content = new ContentManager(ScreenManager.Instance.Content.ServiceProvider, "Content");

            font = content.Load<SpriteFont>("Gameplay/Fonts/Font1");

            int tilesacross;
            if (ScreenManager.Instance.Dimensions.X % map.TileDimensions.X != 0)
            {
                tilesacross = ((int)ScreenManager.Instance.Dimensions.X / (int)map.TileDimensions.X) + 1;
            }
            else
            {
                tilesacross = ((int)ScreenManager.Instance.Dimensions.X / (int)map.TileDimensions.X);
            }

            int tilesdown;
            if (ScreenManager.Instance.Dimensions.Y % map.TileDimensions.Y != 0)
            {
                tilesdown = ((int)ScreenManager.Instance.Dimensions.Y / (int)map.TileDimensions.Y) + 1;
            }
            else
            {
                tilesdown = ((int)ScreenManager.Instance.Dimensions.Y / (int)map.TileDimensions.Y);
            }
            tilesOnScreen = new Vector2(tilesacross, tilesdown);

            


            player.LoadContent(map.TileDimensions, map.EntryLoc + new Vector2(0,1), map);
            map.SpawnEnemies(NumOfEnemies,player.CurrentRoomIn);

            camera = new Camera(map.Size, tilesOnScreen, map.TileDimensions, player.TilePosition);
            StealthManager.Instance.StartNewFloor(map);

            XmlManager<HealthBar> HPBL = new XmlManager<HealthBar>();
            HPBar = HPBL.Load("Load/Gameplay/HealthBar.xml");
            HPBar.LoadContent();

            XmlManager<SuspicionBar> SBL = new XmlManager<SuspicionBar>();
            suspicionBar = SBL.Load("Load/Gameplay/SuspicionBar.xml");
            suspicionBar.LoadContent();

            GameState.Instance.EnteringDungeon = false;//resets in case of error elsewhere
            GameState.Instance.PlayerExists = true;
            exiting = false;
        }

        /*private Vector2 FirstValidPosition(Map.LevelCollisionMap Collisions, Vector2 MapSize)
        {
            for(int X = 0; X < MapSize.X; X++)
            {
                for(int Y = 0; Y< MapSize.Y; Y++)
                {
                    if(Collisions.CMap[X,Y] == 30)
                    {
                        return new Vector2(X, Y);
                    }
                }
            }
            throw new Exception("AllImpassable");
        }*/

        public override void UnloadContent()
        {
            base.UnloadContent();
            map.UnloadContent();
            player.UnloadContent();
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            player.Update(gameTime, out bool PlayerDead);
            if (PlayerDead)
            {
                ScreenManager.Instance.ChangeScreens("GameOverScreen");
            }
            if (PlayerLeaving)
            {//if leaving map:
                if (!exiting)//if process yet to be called
                {
                    //call GameStateEnterWorld
                    GameStateToEnterWorld();
                    ScreenManager.Instance.ChangeScreens("WorldScreen");
                    exiting = true;
                    
                }
                //else wait for exit
                
            }
            else
            {
                StealthManager.Instance.Update();
                map.Update(gameTime);
                if (map.LivingEnemies < NumOfEnemies)
                {
                    map.SpawnEnemies(1, player.CurrentRoomIn);
                }

                camera.Update(gameTime, player.TilePosition, player.Offset, map.FullMap);
                AIMoveManager.Instance.Update(gameTime);
                AttackManager.Instance.Update(gameTime);
            }
            

            


        }
        //as a matter of course, it is probably wise to update your map AFTER your player, but
        //draw your map BEFORE your player.
        //some map elements are based on how the player moves, but you do not want the map drawn OVER the player.

        public override void Draw(SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);
            map.Draw(spriteBatch, camera);
            player.Draw(spriteBatch, camera);
            if(map.LivingEnemies > 0)
            {
                //spriteBatch.DrawString(font, "Enemy HP: " + map.CurrentEnemies[0].HP + "/ " + map.CurrentEnemies[0].MaxHP, new Vector2(10, 80), Color.PaleVioletRed);
                //spriteBatch.DrawString(font, "Susp: " + map.CurrentEnemies[0].TotalofAlertPoints, new Vector2(10, 100), Color.PaleVioletRed);
                if(map.CurrentEnemies.Count > 1)
                {
                    //spriteBatch.DrawString(font, "Enemy 2 HP: " + map.CurrentEnemies[1].HP + "/ " + map.CurrentEnemies[1].MaxHP, new Vector2(10, 130), Color.MidnightBlue);
                    //spriteBatch.DrawString(font, "Susp 2 : " + map.CurrentEnemies[1].TotalofAlertPoints, new Vector2(10, 150), Color.MidnightBlue);
                }
            }

            HPBar.Draw(spriteBatch, player.Stats.HP, player.Stats.MaxHP);
            if(map.CurrentEnemies.Count > 0)
            {
                suspicionBar.Draw(spriteBatch, map.CurrentAvgSuspicion);
            }
            int EnemiesKilled = map.NextEnemyIndex - NumOfEnemies;
            spriteBatch.DrawString(font, "Total Enemies Killed: " + EnemiesKilled, new Vector2(10, 80), Color.AliceBlue);
        }

       public void GameStateToEnterWorld()
        {
            player.Stats.AgeStatChanges();
            GameState.Instance.PlayerStats = player.Stats;
            GameState.Instance.EnteringWorld = true;
            GameState.Instance.EnteringVillage = GameState.Instance.EnteringVillage = false;
            GameState.Instance.PlayerExists = true;
        } 

        public bool PlayerLeaving
        {
            get
            {
                int CollValue = map.Collision.CMap[(int)player.TilePosition.X, (int)player.TilePosition.Y];
                if ( CollValue== 20 || CollValue == 21)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}