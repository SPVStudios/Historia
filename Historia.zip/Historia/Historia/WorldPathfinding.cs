﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Xml.Serialization;
namespace Historia
{
    public static class WorldPathfinding
    {
        public static bool GetToLocation(Vector2 FinalLocation, Vector2 StartLocation, out List<Vector2> PathTaken, int[,] Coll, Random D, int MinPass)
        {
            PathTaken = new List<Vector2>();
            return GetToLocation(FinalLocation, StartLocation, out PathTaken, Coll, new List<Vector2>(), 0, D,MinPass);
        }

        private static bool GetToLocation(Vector2 FinalLocation, Vector2 StartLocation, out List<Vector2> PathTaken, int[,] Coll, List<Vector2> AlreadyUsedMidpoints, int RecLayer, Random D, int MinCollPass)
        ///KnightPath algorithm
        ///creates a sequential list of co-ordinates to follow 1 by 1 to reach a destination.
        /// the boolean refers to whether such a location is accessible; the ouptut list is how you get there.
        {
            RecLayer++;

            if (FinalLocation == StartLocation)
            {
                PathTaken = new List<Vector2>();

                return true;
            }
            else if (RectMethod.TwoTilesAreAdjacentOrSame(StartLocation, FinalLocation))
            {
                PathTaken = new List<Vector2>() { FinalLocation };
                return true;
            }
            else if (RecLayer > 10)
            {
                PathTaken = new List<Vector2>();
                return false;
            }
            else if (WorldCollision.CheckTargetBool(Coll, FinalLocation,MinCollPass))
            {
                Vector2 Movement = FinalLocation - StartLocation;
                //try with horizntal-first L
                bool CanHoriFirst = WorldP_Check_Path(StartLocation, Movement, false, Coll, out Vector2 HoriProb, out bool HoriProbIsVertical, MinCollPass);
                //try with vertical-first L
                bool CanVertiFirst = WorldP_Check_Path(StartLocation, Movement, true, Coll, out Vector2 VertiProb, out bool VertiProbIsVertical,MinCollPass);

                if (CanVertiFirst)
                {
                    if (CanHoriFirst && D.Next(0, 100) > 50)
                    {
                        PathTaken = WorldP_Return_Path(StartLocation, Movement, false);
                        return true;
                    }
                    else
                    {
                        PathTaken = WorldP_Return_Path(StartLocation, Movement, true);
                        return true;
                    }
                }
                else if (CanHoriFirst)
                {
                    PathTaken = WorldP_Return_Path(StartLocation, Movement, false);
                    return true;
                }
                else
                {//if neither work, go along the obstacles from each to find a valid midpoint, if any.
                    List<Vector2> Midpoints = WorldP_Find_Midpoints(HoriProb, HoriProbIsVertical, VertiProb, VertiProbIsVertical, Coll, AlreadyUsedMidpoints,MinCollPass);
                    //if none, return false
                    if (Midpoints.Count == 0)
                    {
                        PathTaken = new List<Vector2>();//irrelevant, but must set out variable
                        return false;
                    }

                    else
                    {//(else) if some, Pathfind from start to any of these 4 midpoints, and from those midpoints to the end point.
                        List<List<Vector2>> Options = new List<List<Vector2>>();
                        AlreadyUsedMidpoints.AddRange(Midpoints);
                        for (int O = 0; O < Midpoints.Count; O++)
                        {
                            bool Valid = GetToLocation(Midpoints[O], StartLocation, out List<Vector2> FirstStint, Coll, AlreadyUsedMidpoints, RecLayer,D,MinCollPass);
                            if (Valid)
                            {
                                Valid = GetToLocation(FinalLocation, Midpoints[O], out List<Vector2> SecondStint, Coll, AlreadyUsedMidpoints, RecLayer,D,MinCollPass);
                                if (Valid)
                                {
                                    FirstStint.AddRange(SecondStint);
                                    Options.Add(FirstStint);
                                }
                            }
                        }

                        if (Options.Count == 0)
                        {
                            PathTaken = new List<Vector2>();
                            return false;
                        }
                        else if (Options.Count == 1)
                        {//return the only valid route
                            PathTaken = Options[0];
                            return true;
                        }
                        else//2+different Options
                        {
                            //for the above <=4 valid solutions, pick the one with the shortest list of locations, as it is most efficient,
                            //and return that.
                            int Shortest = Options[0].Count;
                            int ShortestIndex = 0;
                            for (int I = 1; I < Options.Count; I++)
                            {
                                if (Options[I].Count < Shortest)
                                {
                                    Shortest = Options[I].Count;
                                    ShortestIndex = I;
                                }
                            }
                            PathTaken = Options[ShortestIndex];
                            return true;
                        }
                    }
                }
            }
            else//target location isn't even valid
            {
                PathTaken = new List<Vector2>();
                return false;
            }
        }
        // ^^^ Not handled List<Vector2> PreviousLocations to prevent doubling back - add it to CheckPath vv

        public static bool WorldP_Check_Path(Vector2 StartLocation, Vector2 Movement,
            bool VerticalFirst, int[,] Coll, out Vector2 FirstProblem, out bool ProblemWasVertical, int MinCollPass)
        {
            if (VerticalFirst)
            {
                for (int Y = 0; MathMethod.Modulus(Y) < MathMethod.Modulus(Movement.Y); Y += Math.Sign(Movement.Y))
                {
                    if (!WorldCollision.CheckTargetBool(Coll, StartLocation + new Vector2(0, Y),MinCollPass))
                    {
                        FirstProblem = StartLocation + new Vector2(0, Y);
                        ProblemWasVertical = true;
                        return false;
                    }
                }
                //now horizontal
                for (int X = 0; MathMethod.Modulus(X) < MathMethod.Modulus(Movement.X); X += Math.Sign(Movement.X))
                {
                    if (!WorldCollision.CheckTargetBool(Coll, StartLocation + new Vector2(X, Movement.Y),MinCollPass))
                    {
                        FirstProblem = StartLocation + new Vector2(X, Movement.Y);
                        ProblemWasVertical = false;
                        return false;
                    }
                }
                FirstProblem = Vector2.Zero;
                ProblemWasVertical = false;
                return true;
            }
            else
            {//horizontal first
                for (int X = 0; MathMethod.Modulus(X) < MathMethod.Modulus(Movement.X); X += Math.Sign(Movement.X))
                {
                    if (!WorldCollision.CheckTargetBool(Coll, StartLocation + new Vector2(X, 0),MinCollPass))
                    {
                        FirstProblem = StartLocation + new Vector2(X, 0);
                        ProblemWasVertical = false;
                        return false;
                    }
                }
                //now vertical
                for (int Y = 0; MathMethod.Modulus(Y) < MathMethod.Modulus(Movement.Y); Y += Math.Sign(Movement.Y))
                {
                    if (!WorldCollision.CheckTargetBool(Coll, StartLocation + new Vector2(Movement.X, Y),MinCollPass))
                    {
                        FirstProblem = StartLocation + new Vector2(Movement.X, Y);
                        ProblemWasVertical = true;
                        return false;
                    }
                }
                FirstProblem = Vector2.Zero;
                ProblemWasVertical = false;
                return true;
            }
        }

        private static List<Vector2> WorldP_Return_Path(Vector2 StartLocation, Vector2 Movement,
            bool VerticalFirst)
        {
            List<Vector2> Path = new List<Vector2>();
            if (VerticalFirst)
            {
                for (int Y = Math.Sign(Movement.Y); MathMethod.Modulus(Y) < MathMethod.Modulus(Movement.Y); Y += Math.Sign(Movement.Y))
                {
                    Path.Add(new Vector2(StartLocation.X, StartLocation.Y + Y));
                }
                //now horizontal
                for (int X = 0; MathMethod.Modulus(X) < MathMethod.Modulus(Movement.X); X += Math.Sign(Movement.X))
                {
                    Path.Add(new Vector2(StartLocation.X + X, StartLocation.Y + Movement.Y));
                }
                Path.Add(StartLocation + Movement);

                return Path;
            }
            else
            {//horizontal first
                for (int X = Math.Sign(Movement.X); MathMethod.Modulus(X) < MathMethod.Modulus(Movement.X); X += Math.Sign(Movement.X))
                {
                    Path.Add(StartLocation + new Vector2(X, 0));

                }
                //now vertical
                for (int Y = 0; MathMethod.Modulus(Y) < MathMethod.Modulus(Movement.Y); Y += Math.Sign(Movement.Y))
                {
                    Path.Add(StartLocation + new Vector2(Movement.X, Y));
                }
                Path.Add(StartLocation + Movement);
                return Path;
            }
        }

        private static List<Vector2> WorldP_Find_Midpoints(Vector2 FirstIssue, bool FirstIssueEncounteredWhenVertical, Vector2 Second, bool SecondVerti, int[,] Coll, List<Vector2> AlreadyUsedMidpoints, int MinColl)
        {
            List<Site> Options = new List<Site>();

            if (FirstIssueEncounteredWhenVertical)
            {
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(1, 0) });
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(-1, 0) });
            }
            else
            {
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(0, 1) });
                Options.Add(new Site { Loc = FirstIssue, NextDirection = new Vector2(0, -1) });
            }

            if (SecondVerti)
            {
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(1, 0) });
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(-1, 0) });
            }
            else
            {
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(0, 1) });
                Options.Add(new Site { Loc = Second, NextDirection = new Vector2(0, -1) });
            }

            List<Vector2> ConfirmedLocations = new List<Vector2>();

            while (Options.Count > 0)
            {
                List<Site> NewOptions = new List<Site>();
                for (int I = 0; I < Options.Count; I++)
                {

                    Vector2 NewLoc = Options[I].Loc + Options[I].NextDirection;
                    int Result = WorldCollision.CheckTarget(Coll, NewLoc);
                    if (Result == 0)
                    {//encounters void
                        //failed, don't add to next round
                    }
                    else if (Result >= MinColl)
                    {
                        if (!ConfirmedLocations.Contains(NewLoc))
                        {
                            //pass - don't add to options, but to confirmedlocations
                            ConfirmedLocations.Add(NewLoc);
                        }
                    }
                    else
                    {
                        if (WorldP_SiteIsUnique(Options, new Site { Loc = NewLoc, NextDirection = Options[I].NextDirection }, NewOptions))
                        {
                            NewOptions.Add(new Site { Loc = NewLoc, NextDirection = Options[I].NextDirection });
                        }
                    }
                }
                Options = new List<Site>();
                Options.AddRange(NewOptions);
            }

            return ListMethod.FilterBOutOfA(ConfirmedLocations, AlreadyUsedMidpoints);
        }




        private static bool WorldP_SiteIsUnique(List<Site> Previous, Site Addition, List<Site> New)
        {
            for (int S = 0; S < Previous.Count; S++)
            {
                if (Previous[S].Loc == Addition.Loc && Addition.NextDirection * -1 == Previous[S].NextDirection)
                {
                    return false;
                }
            }
            for (int S = 0; S < New.Count; S++)
            {
                if (New[S].Loc == Addition.Loc && (Addition.NextDirection * -1 == New[S].NextDirection || Addition.NextDirection == New[S].NextDirection))
                {
                    return false;
                }
            }
            return true;
        }
    }
}
