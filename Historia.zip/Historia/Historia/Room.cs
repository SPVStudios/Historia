﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Historia
{
    public class Room
    {
        public class EntryPoint//these detail the MAP tile location of where the passageway starts,
            //and which room in the list it goes to, and which passageway in the list it uses to do so.
        {
            public Vector2 Location;
            public int RoomTo;
            public int PassagewayUsing;

            public EntryPoint(Vector2 Location, int RoomTo, int PassagewayUsing)
            {
                this.Location = Location;
                this.RoomTo = RoomTo;
                this.PassagewayUsing = PassagewayUsing;
            }
        }


        public List<Rectangle> Location//usually just one rectangle, but could be a compound shape.
        {
            get;
            private set;
        }
        public string RoomShape;
        public List<EntryPoint> EntryPoints;

        public Rectangle SpaceTakenUpOnTileMap;//the floor space of the room, PLUS the tiles for the walls around it.
        public string Purpose;

        public Room(Rectangle Location)
        {
            this.Location = new List<Rectangle>();
            this.Location.Add(Location);
            EntryPoints = new List<EntryPoint>();
            RoomShape = "Rectangle";
        }
        public Room(List<Rectangle> PartsOfTheRoom)
        {
            EntryPoints = new List<EntryPoint>();
            foreach (Rectangle Part in PartsOfTheRoom)
            {
                this.Location.Add(Part);
            }
            RoomShape = "Compound";
        }


        public void AddEntryPoint(int RoomTo, int PassagewayUsing, Vector2 Location)
        {
            EntryPoints.Add(new EntryPoint(Location, RoomTo, PassagewayUsing));
        }

    }
}
