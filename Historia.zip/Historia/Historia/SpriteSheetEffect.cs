﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using System.Xml.Serialization;

namespace Historia
{
    public class SpriteSheetEffect : ImageEffect
    ///<overview>
    ///The Spritesheet effect rotates through the x-axis frames of a given spritesheet, NOT THE Y.
    /// The different Columns of sprites should be the image of the entity in DIFFERENT STATES.
    /// 
    /// 
    ///</overview>




    {
        public int FrameCounter;
        public int SwitchFrame;
        public Vector2 CurrentFrame;
        public Vector2 AmountOfFrames;

        //variables monitoring the progress of a limited loop animation
        [XmlIgnore]
        public bool IsBusy { get; private set; }
        [XmlIgnore]
        public bool LimitedLoops { get; private set; }
        int NumLoopsLeft;
        int LoopYValueAfterLimitReached;

        [XmlIgnore]
        public int BaseAnimationSpeed
        {
            get; private set;
        }
            
            //the speed it reverts to after receiving a change-speed loop order.

        public int TimeforOneLoop
        {
            get
            {
                return SwitchFrame * (int)AmountOfFrames.X;
            }
        }

        public int FrameWidth
        {
            get
            {
                if (image.Texture != null)
                {
                    return image.Texture.Width / (int)AmountOfFrames.X;
                }
                return 0;//if no texture found
            }
        }

        public int FrameHeight
        {
            get//"get" fires every time this value is called.
            {
                if (image.Texture != null)
                {
                    return image.Texture.Height / (int)AmountOfFrames.Y;
                }
                return 0;//if no texture found
            }
        }

        public SpriteSheetEffect()
        {
            AmountOfFrames = new Vector2(1, 1);//4 wide, 4 tall
            CurrentFrame = new Vector2(1, 0);
            SwitchFrame = 100;
            BaseAnimationSpeed = 100;
            FrameCounter = 0;
        }

        public override void LoadContent(ref Image Image)
        {
            base.LoadContent(ref Image);
            BaseAnimationSpeed = SwitchFrame;
        }

        public override void UnloadContent()
        {
            base.UnloadContent();
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            if (image.IsActive)
            {
                FrameCounter += (int)gameTime.ElapsedGameTime.TotalMilliseconds;
                if (FrameCounter >= SwitchFrame)
                {
                    FrameCounter = 0;
                    CurrentFrame.X++;

                    if (CurrentFrame.X * FrameWidth >= image.Texture.Width)
                    {
                        //the animation always goes back to the first in a column, regardless of whether it was a limited-time thing or not.
                        CurrentFrame.X = 0;
                        if (LimitedLoops)
                        {
                            NumLoopsLeft--;
                            if (NumLoopsLeft <= 0)
                            {
                                IsBusy = false;
                                LimitedLoops = false;
                                CurrentFrame.Y = LoopYValueAfterLimitReached;
                                if (BaseAnimationSpeed != SwitchFrame)
                                {
                                    SwitchFrame = BaseAnimationSpeed;
                                }
                            }
                        }
                    }
                }
            }
            else//if image is inactive
            {
                CurrentFrame.X = 1;
            }

            image.SourceRect = new Rectangle((int)CurrentFrame.X * FrameWidth, (int)CurrentFrame.Y * FrameHeight, FrameWidth, FrameHeight);
        }

        public void StartLimitedLoop(int WhichAnimationY, int HowManyTimes, int WhatAnimationAfterwards)
        {
            if (!IsBusy)
            {

                CurrentFrame = new Vector2(0, WhichAnimationY);//starts the animation loop
                FrameCounter = 0;
                NumLoopsLeft = HowManyTimes;
                LoopYValueAfterLimitReached = WhatAnimationAfterwards;
                IsBusy = true;
                LimitedLoops = true;
            }
        }

        public void StartLimitedLoop(int WhichAnimationY, int HowManyTimes, int WhatAnimationAfterwards, int New_SwitchFrame)
        //this allows the speed of the animation to be changed only for the duration of the limited loop's runtime.
        {
            if (!IsBusy)
            {

                CurrentFrame = new Vector2(0, WhichAnimationY);//starts the animation loop
                FrameCounter = 0;
                NumLoopsLeft = HowManyTimes;
                LoopYValueAfterLimitReached = WhichAnimationY;
                IsBusy = true;
                LimitedLoops = true;
                SwitchFrame = New_SwitchFrame;
            }
        }

        public void StartLimitedLoop(int WhichAnimationY, int HowManyTimes, int WhatAnimationAfterwards, bool IsUrgent)
        //this doesn't need to check if it's free. It will override any previous limited animation loop.
        {

            CurrentFrame = new Vector2(0, WhichAnimationY);//starts the animation loop
            FrameCounter = 0;
            NumLoopsLeft = HowManyTimes;
            LoopYValueAfterLimitReached = WhichAnimationY;
            IsBusy = true;
            LimitedLoops = true;
        }
    }
}
