﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Xml.Serialization;

namespace Historia
{
    public class MapObject
    {

        public int PresenceY { get; private set; }
        // the Y value relative to the top tile of the object which gives which row it is drawn on,
        // to determine whether it is in front of or behind the player at diffferent points

        public Vector2 Dimensions { get; private set; }

        public Rectangle FullTileLocation { get; private set; }

        public Vector2 TL_TileLocation { get; private set; }//returns a vector of the top left tile of the object (for drawing, mostly)

        public Vector2 DrawLocation;

        public Vector2 TopLeftTile;
        public bool CanClimbInto
        {
            get; private set;
        }
        public bool Opaque
        {
            get; private set;
        }

        public bool Traversable
        {
            get; private set;
        }
        public bool Destructible
        {
            get; private set;
        }

        private Rectangle textureRect;
        public Rectangle SourceRect//public version that is read-only
        {
            get { return textureRect; }

        }

        public int WhichTileSet;


        public MapObject(int PresenceY,bool CanClimbInto, bool Opaque,bool Traversable, bool Destructible, Vector2 Position,
            Vector2 Dimensions, Vector2 TopLeftTile, Rectangle textureRect, int whichTileSet)//when creating a new one WITHOUT xml Loader
        {
            this.PresenceY = PresenceY;
            this.CanClimbInto = CanClimbInto;
            this.Opaque = Opaque;
            this.Traversable = Traversable;
            this.Destructible = Destructible;
            this.Dimensions = Dimensions;
            this.textureRect = textureRect;
            this.WhichTileSet = whichTileSet;

            FullTileLocation = new Rectangle((int)TopLeftTile.X, (int)TopLeftTile.Y, (int)Dimensions.X-1, (int)Dimensions.Y-1);
            //be careful with putting the above into an Xml file

        }

        public MapObject(ObjectTileSet TileSet, int whichTileSet, int whichSchema, Vector2 Location, Random D)//for when creating a random object from a RowSchema without an XmlLoader
        {
            ObjectTileSet.ObjectRowSchema schema = TileSet.RowSchemas[whichSchema];
            PresenceY = schema.PresenceY;
            CanClimbInto = schema.CanClimbInto;
            Opaque = schema.Opaque;
            Traversable = schema.Traversable;
            Destructible = schema.Destructible;
            Dimensions = schema.Dimensions;
            
            int whichVariant = D.Next(0, schema.Instances - 1);
            this.textureRect = new Rectangle(
                whichVariant * ((int)TileSet.TileDimensions.X * (int)Dimensions.X),
                TileSet.WhereRowStarts(whichSchema),
                (int)TileSet.TileDimensions.X * (int)Dimensions.X,
                (int)TileSet.TileDimensions.Y * (int)Dimensions.Y
                );

            this.WhichTileSet = whichTileSet;
            this.FullTileLocation = new Rectangle((int)Location.X, (int)Location.Y, (int)Dimensions.X, (int)Dimensions.Y);
            this.TL_TileLocation = new Vector2(Location.X, Location.Y);
        }

        public MapObject()//for XmlLoader
        {
        
        }

        


    }
}
