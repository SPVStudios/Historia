﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Historia;

namespace Historia
{
    public class Image
    {

        public float Alpha;
        public string Text, FontName, Path;
        [XmlIgnore]
        public Texture2D Texture;
        public bool IsActive;
        public Vector2 Position, Scale;
        public Rectangle SourceRect;
        RenderTarget2D renderTarget;
        public Vector2 Origin;
        [XmlIgnore]
        public SpriteFont font;
        Dictionary<string, ImageEffect> effectList;
        public string Effects;
        ContentManager content;

        [XmlIgnore]
        public Rectangle LocationOnScreen
        {
            get
            {
                return new Rectangle((int)Position.X, (int)Position.Y, (int)(SourceRect.Width * Scale.X), (int)(SourceRect.Height * Scale.Y));
            }
        }

        public FadeEffect FadeEffect;
        public SpriteSheetEffect SpriteSheetEffect;

        void SetEffect<T>(ref T effect)//this <T> allows the type of the variable to be different, allowing classes that INHERIT
        //from ImageEffect but are not just ImageEffects be used and handled.
        {

            if (effect == null)
            {
                effect = (T)Activator.CreateInstance(typeof(T));
            }
            else
            {
                //(effect as ImageEffect).IsActive = true;
                var obj = this;
                (effect as ImageEffect).LoadContent(ref obj);//
            }

            string Key = effect.GetType().ToString().Replace("Historia.", "");

            if (!effectList.ContainsKey(Key))
            {
                effectList.Add(Key, (effect as ImageEffect));
            }

        }

        public void ActivateEffect(string effect)
        {
            if (effectList.ContainsKey(effect))
            {
                effectList[effect].IsActive = true;
                var obj = this;
                effectList[effect].LoadContent(ref obj);
            }
        }

        public void StoreEffects()
        {
            Effects = String.Empty;
            foreach (var effect in effectList)
            {
                if (effect.Value.IsActive)
                {
                    Effects += effect.Key + ":";
                }
            }
            if (Effects != String.Empty)
            {
                Effects.Remove(Effects.Length - 1);//removes the last colon which is unnecessary
            }

        }

        public void RestoreEffects()
        {
            foreach (var effect in effectList)
            {
                DeactivateEffect(effect.Key);
            }
            string[] split = Effects.Split(':');
            foreach (string s in split)
            {
                ActivateEffect(s);
            }
        }

        public void DeactivateEffect(string effect)
        {
            if (effectList.ContainsKey(effect))
            {
                effectList[effect].IsActive = false;
                effectList[effect].UnloadContent();
            }
        }

        public Image()
        {
            Path = string.Empty;
            Text = string.Empty;
            Effects = string.Empty;
            FontName = "Gameplay/Fonts/Font1";//Change this to something actually stored (Maybe)
            Position = Vector2.Zero;
            Scale = Vector2.One;
            Alpha = 1.0f;
            SourceRect = Rectangle.Empty;
            effectList = new Dictionary<string, ImageEffect>();
        }

        public void LoadContent()
        {
            content = new ContentManager(ScreenManager.Instance.Content.ServiceProvider, "Content");

            Vector2 dimensions = Vector2.Zero;

            font = content.Load<SpriteFont>(FontName);
            int LongestLine=0;
            if (Path != String.Empty)
            {
                Texture = content.Load<Texture2D>(Path);
            }

            if (Texture != null)
            {
                dimensions.X += Texture.Width;
            }
            if(Text.Length > 40)
            {
                string[] Words = Text.Split(' ');
                int LengthThisLine = Words[0].Length;
                int LineNum = 1;
                string ThisLine = Words[0];
                LongestLine=0;
                
                for(int W = 1; W < Words.Length;W++)
                {
                    string Word = Words[W];
                    if (LengthThisLine + Word.Length < 40)
                    {
                        ThisLine += " "+Word;
                        LengthThisLine += Word.Length + 1;
                    }
                    else
                    {
                        if(font.MeasureString(ThisLine).X > LongestLine)
                        {
                            LongestLine = (int)font.MeasureString(ThisLine).X;
                        }
                        ThisLine = Word;
                        LengthThisLine = Word.Length;
                        LineNum++;
                    }
                }
                if (font.MeasureString(ThisLine).X > LongestLine)
                {
                    LongestLine = (int)font.MeasureString(ThisLine).X;
                }


                dimensions.X += LongestLine;

                if (Texture!=null)
                {
                    dimensions.Y = Math.Max(Texture.Height, LineNum*font.MeasureString(Text).Y);
                }
                else
                {
                    dimensions.Y = LineNum* font.MeasureString(Text).Y;
                }

            }//use word wrap to determine how large the image need be
            else
            {//else complete as normal
                dimensions.X += font.MeasureString(Text).X;
                LongestLine = (int)font.MeasureString(Text).X;
                if (Texture != null)
                {
                    dimensions.Y = Math.Max(Texture.Height, font.MeasureString(Text).Y);
                }
                else
                {
                    dimensions.Y = font.MeasureString(Text).Y;


                }
            }
            
            
            




            if (SourceRect == Rectangle.Empty)
            {
                SourceRect = new Rectangle(0, 0, (int)dimensions.X, (int)dimensions.Y);
            }
            if (Text != null && Text != string.Empty)
            {//add text to this image.
                renderTarget = new RenderTarget2D(ScreenManager.Instance.GraphicsDevice, (int)dimensions.X, (int)dimensions.Y);
                ScreenManager.Instance.GraphicsDevice.SetRenderTarget(renderTarget);
                ScreenManager.Instance.GraphicsDevice.Clear(Color.Transparent);
                ScreenManager.Instance.SpriteBatch.Name = "Imaging";
                ScreenManager.Instance.SpriteBatch.Begin();
                if (Texture != null)
                {//if there is an actual image, not just text...
                    ScreenManager.Instance.SpriteBatch.Draw(Texture, Vector2.Zero, Color.White);
                }
                string[] Words = Text.Split(' ');
                int LengthThisLine = Words[0].Length;
                int LineNum = 0;
                string ThisLine=Words[0];
                int LineHeight = (int)font.MeasureString(Text).Y;
                int StartX;
                for(int W = 1; W < Words.Length;W++)
                {
                    string Word = Words[W];
                    if(LengthThisLine + Word.Length < 40)
                    {
                        ThisLine += " "+Word;
                        LengthThisLine += Word.Length + 1;
                    }
                    else
                    {
                        StartX = (LongestLine - (int)font.MeasureString(ThisLine).X)/2;
                        ScreenManager.Instance.SpriteBatch.DrawString(font, ThisLine, new Vector2(StartX,LineHeight*LineNum), Color.White);
                        ThisLine = Word;
                        LengthThisLine = Word.Length;
                        LineNum++;
                    }
                }
                StartX = (LongestLine - (int)font.MeasureString(ThisLine).X) / 2;
                ScreenManager.Instance.SpriteBatch.DrawString(font, ThisLine, new Vector2(StartX, LineHeight* LineNum), Color.White);//and add the last line

                ScreenManager.Instance.SpriteBatch.End();
                ScreenManager.Instance.SpriteBatch.Name = string.Empty;
                //everything has now been drawn to the render target

                Texture = renderTarget;
                //this sets the texture to the drawn image of both the text AND the image so will be dealt with in one go in th future.

                ScreenManager.Instance.GraphicsDevice.SetRenderTarget(null);

            }


            SetEffect<FadeEffect>(ref FadeEffect);
            SetEffect<SpriteSheetEffect>(ref SpriteSheetEffect);

            /*This creates a FadeEffect for the Effectlist, but uses it as a reference, so
            changes to the FadeEffect directing BACK to the original that has the extra variables associated with a FadeEffect
            and so these values can still be modified relatively easily and efficiently.*/

            if (Effects != string.Empty)
            {
                string[] split = Effects.Split(':');
                foreach (string item in split)
                {
                    ActivateEffect(item);
                }
            }

        }

        public void UnloadContent()
        {
            content.Unload();

            foreach (var effect in effectList)//unload all of the effects in the effectsList of the Image.
            {
                DeactivateEffect(effect.Key);
            }
        }

        public void Update(GameTime GameTime)
        {
            foreach (var effect in effectList)//update all of the effects currently in the effectsList...
            {
                if (effect.Value.IsActive == true)//...that are currently active
                {
                    effect.Value.Update(GameTime);
                }
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            Rectangle DestinationRectangle = new Rectangle((int)Position.X, (int)Position.Y, (int)(SourceRect.Width * Scale.X), (int)(SourceRect.Height * Scale.Y));
            //spriteBatch.Draw(Texture, Position, SourceRect, Color.White * Alpha, 0.0f, Origin, Scale, SpriteEffects.None, 0.0f);

            //above gives more options but makes SuspicionBar vibrate due to pixel discrepencies
            spriteBatch.Draw(Texture, DestinationRectangle, SourceRect, Color.White * Alpha);
        }
    }  
}
