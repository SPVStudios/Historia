﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Xml.Serialization;

namespace Historia
{
    public class ObjectLayer// NOT inheriting Layer
    {

        public Vector2 Size;
        [XmlIgnore]
        public bool[,] Opaques;
        public Vector2 TileDimensions;
        [XmlIgnore]
        public bool[,] CanClimbIntos;
        [XmlIgnore]
        public bool[,] UNTraversables;
        

        [XmlElement("TileSet")]
        public List<ObjectTileSet> TileSets;

        [XmlElement("Object")]
        List<MapObject> Objects;//DON'T MAKE PUBLIC! interacting with this list should be carried out with the methods such as "RemoveAtReference" instead.

        [XmlIgnore]
        public int[,] ObjectReferences;//this will be refer to any object's position in the object list for a given co-ord, PLUS ONE
                                       // (as it can't have 0, seeing as all non-changed values in the array are 0)


        public ObjectLayer(List<ObjectTileSet> _TileSets, List<MapObject> Objects, Vector2 _TileDimensions, Vector2 Size)
        //for when creating a layer from scratch, without loading anything....
        {

            TileDimensions = _TileDimensions;
            TileSets = _TileSets;
            this.Objects = new List<MapObject>();
            this.Opaques = new bool[(int)Size.X, (int)Size.Y];
            this.UNTraversables = new bool[(int)Size.X, (int)Size.Y];
            this.CanClimbIntos = new bool[(int)Size.X, (int)Size.Y];
            this.Size = Size;

            ObjectReferences = new int[(int)Size.X, (int)Size.Y];
            foreach (MapObject O in Objects)
            {
                AddObject(O);
            }
        }

 
        public ObjectLayer()//for when creating a layer that will be filled with data loaded from the XmlLoader
        {
            this.Objects = new List<MapObject>();
            
        }

        public void AddObject(MapObject O)
        {
            Objects.Add(O);


            for (int X = 0; X < O.Dimensions.X; X++)
            {
                for (int Y = 0; Y < O.Dimensions.Y; Y++)
                {
                    ObjectReferences[(int)O.TL_TileLocation.X + X, (int)O.TL_TileLocation.Y + Y] = Objects.Count;//= to count as it is count - 1 (latest) + 1(cannot be 0 as 0 is = to null)
                }
            }

            if (O.Opaque)
            {
                for (int X = 0; X < O.FullTileLocation.Width; X++)
                {
                    for (int Y = 0; Y < O.FullTileLocation.Height; Y++)
                    {
                        Opaques[O.FullTileLocation.X + X, O.FullTileLocation.Y + Y] = true;
                    }
                }
            }
            if (!O.Traversable)
            {
                for (int X = 0; X < O.FullTileLocation.Width; X++)
                {
                    for (int Y = 0; Y < O.FullTileLocation.Height; Y++)
                    {
                        UNTraversables[O.FullTileLocation.X + X, O.FullTileLocation.Y + Y] = true;
                    }
                }
            }
            if (O.CanClimbInto)
            {
                for (int X = 0; X < O.Dimensions.X; X++)
                {
                    for (int Y = 0; Y < O.Dimensions.Y; Y++)
                    {
                        CanClimbIntos[(int)O.TL_TileLocation.X + X, (int)O.TL_TileLocation.Y + Y] = true;
                    }
                }
            }
        }

        private void CheckOverlap(MapObject O)
        {
            foreach (MapObject Comparator in Objects)
            {
                if (RectMethod.TileIntersects(O.FullTileLocation, Comparator.FullTileLocation))
                {
                    throw new Exception("Objects occupying same tiles");
                }
            }
        }

        public virtual void LoadContent()//for use just after having loaded from an Xml file
        {
            Opaques = new bool[(int)Size.X, (int)Size.Y];
            UNTraversables = new bool[(int)Size.X, (int)Size.Y];
            CanClimbIntos = new bool[(int)Size.X, (int)Size.Y];
            ObjectReferences = new int[(int)Size.X, (int)Size.Y];

            foreach (ObjectTileSet tileset in TileSets)
            {
                tileset.LoadContent();
            }

        }


        public void LoadContent(bool IsNewMap)//always hand this "true", else it will throw an exception.
        {
            if (IsNewMap)
            {
                foreach (ObjectTileSet tileset in TileSets)
                {
                    tileset.LoadContent();
                }
                foreach (MapObject Obj in Objects)
                {

                }
            }
            else
            {
                throw new Exception("You've given it a false value for the new Map version of LoadContent.Give it true or nothing at all!");
            }

        }

        public void UnloadContent()
        {
            foreach (TileSet tileset in TileSets)
            {
                tileset.UnloadContent();
            }
            


        }

        public void Update(GameTime gameTime)
        {

        }

        public void Draw(SpriteBatch spriteBatch, Rectangle DrawArea, Vector2 DrawPoint,  Vector2 Offset)
        {
            Vector2 Origin = new Vector2(DrawArea.X - DrawPoint.X, DrawArea.Y - DrawPoint.Y);//the top-left tile
            foreach (MapObject O in Objects)
            {
                if (RectMethod.TileIntersects(O.FullTileLocation, DrawArea))
                {
                    


                    O.DrawLocation = (O.TL_TileLocation - Origin) * TileDimensions;
                    O.DrawLocation -= Offset;
                  
                    spriteBatch.Draw(TileSets[O.WhichTileSet].Image.Texture, new Rectangle(
                        (int)O.DrawLocation.X, (int)O.DrawLocation.Y,
                        (int)(O.Dimensions.X * TileDimensions.X), (int)(O.Dimensions.Y * TileDimensions.Y)),

                        O.SourceRect, Color.White);
                }
            }
        }

        public void Draw(SpriteBatch spriteBatch, Camera camera)
        {
            foreach (MapObject O in Objects)
            {
                if (RectMethod.TileIntersects(O.FullTileLocation, camera.DrawArea))
                {
                    
                    O.DrawLocation = (O.TL_TileLocation - camera.Origin) * TileDimensions;
                    O.DrawLocation -= camera.Offset;

                    spriteBatch.Draw(TileSets[O.WhichTileSet].Image.Texture, new Rectangle(
                        (int)O.DrawLocation.X, (int)O.DrawLocation.Y,
                        (int)(O.Dimensions.X * TileDimensions.X), (int)(O.Dimensions.Y * TileDimensions.Y)),

                        O.SourceRect, Color.White);
                }
            }
        }

        public void RemoveObjectAt(int ReferenceNumber)//removes the object with the given reference number.
        {
            Objects.RemoveAt(ReferenceNumber - 1);
        }

        public MapObject MapObjectAt(int ReferenceNumber)//returns a copy of the object with the given reference number.
        {
            return Objects[ReferenceNumber - 1];
        }

    }
}
    

